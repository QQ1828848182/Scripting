// ---------- 首页：状态总览（布局对齐 F50 Monitor 参考稿） ----------
// 结构：运营商/信号卡（运营商 + 制式 + 频段 + 信号格 + 签约信息 + RSRP/SINR/RSRQ 三列）
//       → 实时下载 / 实时上传（带走势图）→ 套餐流量（进度条 + 今日/本月）
//       → CPU / 内存 → 在线设备 / 运行时长

import { ScrollView, VStack, HStack, ZStack, Text, Image, Spacer, Canvas, Menu, Button, useState, useEffect, ProgressView } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { fetchDevices, fmtMac, isOnline } from "./lib/api"
import {
  fetchSnapshotWithRate,
  loadSnapshot,
  saveSnapshot,
  fmtMb,
  fmtRate,
  fmtUptime,
  signalColor,
  signalBars,
  levelColor,
  levelText,
  ratio,
  parsePct,
  daysToReset,
  type DeviceSnapshot,
  type Rate,
} from "./lib/deviceData"
import { fill, capsuleFill, glassStyle, ACCENT, OK, DANGER } from "./lib/ui"
import BindPage from "./bind"
import { brandOf } from "./lib/brand"
import { BrandMark } from "./lib/brandMark"

const PURPLE = "#5E5CE6"
const WARM = "#FF9F0A"

/** "1.20 GB" / "983 MB" / "—" → { value, unit } */
function splitMb(mb: number | null | undefined): { value: string; unit: string } {
  const s = fmtMb(mb)
  if (!s || s === "—") return { value: "—", unit: "" }
  const m = s.match(/^([\d.]+)\s*([A-Za-z]+)?$/)
  return m ? { value: m[1], unit: m[2] ?? "" } : { value: s, unit: "" }
}

/** 当前选中的设备 MAC（持久化，下次进入直接回到上次那台） */
const ACTIVE_MAC_KEY = "cpe.activeMac.v1"

function loadActiveMac(): string | null {
  try {
    const v = Storage.get(ACTIVE_MAC_KEY)
    return typeof v === "string" && v ? v : null
  } catch {
    return null
  }
}

const INITIAL_ACTIVE_MAC = loadActiveMac()

/** 首页 22 秒轮询与下拉刷新可能撞车：同一时间只允许一个快照请求 */
let snapshotInFlight = false

/** 圆角矩形路径（Canvas 没有 roundRect） */
function roundRectPath(ctx: any, x: number, y: number, w: number, h: number) {
  const r = Math.min(h / 2, Math.max(0, w) / 2)
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.lineTo(x + w - r, y)
  ctx.arc(x + w - r, y + r, r, -Math.PI / 2, Math.PI / 2)
  ctx.lineTo(x + r, y + h)
  ctx.arc(x + r, y + r, r, Math.PI / 2, (Math.PI * 3) / 2)
  ctx.closePath()
}

/** 细进度条 */
function Meter(props: { ratio: number; color: any; height?: number }) {
  const h = props.height ?? 5
  const r = Number.isFinite(props.ratio) ? Math.max(0, Math.min(1, props.ratio)) : 0
  return (
    <Canvas
      opaque={false}
      frame={{ maxWidth: "infinity", height: h }}
      draw={(ctx, size) => {
        const w = size.width
        ctx.fillStyle = "rgba(120,120,128,0.22)"
        roundRectPath(ctx, 0, 0, w, h)
        ctx.fill()
        if (r <= 0) return
        ctx.fillStyle = props.color
        roundRectPath(ctx, 0, 0, Math.max(h, w * r), h)
        ctx.fill()
      }}
    />
  )
}

/** 四格信号柱 */
function Bars(props: { level: number; color: any }) {
  const heights = [6, 9, 12, 15]
  return (
    <HStack spacing={2.5} alignment="bottom">
      {heights.map((h, i) => (
        <VStack
          key={i}
          frame={{ width: 3.5, height: h }}
          background={i < props.level ? props.color : "rgba(120,120,128,0.32)"}
        />
      ))}
    </HStack>
  )
}

/** 卡片：背景铺满整行，内容用 padding 内缩（所有卡左右边缘才会完全对齐） */
function Card(props: {
  children?: any
  padding?: number | { horizontal?: number; vertical?: number; top?: number; bottom?: number; leading?: number; trailing?: number }
  spacing?: number
  bg?: string
  onLongPress?: () => void
  width?: number
}) {
  const { children, padding = 10, spacing = 6, bg = "rgba(120,120,128,0.10)", onLongPress, width } = props
  return (
    <VStack
      alignment="leading"
      spacing={0}
      frame={width !== undefined ? { width } : { maxWidth: "infinity" }}
      glassEffect={glassStyle({ cornerRadius: 20 })}
      background={fill(bg, 20)}
      onLongPressGesture={onLongPress}
    >
      <VStack alignment="leading" spacing={spacing} padding={padding} frame={{ maxWidth: "infinity" }}>
        {children}
      </VStack>
    </VStack>
  )
}

/** 小圆底图标 */
function Dot(props: { icon: string; color: any; size?: number }) {
  const { icon, color, size = 30 } = props
  return (
    <VStack alignment="center" frame={{ width: size, height: size }} background={capsuleFill(color, 0.16)}>
      <Image systemName={icon} font={size * 0.46} foregroundStyle={color} />
    </VStack>
  )
}

/** 小信息块：上面标签、下面数值 */
function InfoBox(props: { label: string; value: string }) {
  return (
    <VStack
      alignment="leading"
      spacing={1}
      padding={{ horizontal: 8, vertical: 6 }}
      frame={{ maxWidth: "infinity" }}
      glassEffect={glassStyle({ cornerRadius: 12 })}
      background={fill("rgba(120,120,128,0.10)", 12)}
    >
      <Text font="caption2" foregroundStyle="tertiaryLabel" lineLimit={1}>
        {props.label}
      </Text>
      <Text font="headline" fontWeight="semibold" monospacedDigit foregroundStyle="label" lineLimit={1} minScaleFactor={0.7}>
        {props.value}
      </Text>
    </VStack>
  )
}

/** 信号三列里的一列 */
function SignalCol(props: { label: string; value: number | null; unit: string; kind: "rsrp" | "sinr" | "rsrq" }) {
  const { label, value, unit, kind } = props
  const color = levelColor(kind, value)
  return (
    <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity" }}>
      <HStack spacing={4} frame={{ maxWidth: "infinity" }}>
        <Text font="caption2" foregroundStyle="secondaryLabel">
          {label}
        </Text>
        <Spacer />
        <Text font="caption2" foregroundStyle={color} lineLimit={1}>
          {levelText(kind, value)}
        </Text>
      </HStack>
      <HStack spacing={3} alignment="firstTextBaseline" frame={{ maxWidth: "infinity" }}>
        <Text font="title3" fontWeight="bold" monospacedDigit foregroundStyle="label" lineLimit={1} minScaleFactor={0.8}>
          {value !== null ? String(value) : "—"}
        </Text>
        <Text font="caption2" foregroundStyle="tertiaryLabel" lineLimit={1}>
          {value !== null ? unit : ""}
        </Text>
        <Spacer />
      </HStack>
      <Meter ratio={ratio(kind, value)} color={color} height={4} />
    </VStack>
  )
}

/** 底部两列小卡：标题 + 大数字 */
function MiniCard(props: {
  icon: string
  color: any
  label: string
  value: string
  note?: string
  meter?: number
  small?: boolean
  onLongPress?: () => void
}) {
  const { icon, color, label, value, note, meter, small, onLongPress } = props
  return (
    <Card padding={8} spacing={4} onLongPress={onLongPress}>
      <HStack spacing={6} frame={{ maxWidth: "infinity" }}>
        <Image systemName={icon} font={12} foregroundStyle={color} />
        <Text font="caption" foregroundStyle="secondaryLabel">
          {label}
        </Text>
        <Spacer />
      </HStack>
      <HStack spacing={3} alignment="firstTextBaseline" frame={{ maxWidth: "infinity" }}>
        <Text font={small ? "subheadline" : "title3"} fontWeight="bold" monospacedDigit foregroundStyle="label" lineLimit={1}>
          {value}
        </Text>
        <Spacer />
      </HStack>
      {meter !== undefined ? <Meter ratio={meter} color={color} height={4} /> : null}
      {note ? (
        <Text font="caption2" foregroundStyle="tertiaryLabel" frame={{ maxWidth: "infinity", alignment: "leading" }}>
          {note}
        </Text>
      ) : null}
    </Card>
  )
}

/** 设备选择弹层内容（顶部点设备名时弹出） */
export function DevicePicker(props: {
  devices: DeviceInfo[]
  activeMac?: string | null
  onPick: (mac: string) => void
  onAdd: () => void
  onClose: () => void
}) {
  const { devices, activeMac, onPick, onAdd, onClose } = props
  return (
    <VStack
      alignment="leading"
      spacing={8}
      padding={14}
      frame={{ maxWidth: 320 }}
      background={fill("#FFFFFF", 22, 0.94)}
    >
      <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
        <Text font="headline">在线设备</Text>
        <Spacer />
        <Text font="subheadline" fontWeight="semibold" foregroundStyle={ACCENT} onTapGesture={onClose}>
          完成
        </Text>
      </HStack>
      <Text font="caption2" foregroundStyle="tertiaryLabel">
        点击切换要查看的路由器
      </Text>

      {devices.length === 0 ? (
        <Text font="footnote" foregroundStyle="secondaryLabel" padding={{ vertical: 12 }}>
          当前账号下没有已绑定设备
        </Text>
      ) : null}

      <VStack spacing={8} frame={{ maxWidth: "infinity" }}>
        {devices.map((d) => {
          const on = isOnline(d)
          const active = activeMac === d.mac
          return (
            <HStack
              key={d.mac}
              spacing={10}
              padding={12}
              frame={{ maxWidth: "infinity" }}
              glassEffect={true}
              contentShape="rect"
              onTapGesture={() => onPick(d.mac)}
            >
              <Image systemName="wifi.router.fill" font={15} foregroundStyle={on ? OK : "#8E8E93"} />
              <VStack alignment="leading" spacing={1} frame={{ maxWidth: "infinity", alignment: "leading" }}>
                <Text font="subheadline" fontWeight="semibold" foregroundStyle={active ? ACCENT : undefined} lineLimit={1}>
                  {d.name || d.model || "未命名设备"}
                </Text>
                <Text font="caption2" foregroundStyle="tertiaryLabel" lineLimit={1}>
                  {`${d.model || "—"} · ${fmtMac(d.mac)}`}
                </Text>
              </VStack>
              <Text font="caption2" fontWeight="semibold" foregroundStyle={on ? OK : "#8E8E93"} lineLimit={1}>
                {on ? "在线" : "离线"}
              </Text>
              {active ? <Image systemName="checkmark.circle.fill" font={14} foregroundStyle={ACCENT} /> : null}
            </HStack>
          )
        })}
      </VStack>

      {/* 添加新的绑定设备 */}
      <HStack
        spacing={8}
        padding={{ horizontal: 12, vertical: 11 }}
        frame={{ maxWidth: "infinity" }}
        background={undefined}
        glassEffect={true}
        contentShape="rect"
        onTapGesture={onAdd}
      >
        <Image systemName="plus.circle.fill" font={15} foregroundStyle={ACCENT} />
        <Text font="subheadline" fontWeight="semibold" foregroundStyle={ACCENT}>
          添加新的绑定设备
        </Text>
        <Spacer />
        <Image systemName="chevron.right" font="caption2" foregroundStyle={ACCENT} />
      </HStack>
    </VStack>
  )
}

export default function HomePage(props: {
  session: Session
  devices: DeviceInfo[]
  onDevices: (d: DeviceInfo[]) => void
  onUnauthorized: () => void
  onExit: () => void
  /** 外层底栏选中项；用来知道首页是不是当前页签（onAppear 在 TabView 里不可靠） */
  activeTab?: { value: string; subscribe: (l: (v: string) => void) => void; unsubscribe: (l: (v: string) => void) => void }
}) {
  const { session, devices } = props
  const [activeMac, setActiveMac] = useState<string | null>(INITIAL_ACTIVE_MAC)
  const [adding, setAdding] = useState(false)
  const [bindRound, setBindRound] = useState(0)
  const device = devices.find((d) => d.mac === activeMac) ?? devices[0]

  const [snap, setSnap] = useState<DeviceSnapshot | null>(loadSnapshot())
  const [rate, setRate] = useState<Rate>({ downKbps: null, upKbps: null, source: "ambr" })
  const [loading, setLoading] = useState(false)
  /** 每次「首页重新出现」加一（onAppear），用来触发一次刷新 */
  const [appearRound, setAppearRound] = useState(0)
  /** 底栏当前页签 */
  const [tabValue, setTabValue] = useState<string>(() => (props.activeTab ? props.activeTab.value : "home"))
  const visible = tabValue === "home"
  const [error, setError] = useState("")
  const [toast, setToast] = useState("")

  function say(msg: string) {
    setToast(msg)
    setTimeout(() => setToast(""), 3500)
  }

  /** 拉设备列表：devices 由上层（index.tsx）持有，首页负责首次填充与刷新 */
  async function loadDeviceList() {
    if (!session.token) return
    try {
      const r = await fetchDevices(session)
      props.onDevices(r.devices ?? [])
    } catch (e: any) {
      const msg = String(e?.message ?? e)
      if (/登录|失效|token|10002|-1000|10001/i.test(msg)) {
        props.onUnauthorized()
        return
      }
      setError((prev) => prev || msg)
    }
  }

  async function load(silent = false) {
    if (!device?.mac) {
      await loadDeviceList()
      return
    }
    // 上一轮还没回来就不并发，等下一轮
    if (snapshotInFlight) return
    snapshotInFlight = true
    if (!silent) setLoading(true)
    setError("")
    try {
      const r = await fetchSnapshotWithRate(device.mac, session.token)
      if (r.authFailed) {
        props.onUnauthorized()
        return
      }
      setSnap(r.snapshot)
      setRate(r.rate)
      saveSnapshot(r.snapshot)
      if (r.errors.length) setError(r.errors.join(" · "))
    } catch (e: any) {
      setError(e?.message ?? "读取失败")
    } finally {
      snapshotInFlight = false
      if (!silent) setLoading(false)
    }
  }

  useEffect(() => {
    if (!session.token) return
    if (!device?.mac) {
      loadDeviceList()
      return
    }
    load()
  }, [device?.mac, session.token])

  useEffect(() => {
    const ob = props.activeTab
    if (!ob) return
    const listener = (v: string) => setTabValue(v)
    ob.subscribe(listener)
    return () => ob.unsubscribe(listener)
  }, [])

  // 页面可见时：先立刻静默刷一次（从其他页切回来就是最新的），然后每 22 秒一轮
  // 注：Scripting 没有 setInterval，用 setTimeout 自己续期
  useEffect(() => {
    if (!visible || !session.token || !device?.mac) return
    let alive = true
    let handle: any = null
    const tick = () => {
      handle = setTimeout(() => {
        if (!alive) return
        load(true).finally(() => {
          if (alive) tick()
        })
      }, 22000)
    }
    load(true).finally(() => {
      if (alive) tick()
    })
    return () => {
      alive = false
      if (handle !== null) clearTimeout(handle)
    }
  }, [visible, appearRound, device?.mac, session.token])

  const rsrp = snap?.rsrp ?? null
  const sinr = snap?.sinr ?? null
  const rsrq = snap?.rsrq ?? null
  const sColor = signalColor(rsrp)
  const bars = snap?.signalLevel !== null && snap?.signalLevel !== undefined ? Math.round(snap.signalLevel) : signalBars(rsrp)
  const brand = brandOf(snap?.operator)
  const online = device ? isOnline(device) : false

  const down = fmtRate(rate.downKbps)
  const up = fmtRate(rate.upKbps)
  const rateNote =
    rate.source === "live" ? "设备实时读数" : rate.source === "diff" ? "实时采样" : rate.source === "idle" ? "当前空闲" : "签约上限"

  const monthUsedMb = (snap?.monthRxMb ?? 0) + (snap?.monthTxMb ?? 0)
  const dayUsedMb = (snap?.dayRxMb ?? 0) + (snap?.dayTxMb ?? 0)
  const limitMb = snap?.monthLimitMb ?? null
  const limitValid = limitMb !== null && limitMb > 0
  const limitOn = snap?.monthLimitOn === true && limitValid
  const usedPct = limitValid && limitMb ? Math.min(100, (monthUsedMb / limitMb) * 100) : 0
  const remainMb = limitValid && limitMb !== null ? Math.max(0, limitMb - monthUsedMb) : null
  const limitTxt =
    limitMb === null
      ? ""
      : limitMb >= 1024
        ? `${Math.round(limitMb / 1024)} GB`
        : `${Math.round(limitMb)} MB`
  const resetDays = daysToReset(snap?.monthStartDay ?? null)

  const cpu = parsePct(snap?.cpu)
  const ram = parsePct(snap?.ram)
  const dlAmbrTxt =
    snap?.dlAmbrKbps !== null && snap?.dlAmbrKbps !== undefined ? `${Math.round((snap.dlAmbrKbps ?? 0) / 1024)} Mbps` : "—"
  const ulAmbrTxt =
    snap?.ulAmbrKbps !== null && snap?.ulAmbrKbps !== undefined ? `${Math.round((snap.ulAmbrKbps ?? 0) / 1024)} Mbps` : "—"

  return (
    <ZStack
      alignment="center"
      onAppear={() => setAppearRound((n) => n + 1)}
    >
      <ScrollView refreshable={load}>
      <VStack alignment="leading" spacing={5} padding={{ horizontal: 14, top: 2, bottom: 14 }}>
        {/* 顶部：居中设备名+在线（右侧占位与左侧 Spacer 对称，保证居中） */}
        <HStack spacing={10} frame={{ maxWidth: "infinity" }}>
          <Spacer />
          <Menu
            label={
              <HStack spacing={6} contentShape="rect">
                <Text font="headline" fontWeight="semibold" foregroundStyle="label" lineLimit={1} minScaleFactor={0.7}>
                  {device?.name || device?.model || (loading ? "正在同步…" : "未绑定设备")}
                </Text>
                <Text
                  font="caption2"
                  fontWeight="semibold"
                  foregroundStyle={online ? OK : "#8E8E93"}
                  padding={{ horizontal: 5, vertical: 1 }}
                  background={capsuleFill(online ? OK : "#8E8E93", 0.16)}
                  lineLimit={1}
                >
                  {online ? "在线" : "离线"}
                </Text>
                <Image
                  systemName="chevron.up.chevron.down"
                  font="caption2"
                  fontWeight="semibold"
                  foregroundStyle="secondaryLabel"
                />
              </HStack>
            }
          >
            {devices.map(d => (
              <Button
                key={d.mac}
                title={`${d.mac === device?.mac ? "✓ " : ""}${d.name || d.model || fmtMac(d.mac)}`}
                action={() => {
                  setActiveMac(d.mac)
                  setSnap(null)
                  try {
                    Storage.set(ACTIVE_MAC_KEY, d.mac)
                  } catch {}
                }}
              />
            ))}
            <Button
              title="添加设备…"
              action={() => {
                setBindRound(bindRound + 1)
                setAdding(true)
              }}
            />
          </Menu>
          <Spacer />
        </HStack>


        {toast ? (
          <HStack spacing={8} padding={12} frame={{ maxWidth: "infinity" }} background={fill(OK, 14, 0.14)}>
            <Image systemName="checkmark.circle.fill" font="footnote" foregroundStyle={OK} />
            <Text font="footnote" foregroundStyle="label" frame={{ maxWidth: "infinity", alignment: "leading" }}>
              {toast}
            </Text>
          </HStack>
        ) : null}

        {!device && !loading ? (
          <HStack spacing={8} padding={12} frame={{ maxWidth: "infinity" }} glassEffect={glassStyle({ cornerRadius: 14 })} background={fill("rgba(120,120,128,0.12)", 14)}>
            <Image systemName="info.circle.fill" font="footnote" foregroundStyle="secondaryLabel" />
            <Text font="footnote" foregroundStyle="secondaryLabel" frame={{ maxWidth: "infinity", alignment: "leading" }}>
              当前账号下没有已绑定设备。若刚完成绑定，下拉刷新即可。
            </Text>
          </HStack>
        ) : null}

        {/* ① 运营商 + 信号 */}
        <Card padding={8} spacing={5}>
          {/* 同一行：图标 · 运营商 · 制式 · 频段 · 信号柱 · 在线 */}
          <HStack spacing={7} frame={{ maxWidth: "infinity" }}>
            {brand ? <BrandMark brand={brand} size={30} /> : <Dot icon="antenna.radiowaves.left.and.right" color={sColor} size={30} />}
            <Text font="title3" fontWeight="bold" lineLimit={1} minScaleFactor={0.6}>
              {snap?.operator && snap.operator !== "—" ? snap.operator : "—"}
            </Text>
            <Text
              font="caption2"
              fontWeight="semibold"
              foregroundStyle={ACCENT}
              padding={{ horizontal: 5, vertical: 1 }}
              background={capsuleFill(ACCENT, 0.16)}
              lineLimit={1}
            >
              {snap?.workMode && snap.workMode !== "—" ? snap.workMode : "—"}
            </Text>
            <Text font="caption2" fontWeight="semibold" foregroundStyle="secondaryLabel" lineLimit={1} minScaleFactor={0.7}>
              {snap?.band || "—"}
            </Text>
            <Spacer />
            <Bars level={bars} color={sColor} />
          </HStack>

          {/* 签约下行 / 签约上行 / QCI：三块，文字在上数字在下 */}
          <HStack spacing={6} frame={{ maxWidth: "infinity" }}>
            <InfoBox label="签约下行" value={dlAmbrTxt} />
            <InfoBox label="签约上行" value={ulAmbrTxt} />
            <InfoBox label="QCI" value={snap?.qci && snap.qci !== "—" ? snap.qci : "—"} />
          </HStack>

          <HStack spacing={0} frame={{ maxWidth: "infinity", height: 0.5 }} background={fill("rgba(120,120,128,0.25)")}>
            <Spacer />
          </HStack>

          <HStack spacing={14} frame={{ maxWidth: "infinity" }}>
            <SignalCol label="RSRP" value={rsrp} unit="dBm" kind="rsrp" />
            <SignalCol label="SINR" value={sinr} unit="dB" kind="sinr" />
            <SignalCol label="RSRQ" value={rsrq} unit="dB" kind="rsrq" />
          </HStack>

          <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
            <Text font="caption2" foregroundStyle="tertiaryLabel">
              {`PCI ${snap?.pci || "—"} · ARFCN ${snap?.arfcn || "—"}`}
            </Text>
            <Spacer />
          </HStack>
        </Card>

        {/* ② 实时速率（回到原样式：双色卡 + 大数字） */}
        <HStack spacing={12} frame={{ maxWidth: "infinity" }}>
          <Card padding={8} spacing={3} bg="rgba(48,209,88,0.14)">
            <HStack spacing={6} frame={{ maxWidth: "infinity" }}>
              <Image systemName="arrow.down" font={12} foregroundStyle={OK} />
              <Text font="caption" foregroundStyle="secondaryLabel">
                下载
              </Text>
              <Spacer />
            </HStack>
            <HStack spacing={3} alignment="firstTextBaseline" frame={{ maxWidth: "infinity" }}>
              <Text font="title2" fontWeight="bold" monospacedDigit>
                {down.value}
              </Text>
              <Text font="caption2" foregroundStyle="secondaryLabel">
                {down.unit}
              </Text>
              <Spacer />
            </HStack>
            <Text font="caption2" foregroundStyle="tertiaryLabel" frame={{ maxWidth: "infinity", alignment: "leading" }}>
              {rateNote}
            </Text>
          </Card>
          <Card padding={8} spacing={3} bg="rgba(10,132,255,0.14)">
            <HStack spacing={6} frame={{ maxWidth: "infinity" }}>
              <Image systemName="arrow.up" font={12} foregroundStyle={ACCENT} />
              <Text font="caption" foregroundStyle="secondaryLabel">
                上传
              </Text>
              <Spacer />
            </HStack>
            <HStack spacing={3} alignment="firstTextBaseline" frame={{ maxWidth: "infinity" }}>
              <Text font="title2" fontWeight="bold" monospacedDigit>
                {up.value}
              </Text>
              <Text font="caption2" foregroundStyle="secondaryLabel">
                {up.unit}
              </Text>
              <Spacer />
            </HStack>
            <Text font="caption2" foregroundStyle="tertiaryLabel">
              {rateNote}
            </Text>
          </Card>
        </HStack>

        {/* ③ 载波聚合 */}
        <Card padding={8} spacing={4}>
          <HStack spacing={7} frame={{ maxWidth: "infinity" }}>
            <Image systemName="antenna.radiowaves.left.and.right" font={12} foregroundStyle={ACCENT} />
            <Text font="headline">载波聚合</Text>
            <Spacer />
            <Text font="caption2" foregroundStyle="tertiaryLabel" lineLimit={1}>
              {snap ? `${snap.carriers.length} CC` : "—"}
            </Text>
          </HStack>

          {snap && snap.carriers.length ? (
            snap.carriers.map((c, i) => (
              <HStack key={i} spacing={6} frame={{ maxWidth: "infinity" }}>
                <Text
                  font="caption2"
                  fontWeight="semibold"
                  foregroundStyle={ACCENT}
                  padding={{ horizontal: 5, vertical: 1 }}
                  background={capsuleFill(ACCENT, 0.14)}
                  lineLimit={1}
                >
                  {c.role || "CC"}
                </Text>
                <Text font="subheadline" fontWeight="semibold" lineLimit={1}>
                  {c.band || "—"}
                </Text>
                {c.bandwidth ? (
                  <Text font="caption2" foregroundStyle="tertiaryLabel" lineLimit={1}>
                    {c.bandwidth}
                  </Text>
                ) : null}
                <Spacer />
                <Text font="caption2" foregroundStyle="secondaryLabel" monospacedDigit lineLimit={1} minScaleFactor={0.65}>
                  {`ARFCN ${c.arfcn || "—"} · PCI ${c.pci || "—"}${c.rsrp ? ` · ${c.rsrp} dBm` : ""}`}
                </Text>
              </HStack>
            ))
          ) : (
            <Text font="caption2" foregroundStyle="tertiaryLabel">
              暂无载波信息
            </Text>
          )}
        </Card>
        <Card padding={10} spacing={6}>
          <HStack spacing={7} frame={{ maxWidth: "infinity" }}>
            <Image systemName="chart.bar.fill" font={13} foregroundStyle={ACCENT} />
            <Text font="headline">套餐流量</Text>
            <Spacer />
            <Text font="caption2" foregroundStyle="tertiaryLabel">
              {limitValid ? (limitOn ? "限额已开启" : "限额已关闭") : "未设限额"}
            </Text>
          </HStack>

          <HStack spacing={10} frame={{ maxWidth: "infinity" }}>
            <Text font="caption" foregroundStyle="secondaryLabel">
              剩余
            </Text>
            <Text font="headline" fontWeight="bold" monospacedDigit foregroundStyle="label" lineLimit={1}>
              {remainMb !== null ? fmtMb(remainMb) : "—"}
            </Text>
            <Spacer />
            <Text font="caption2" foregroundStyle="secondaryLabel" monospaced lineLimit={1}>
              {`已用 ${fmtMb(monthUsedMb)}${limitTxt ? ` / ${limitTxt}` : ""}`}
            </Text>
          </HStack>

          <Meter ratio={limitValid ? usedPct / 100 : Math.min(1, monthUsedMb > 0 ? monthUsedMb / 1024 / 10 : 0)} color={usedPct > 90 ? DANGER : usedPct > 70 ? WARM : limitValid ? (limitOn ? ACCENT : "rgba(120,120,128,0.55)") : ACCENT} height={6} />

          <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
            <Text font="caption2" foregroundStyle="tertiaryLabel">
              {limitValid ? `已用 ${usedPct.toFixed(0)}%` : "按本月用量估算"}
            </Text>
            <Spacer />
            <Text font="caption2" foregroundStyle="tertiaryLabel">
              {resetDays === null ? "" : resetDays <= 0 ? "今天重置" : `${resetDays}天后重置`}
            </Text>
          </HStack>

          <HStack spacing={6} frame={{ maxWidth: "infinity" }}>
            <Card padding={8} spacing={3} bg="rgba(120,120,128,0.10)">
              <HStack spacing={5} frame={{ maxWidth: "infinity" }}>
                <Image systemName="sun.max.fill" font={10} foregroundStyle={WARM} />
                <Text font="caption2" foregroundStyle="secondaryLabel">
                  今日流量
                </Text>
                <Spacer />
              </HStack>
              <Text font="headline" fontWeight="semibold" monospacedDigit foregroundStyle="label" lineLimit={1} minScaleFactor={0.7} frame={{ maxWidth: "infinity", alignment: "leading" }}>
                {fmtMb(dayUsedMb)}
              </Text>
              <HStack spacing={6} frame={{ maxWidth: "infinity" }}>
                <HStack spacing={2}>
                  <Image systemName="arrow.down" font={9} foregroundStyle={OK} />
                  <Text font={10} foregroundStyle={OK} lineLimit={1} minScaleFactor={0.7} allowsTightening>
                    {fmtMb(snap?.dayRxMb ?? null)}
                  </Text>
                </HStack>
                <HStack spacing={2}>
                  <Image systemName="arrow.up" font={9} foregroundStyle={ACCENT} />
                  <Text font={10} foregroundStyle={ACCENT} lineLimit={1} minScaleFactor={0.7} allowsTightening>
                    {fmtMb(snap?.dayTxMb ?? null)}
                  </Text>
                </HStack>
                <Spacer />
              </HStack>
            </Card>
            <Card padding={8} spacing={3} bg="rgba(120,120,128,0.10)">
              <HStack spacing={5} frame={{ maxWidth: "infinity" }}>
                <Image systemName="calendar" font={10} foregroundStyle={ACCENT} />
                <Text font="caption2" foregroundStyle="secondaryLabel">
                  本月已用
                </Text>
                <Spacer />
              </HStack>
              <Text font="headline" fontWeight="semibold" monospacedDigit foregroundStyle="label" lineLimit={1} minScaleFactor={0.7} frame={{ maxWidth: "infinity", alignment: "leading" }}>
                {fmtMb(monthUsedMb)}
              </Text>
              <HStack spacing={6} frame={{ maxWidth: "infinity" }}>
                <HStack spacing={2}>
                  <Image systemName="arrow.down" font={9} foregroundStyle={OK} />
                  <Text font={10} foregroundStyle={OK} lineLimit={1} minScaleFactor={0.7} allowsTightening>
                    {fmtMb(snap?.monthRxMb ?? null)}
                  </Text>
                </HStack>
                <HStack spacing={2}>
                  <Image systemName="arrow.up" font={9} foregroundStyle={ACCENT} />
                  <Text font={10} foregroundStyle={ACCENT} lineLimit={1} minScaleFactor={0.7} allowsTightening>
                    {fmtMb(snap?.monthTxMb ?? null)}
                  </Text>
                </HStack>
                <Spacer />
              </HStack>
            </Card>
          </HStack>
        </Card>

        {/* ④ CPU / 内存 */}
        <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
          <MiniCard
            icon="cpu"
            color={ACCENT}
            label="CPU 占用率"
            value={cpu !== null ? `${cpu.toFixed(0)}%` : "—"}
            meter={cpu !== null ? cpu / 100 : 0}
          />
          <MiniCard
            icon="memorychip"
            color={PURPLE}
            label="内存占用率"
            value={ram !== null ? `${ram.toFixed(0)}%` : "—"}
            meter={ram !== null ? ram / 100 : 0}
          />
        </HStack>

        {/* ⑤ 在线设备 */}
        <Card padding={{ horizontal: 10, vertical: 10 }} spacing={0}>
          <HStack spacing={7} alignment="center" frame={{ maxWidth: "infinity" }}>
            <Image systemName="wifi" font={12} foregroundStyle={OK} />
            <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
              <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1}>
                Wi-Fi 连接设备
              </Text>
              <Text font="caption2" foregroundStyle="tertiaryLabel" lineLimit={1}>
                {`绑定的 ${devices.length} 台 · ${online ? "在线" : "离线"}`}
              </Text>
            </VStack>
            <Text font="headline" fontWeight="semibold" monospacedDigit foregroundStyle="label" lineLimit={1}>
              {snap ? `${snap.onlineDevices} 台` : "—"}
            </Text>
          </HStack>
        </Card>

        <Text font="caption2" foregroundStyle="tertiaryLabel" frame={{ maxWidth: "infinity", alignment: "center" }}>
          {`运行 ${fmtUptime(snap?.uptimeSec ?? null)} · ${snap?.fw ? `固件 ${snap.fw} · ` : ""}${snap ? `更新于 ${new Date(snap.at).toLocaleTimeString("zh-CN", { hour12: false })}` : "下拉刷新"}`}
        </Text>
      </VStack>
      </ScrollView>

      {/* 添加新的绑定设备：直接在页面内全屏覆盖。
          不用 fullScreenCover / NavigationStack —— 模态在设备列表刷新时会自己重新呈现，
          导致「点完成 → 回首页 → 又弹回绑定页」；覆盖层是纯视图，没有呈现状态机，不可能反弹。 */}
      {adding ? (
        <VStack
          frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
          background="systemGroupedBackground"
        >
          <BindPage
            key={`bind-${bindRound}`}
            session={session}
            onBack={() => setAdding(false)}
            onBound={(list) => {
              const last = list[list.length - 1]
              if (last?.mac) {
                setActiveMac(last.mac)
                setSnap(null)
                try {
                  Storage.set(ACTIVE_MAC_KEY, last.mac)
                } catch {}
              }
              // 先关覆盖层，再让上层刷新设备列表（顺序反了会触发重新呈现）
              setAdding(false)
              props.onDevices(list)
            }}
          />
        </VStack>
      ) : null}
    </ZStack>
  )
}
