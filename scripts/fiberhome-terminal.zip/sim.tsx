// ---------- SIM 卡信息（GET_SIM_INFO，只读） ----------

import { useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { ACCENT, Group, NoticeRow, OK, Row, SettingsPage } from "./lib/settings"

const OPERATOR: Record<string, string> = {
  UNICOM: "中国联通",
  CMCC: "中国移动",
  CTCC: "中国电信",
  CBN: "中国广电",
}

/** SIM 的 NetMode 与 GET_MOBILE_NETWORK 的 NetworkMode 不同码：3=5G / 2=4G / 1=3G / 0=无 */
function netModeText(v: string): string {
  switch (v) {
    case "3":
      return "5G"
    case "2":
      return "4G"
    case "1":
      return "3G"
    case "0":
      return "无服务"
    default:
      return v ? `未知(${v})` : "—"
  }
}

export default function SimPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices[0]

  const [sim, setSim] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  async function load() {
    if (!device?.mac || !session.token) return
    setLoading(true)
    setError("")
    const r = await invokeService<any>(device.mac, session.token, "GET_SIM_INFO", {}, 8)
    setLoading(false)
    if (r.ok) {
      setSim(r.data)
    } else {
      setError(`${r.error ?? "读取失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
    }
  }
  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  const state = String(sim?.State ?? "")
  const reg = String(sim?.RegStatus ?? "")
  const op = String(sim?.Operator ?? "")

  return (
    <SettingsPage title="SIM 卡信息" refreshable={load}>
      {error ? (
        <Group>
          <NoticeRow kind="error" text={error} />
        </Group>
      ) : null}

      <Group header="状态">
        <Row
          label="SIM 卡状态"
          icon="simcard.fill"
          iconColor={state === "0" ? OK : "secondaryLabel"}
          value={state === "" ? "—" : state === "0" ? "正常" : `异常(${state})`}
          valueColor={state === "0" ? OK : "secondaryLabel"}
        />
        <Row
          label="注册状态"
          icon="checkmark.seal"
          iconColor={reg === "0" ? OK : "secondaryLabel"}
          value={reg === "" ? "—" : reg === "0" ? "注册成功" : `未注册(${reg})`}
          valueColor={reg === "0" ? OK : "secondaryLabel"}
        />
      </Group>

      <Group header="卡信息">
        <Row label="IMEI" icon="number" value={sim?.IMEI ?? "—"} mono />
        <Row label="IMSI" icon="creditcard" value={sim?.IMSI ?? "—"} mono />
        <Row label="网络模式" icon="cellularbars" iconColor={ACCENT} value={netModeText(String(sim?.NetMode ?? ""))} />
        <Row label="运营商" icon="building.2" value={OPERATOR[op] ?? (op || "—")} />
        <Row label="电话号码" icon="phone" value={sim?.PhoneNum || "—"} />
      </Group>
    </SettingsPage>
  )
}
