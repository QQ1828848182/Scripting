// ---------- 固件升级（对齐官方「固件升级」页）----------
// 版本来源：
//   设备端 HG_GET_UPDATE_STATUS（6.har 实测）→ FWVersion / FWDATA / HWVersion / up_status
//   云端 /operVersionManage/queryRouterVerInfo → routerVerInfos[0]（version / url / size(KB) / verMd5 / descriptions）
// 刷写：HG_IMAGE_UPDATE（2026-10-30 真机探测确认存在：空参回 {"Status":"1","FailReason":"json node null"}，
//   而假命令会原样回显报「命令未实现」，两者完全区分得开）。真实字段名未抓到，所以把 Url/MD5/Size/Version
//   的常见写法都带上，多余字段设备会忽略。安全阀：只有当前版本 ≠ 云端版本时才下发。

import { Image, ProgressView, Text, VStack, ZStack, useState, useEffect } from "scripting"
import type { DeviceInfo, RouterVersion, Session } from "./lib/api"
import { queryRouterVersion } from "./lib/api"
import { fetchUpdateStatus, type UpdateStatus } from "./lib/cmds"
import { invokeService, isEcho } from "./lib/invoke"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"
import { DialogButtons, GlassDialog, Overlay } from "./lib/pickers"
import { ACCENT, ButtonRow, Group, NoticeRow, Row, SettingsPage } from "./lib/settings"

const ORANGE = "#FF5F00"
const CARD_BG = "rgba(120,120,128,0.12)"

/** 固件升级三步（2026-10-30 真机验证）：
 *  ① HG_IMAGE_DOWNLOAD  —— 带云端 url/md5/size/version，设备自己去取镜像（会被接受，up_status 0→2）
 *  ② HG_GET_UPDATE_STATUS —— 轮询 up_status，等下载阶段结束（不再是 2）
 *  ③ HG_IMAGE_UPDATE    —— 让设备把已下好的镜像刷进去，随后自动重启
 *  直接先发 ③ 会被拒（FailReason: json node null，本地还没镜像）。
 */

function fmtSize(kb: number | null): string {
  if (kb === null) return "—"
  const mb = kb / 1024
  return mb >= 1024 ? `${(mb / 1024).toFixed(2)} GB` : `${mb.toFixed(1)} MB`
}

function sleep(ms: number) {
  return new Promise<void>(resolve => setTimeout(() => resolve(), ms))
}

/** up_status 含义（实测：下发下载后 0→1→2） */
function upStatusHint(s: string): string {
  if (s === "0") return "（空闲/结束）"
  if (s === "1") return "（已受理·准备中）"
  if (s === "2") return "（下载中）"
  return s ? "（进行中）" : ""
}

/** 秒 → 「1 分 20 秒」/「45 秒」 */
function fmtDur(sec: number): string {
  const s = Math.max(0, Math.round(sec))
  if (s < 60) return `${s} 秒`
  const m = Math.floor(s / 60)
  const r = s % 60
  if (m < 60) return r === 0 ? `${m} 分钟` : `${m} 分 ${r} 秒`
  const h = Math.floor(m / 60)
  return `${h} 小时 ${m % 60} 分`
}

type Phase = "idle" | "running" | "done"

export default function UpgradePage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices[0]

  const [list, setList] = useState<RouterVersion[]>([])
  const [dev, setDev] = useState<UpdateStatus | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [phase, setPhase] = useState<Phase>("idle")
  const [pct, setPct] = useState(0)
  /** 升级阶段：下载 → 刷写 → 等重启 */
  const [stage, setStage] = useState<"download" | "flash" | "wait">("download")
  /** 设备是否给了真实百分比（目前实测没有，只有 up_status） */
  const [pctReal, setPctReal] = useState(false)
  /** 开始时间 / 当前时间戳：设备不报进度，所以进度条与剩余时间按耗时估算 */
  const [startedAt, setStartedAt] = useState(0)
  const [now, setNow] = useState(0)
  /** 完成页的补充说明（如版本未变） */
  const [doneNote, setDoneNote] = useState("")
  /** 是否确认已刷入（版本变了，或刷写后设备连不上终端） */
  const [doneOk, setDoneOk] = useState(false)
  const [confirm, setConfirm] = useState(false)
  const [logs, setLogs] = useState<string[]>([])
  const [hint, setHint] = useState<Hint | null>(null)

  const current = dev?.fwVersion || device?.firmVersion || ""
  const latest = list[0]
  const newest = latest?.version || ""
  const isNewer = !!newest && !!current && newest !== current

  // ---- 耗时估算 ----
  // 设备不报下载百分比，按经验把一次升级估成 1 分钟（可按实测调整 EST_TOTAL_SEC）
  const EST_TOTAL_SEC = 60
  const estTotalSec = EST_TOTAL_SEC
  const elapsedSec = startedAt > 0 && now > startedAt ? (now - startedAt) / 1000 : 0
  const shownPct = pctReal ? pct : Math.min(95, (elapsedSec / estTotalSec) * 100)
  const remainSec = Math.max(0, estTotalSec - elapsedSec)
  const stageText = stage === "flash" ? "正在写入固件" : stage === "wait" ? "等待设备重启" : "正在下载固件"

  function push(line: string) {
    setLogs(prev => {
      const next = prev.concat(line)
      return next.length > 8 ? next.slice(next.length - 8) : next
    })
  }

  async function load(flash = false) {
    if (!device?.mac || !session.token) return
    setLoading(true)
    setError("")
    try {
      const st = await fetchUpdateStatus(device.mac, session.token)
      if (st.ok && st.data) setDev(st.data)
      const v = await queryRouterVersion(session, device.mac, device.model || "LG6851F")
      setList(v)
      if (flash) setHint({ text: "已刷新" })
    } catch (e: any) {
      setError(e?.message ?? String(e))
    }
    setLoading(false)
  }

  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  async function startUpgrade() {
    if (!device?.mac || !latest || phase === "running") return
    setConfirm(false)
    setPhase("running")
    setPct(0)
    setPctReal(false)
    setDoneOk(false)
    setDoneNote("")
    setError("")
    setLogs([])
    const baseVer = current
    push(`目标 ${latest.version}（${fmtSize(latest.size)}）`)

    const url = latest.url
    // 官方 App 的报文（7.har 实测）：只带 UpdateUrl + AreaCode，没有 md5/size/version
    const dlParam: Record<string, any> = {
      UpdateUrl: url,
      AreaCode: dev?.areaCode || "COMMON_Trunk",
    }
    const dlKeys = Object.keys(dlParam)

    // ---- ① HG_IMAGE_DOWNLOAD：让设备自己去取镜像 ----
    setStage("download")
    push("① 下发 HG_IMAGE_DOWNLOAD")
    const dl = await invokeService<any>(device.mac, session.token, "HG_IMAGE_DOWNLOAD", dlParam, 60)
    if (!dl.ok) {
      const reason = String((dl.data as any)?.FailReason ?? "")
      push(`✗ 下载命令被拒：${dl.error ?? "失败"}${reason ? `（${reason}）` : ""}`)
      setPhase("idle")
      setError("设备没有接受 HG_IMAGE_DOWNLOAD。")
      setHint({ text: "下载命令被拒", ok: false })
      return
    }
    if (isEcho(dl.data, "HG_IMAGE_DOWNLOAD", dlKeys)) {
      push("✗ 设备不认识 HG_IMAGE_DOWNLOAD")
      setPhase("idle")
      setError("设备不认识 HG_IMAGE_DOWNLOAD。")
      return
    }
    push("✓ 下载已启动")

    // 轮询：设备不提供下载百分比（HG_GET_UPDATE_STATUS 只有 up_status），
    // 所以进度条与剩余时间按耗时估算，真正判完成看两项：FWVersion 变了，或 up_status 从非 0 回到 0。
    const t0 = Date.now()
    setStartedAt(t0)
    setNow(t0)

    // 3 秒一次状态请求，但每 1 秒刷新一次计时
    const tick3 = async () => {
      for (let k = 0; k < 3; k++) {
        await sleep(1000)
        setNow(Date.now())
      }
    }

    // ---- ② HG_GET_UPDATE_STATUS：等下载阶段结束 ----
    push("② 轮询 HG_GET_UPDATE_STATUS 等下载完成")
    let sawDownloading = false
    let dlLastUp = ""
    let dlOffline = 0
    let downloaded = false
    let busyTicks = 0
    for (let i = 0; i < 240; i++) {
      await tick3()
      const st = await fetchUpdateStatus(device.mac, session.token)
      if (!st.ok || !st.data) {
        dlOffline++
        if (dlOffline === 3) push("状态读不到，继续等")
        continue
      }
      dlOffline = 0
      const d = st.data
      setDev(d)
      if (d.fwVersion && baseVer && d.fwVersion !== baseVer) {
        setPct(100)
        push(`固件已变为 ${d.fwVersion}（设备自己完成了刷写）`)
        setDoneOk(true)
        setDoneNote("")
        setPhase("done")
        return
      }
      if (d.upStatus !== dlLastUp) {
        dlLastUp = d.upStatus
        push(`up_status=${d.upStatus || "—"}${upStatusHint(d.upStatus)}`)
      }
      // 2 = 下载中。1 只是「已受理/准备中」，不能当结束
      if (d.upStatus === "2") {
        sawDownloading = true
        busyTicks++
      }
      if (sawDownloading && d.upStatus !== "2") {
        push("✓ 下载阶段结束")
        downloaded = true
        break
      }
      // 实测：镜像下完后 up_status 仍会停在 2 不走，所以只等 40 秒就开始下发第③步，
      // 没下完的话第③步会报错，交给后面的重试循环等它下完
      if (busyTicks >= 14) {
        push("up_status=2 已持续 40 秒，开始下发刷写（未下完会自动重试）")
        break
      }
      if (!sawDownloading && i >= 40) {
        push("等不到下载进行中（up_status 未到 2），不再空等")
        break
      }
    }
    if (!downloaded && sawDownloading === false) push("没等到下载结束信号，直接进入刷写")

    // ---- ③ HG_IMAGE_UPDATE：官方报文只有 {Update:"1"}（7.har 实测）----
    setStage("flash")
    push("③ 下发 HG_IMAGE_UPDATE {Update:1}")
    let flashed = false
    for (let k = 0; k < 30; k++) {
      const up = await invokeService<any>(device.mac, session.token, "HG_IMAGE_UPDATE", { Update: "1" }, 60)
      if (up.ok && !isEcho(up.data, "HG_IMAGE_UPDATE", ["Update"])) {
        push("✓ 刷写已触发，设备即将重启")
        flashed = true
        break
      }
      const reason = String((up.data as any)?.FailReason ?? "")
      const errText = String(up.error ?? "")
      push(`✗ 刷写未接受（第 ${k + 1} 次）：${errText || "失败"}${reason ? `（${reason}）` : ""}`)
      // 下发刷写后设备连不上终端（离线 / 响应超时 / 云端连不上）就说明它已经在重启刷写了 → 直接算完成
      const unreachable = errText.includes("离线") || errText.includes("超时") || errText.includes("连不上")
      if (unreachable) {
        push("设备已连不上终端 → 视为刷入完成，进度置 100%")
        setPctReal(false)
        setPct(100)
        setDoneOk(true)
        setDoneNote("已下发刷写命令，设备正在重启刷写（约 3–5 分钟）。重启回来后重新进入本页即可看到新版本。")
        setPhase("done")
        return
      }
      if (k < 29) {
        // 官方 App 也会在 up_status=2 时失败；镜像没下完就会报错，过一会再试
        await tick3()
        await sleep(17000)
        const st = await fetchUpdateStatus(device.mac, session.token)
        if (st.ok && st.data) {
          setDev(st.data)
          if (baseVer && st.data.fwVersion && st.data.fwVersion !== baseVer) {
            setPct(100)
            setDoneOk(true)
            setDoneNote("")
            setPhase("done")
            return
          }
        }
      }
    }

    // ---- 等设备重启并核对版本 ----
    if (!flashed) push("刷写命令没被接受，改为等设备自行刷写")
    setStage("wait")
    let offlineTicks = 0
    let sawBusy = false
    let lastUp = ""
    let idleTicks = 0
    for (let i = 0; i < 240; i++) {
      // 3 秒一次请求，但每 1 秒刷新一次计时，让「已用 / 预计还需」看着在走
      for (let k = 0; k < 3; k++) {
        await sleep(1000)
        setNow(Date.now())
      }
      const st = await fetchUpdateStatus(device.mac, session.token)
      if (!st.ok || !st.data) {
        offlineTicks++
        if (offlineTicks === 3) push("设备联系不上（正在重启）")
        continue
      }
      offlineTicks = 0
      const d = st.data
      setDev(d)

      if (d.fwVersion && baseVer && d.fwVersion !== baseVer) {
        setPct(100)
        push(`固件已变为 ${d.fwVersion}`)
        setDoneOk(true)
        setDoneNote("")
        setPhase("done")
        return
      }

      if (d.upStatus !== lastUp) {
        lastUp = d.upStatus
        push(`up_status=${d.upStatus || "—"}${upStatusHint(d.upStatus)}`)
      }
      if (d.upStatus && d.upStatus !== "0") sawBusy = true

      const real = Number(String(d.progress ?? "").replace(/[^\d.]/g, ""))
      if (Number.isFinite(real) && real > 0) {
        setPctReal(true)
        setPct(Math.min(99, Math.max(1, real)))
      }

      if (d.upStatus === "0") {
        idleTicks++
        // 至少见过一次忙状态，且连续 4 次空闲 → 算结束（设备重启后才会回到 0）
        if (sawBusy && idleTicks >= 4) {
          setPct(100)
          if (d.fwVersion && baseVer && d.fwVersion === baseVer) {
            push(`固件仍是 ${d.fwVersion}，可能只完成了下载`)
            setDoneNote("设备已处理完升级包，但版本号还没变——很可能正在重启刷写，等 2–3 分钟再看；若一直不变，可手动重启设备触发。")
          } else {
            push("升级流程结束")
            setDoneOk(true)
          }
          setPhase("done")
          return
        }
        // 一开始就一直空闲（命令没生效）→ 超时退出，避免卡死
        if (!sawBusy && i >= 20) {
          setPhase("idle")
          setError("设备没有开始下载（up_status 一直为 0），可能该固件包没被接受。")
          return
        }
      } else {
        idleTicks = 0
      }
    }
    setPhase("done")
  }

  async function copyInfo() {
    if (!latest) return
    const text = [
      `model: ${latest.model}`,
      `version: ${latest.version}`,
      `size: ${latest.size ?? ""} KB`,
      `md5: ${latest.verMd5}`,
      `url: ${latest.url}`,
      `descriptions: ${latest.descriptions}`,
    ].join("\n")
    await Pasteboard.setString(text)
    setHint({ text: "升级信息已复制" })
  }

  // ---------- 页面（对齐 iOS「软件更新」）----------
  const upToDate = !!current && !!newest && current === newest
  const timeLine =
    stage === "download"
      ? elapsedSec > estTotalSec
        ? `已用 ${fmtDur(elapsedSec)} · 已超过预估，设备仍在处理`
        : `已用 ${fmtDur(elapsedSec)} · 预计还需 ${fmtDur(remainSec)}`
      : `已用 ${fmtDur(elapsedSec)} · 设备重启期间可能短暂失联`

  if (phase === "done") {
    return (
      <SettingsPage title="固件更新">
        <Group>
          <Row
            content={
              <VStack alignment="center" spacing={10} frame={{ maxWidth: "infinity" }}>
                <Image
                  systemName={doneOk || upToDate ? "checkmark.circle.fill" : "arrow.triangle.2.circlepath"}
                  font={52}
                  foregroundStyle={doneOk || upToDate ? "#34C759" : ORANGE}
                />
                <Text font="headline" multilineTextAlignment="center">
                  {doneOk ? "刷写完成，设备正在重启" : upToDate ? "已是最新版本" : "升级流程已结束"}
                </Text>
                <Text font="footnote" foregroundStyle="secondaryLabel" multilineTextAlignment="center">
                  {current ? `当前固件 ${current}` : "正在重新读取版本…"}
                </Text>
                {doneNote ? (
                  <Text font="caption" foregroundStyle={ORANGE} multilineTextAlignment="center">
                    {doneNote}
                  </Text>
                ) : null}
              </VStack>
            }
          />
        </Group>
        <Group footer="若升级成功，路由器会自动重启，重启后需要重新连接 Wi-Fi。">
          <Row label="当前版本" value={current || "—"} mono />
          <Row label="最新版本" value={newest || "—"} mono />
        </Group>
        <Group>
          <ButtonRow
            title="完成"
            onTap={() => {
              setPhase("idle")
              setPct(0)
              load(true)
            }}
          />
        </Group>
      </SettingsPage>
    )
  }

  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      <SettingsPage
        title="固件更新"
        refreshable={async () => {
          await load(true)
        }}
        toast={hintToast(hint, () => setHint(null))}
      >
        {/* 版本信息（最上面） */}
        <Group header="版本信息">
          <Row label="当前版本" value={current || "—"} mono />
          <Row label="最新版本" value={newest || "—"} mono />
          <Row label="升级包大小" value={fmtSize(latest?.size ?? null)} />
          {isNewer ? <Row label="预计用时" value={fmtDur(estTotalSec)} /> : null}
          {isNewer ? <Row label="复制升级信息" chevron onTap={copyInfo} /> : null}
        </Group>

        {error ? (
          <Group>
            <NoticeRow kind="error" text={error} />
          </Group>
        ) : null}

        {/* 主卡：版本 + 说明 + 操作按钮（与 iOS 软件更新一致） */}
        <Group
          footer={
            phase === "running"
              ? "升级过程中路由器会自动重启，网络会中断几分钟，请保持供电、不要断电。"
              : isNewer
                ? `将从 ${current || "—"} 升级到 ${newest}，升级时设备会自动重启。`
                : undefined
          }
        >
          <Row
            content={
              <VStack alignment="leading" spacing={8} frame={{ maxWidth: "infinity", alignment: "leading" }}>
                <Text font="title3" fontWeight="semibold">
                  {isNewer ? `固件 ${newest}` : current ? `固件 ${current}` : "固件版本"}
                </Text>
                <Text font="footnote" foregroundStyle="secondaryLabel">
                  {phase === "running" ? stageText : loading ? "正在检查更新…" : isNewer ? "可更新" : "已是最新版本"}
                </Text>

                {phase === "running" ? (
                  <VStack alignment="leading" spacing={6} frame={{ maxWidth: "infinity", alignment: "leading" }}>
                    <ProgressView value={shownPct} total={100} tint={ORANGE} />
                    <Text font="caption" foregroundStyle="secondaryLabel">
                      {`${Math.round(shownPct)}%${pctReal ? "" : "（按时间估算）"}`}
                    </Text>
                    <Text font="caption" foregroundStyle="secondaryLabel">
                      {timeLine}
                    </Text>
                  </VStack>
                ) : null}

                {phase !== "running" && latest ? (
                  <Text font="footnote" frame={{ maxWidth: "infinity", alignment: "leading" }}>
                    {latest.descriptions || "该版本未提供说明。"}
                  </Text>
                ) : null}

                {phase !== "running" && latest ? (
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    {`${fmtSize(latest.size)} · ${latest.uploadTime || "发布时间未知"}`}
                  </Text>
                ) : null}
              </VStack>
            }
          />

          {phase === "running" ? null : isNewer ? (
            <ButtonRow title="下载并安装" onTap={() => setConfirm(true)} />
          ) : (
            <ButtonRow title={loading ? "正在检查…" : "检查更新"} disabled={loading} onTap={() => load(true)} />
          )}
        </Group>

      </SettingsPage>

      {confirm ? (
        <Overlay onDismiss={() => setConfirm(false)}>
          <GlassDialog width={300}>
            <Text font="subheadline" fontWeight="semibold" foregroundStyle="label" frame={{ maxWidth: "infinity", alignment: "leading" }}>
              {"下载并安装"}
            </Text>
            <Text font="subheadline" foregroundStyle="label" frame={{ maxWidth: "infinity", alignment: "leading" }}>
              {`即将把固件从 ${current} 升级到 ${newest}。过程中设备会自动重启，网络会中断几分钟，请保持供电。`}
            </Text>
            <DialogButtons
              accent={ORANGE}
              doneTitle="安装"
              onCancel={() => setConfirm(false)}
              onDone={startUpgrade}
            />
          </GlassDialog>
        </Overlay>
      ) : null}
    </ZStack>
  )
}

