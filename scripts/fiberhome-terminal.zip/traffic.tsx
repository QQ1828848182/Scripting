// ---------- 蜂窝流量管理：当日 / 当月统计（真实数据，iOS 设置风格） ----------
// 数据源：GET_CELLULAR_TRAFFIC_INFO（单位 MB）
// 限流开关：SET_CELLULAR_TRAFFIC_INFO（已实测，带 month_start_day 可改统计起始日）
// 流量清零：CLEANUP_TAFFIC（无参，最早一直用这条）；失败回退 CALIBRATE_MONTH_TRAFFIC {traffic:"0"}
// 流量校准：CALIBRATE_MONTH_TRAFFIC {traffic:"KB"}（5.har 实测：字段名小写、值单位 KB，语义=把本月已用设成该值）
// 统计日期：SET_CELLULAR_TRAFFIC_INFO 带 month_start_day（抓包里只见到读，写属尝试+回读校验）

import { Canvas, HStack, Image, Spacer, Text, TextField, VStack, ZStack, useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"
import { Overlay, GlassDialog, DialogButtons } from "./lib/pickers"
import {
  ACCENT,
  ButtonRow,
  DANGER,
  Group,
  InputRow,
  NoticeRow,
  OK,
  PickerRow,
  Row,
  SettingsPage,
  SwitchRow,
} from "./lib/settings"

function num(v: any): number | null {
  if (v === null || v === undefined || v === "") return null
  const n = typeof v === "number" ? v : parseFloat(String(v))
  return Number.isFinite(n) ? n : null
}

function splitMb(mb: number | null): { value: string; unit: string } {
  if (mb === null || !Number.isFinite(mb)) return { value: "—", unit: "" }
  if (mb >= 1024) return { value: (mb / 1024).toFixed(2), unit: "GB" }
  return { value: mb.toFixed(mb < 10 ? 2 : 1), unit: "MB" }
}

function shortMb(mb: number | null): string {
  const s = splitMb(mb)
  return s.unit ? `${s.value} ${s.unit}` : "—"
}

/** MB → 输入框里的 GB 文字（去掉无意义的 .00） */
function mbToGbText(mb: number | null): string {
  if (mb === null || !Number.isFinite(mb) || mb <= 0) return ""
  const gb = mb / 1024
  return gb.toFixed(2).replace(/\.00$/, "").replace(/(\.\d)0$/, "$1")
}

/** 输入框的 GB 文字 → MB（设备存的是 MB） */
function gbTextToMb(text: string): number {
  const gb = Number(text)
  if (!Number.isFinite(gb) || gb <= 0) return 0
  return Math.round(gb * 1024)
}

/** 在返回体里找一个像"限额"的数字（MB） */
function findLimit(obj: any): number | null {
  if (!obj || typeof obj !== "object") return null
  for (const k of Object.keys(obj)) {
    const v = obj[k]
    if (typeof v === "object" && v !== null) {
      const deep = findLimit(v)
      if (deep !== null) return deep
      continue
    }
    if (!/(max|limit|total).*(flow|traffic)|(flow|traffic).*(max|limit)/i.test(k)) continue
    const n = num(v)
    if (n !== null && n > 0) return n
  }
  return null
}

function roundRectPath(ctx: any, x: number, y: number, w: number, h: number) {
  const r = Math.min(h / 2, w / 2)
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.lineTo(x + w - r, y)
  ctx.arc(x + w - r, y + r, r, -Math.PI / 2, Math.PI / 2)
  ctx.lineTo(x + r, y + h)
  ctx.arc(x + r, y + r, r, Math.PI / 2, (Math.PI * 3) / 2)
  ctx.closePath()
}

/** 进度条：底槽永远画出来，ratio 非法也不会变空白 */
function Bar(props: { ratio: number; color: any; height?: number }) {
  const h = props.height ?? 5
  const raw = props.ratio
  const r = Number.isFinite(raw) ? Math.max(0, Math.min(1, raw)) : 0
  return (
    <Canvas
      opaque={false}
      frame={{ maxWidth: "infinity", height: h }}
      draw={(ctx, size) => {
        const w = size.width
        ctx.fillStyle = "rgba(120,120,128,0.22)"
        roundRectPath(ctx, 0, 0, w, h)
        ctx.fill()
        if (r <= 0) return
        ctx.fillStyle = props.color
        roundRectPath(ctx, 0, 0, Math.max(h, w * r), h)
        ctx.fill()
      }}
    />
  )
}

/** "1" / 1 / true → true */
function flag(v: any): boolean {
  if (typeof v === "boolean") return v
  if (typeof v === "number") return v !== 0
  return /^(1|true|on|enable)$/i.test(String(v ?? "").trim())
}

export default function TrafficPage(props: {
  session: Session
  devices: DeviceInfo[]
  onBack: () => void
}) {
  const { session, devices } = props
  const device = devices?.[0]

  const [dayRx, setDayRx] = useState<number | null>(null)
  const [dayTx, setDayTx] = useState<number | null>(null)
  const [monRx, setMonRx] = useState<number | null>(null)
  const [monTx, setMonTx] = useState<number | null>(null)
  const [limitMb, setLimitMb] = useState<number | null>(null)
  const [dayLimitMb, setDayLimitMb] = useState<number | null>(null)
  const [monthOn, setMonthOn] = useState(false)
  const [dayOn, setDayOn] = useState(false)
  const [monthStartDay, setMonthStartDay] = useState<number | null>(null)
  const [monthGbText, setMonthGbText] = useState("")
  const [saving, setSaving] = useState(false)
  const [notice, setNotice] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [toastHint, setToastHint] = useState<Hint | null>(null)
  const [confirmClean, setConfirmClean] = useState(false)
  const [cleaning, setCleaning] = useState(false)
  // 月流量校准弹窗
  const [calibOpen, setCalibOpen] = useState(false)
  const [calibText, setCalibText] = useState("")
  const [calibUnit, setCalibUnit] = useState<"MB" | "GB">("MB")
  const [calibSaving, setCalibSaving] = useState(false)
  const [startBusy, setStartBusy] = useState(false)

  function flash(msg: string) {
    setNotice(msg)
    setTimeout(() => setNotice(""), 2800)
  }

  async function load() {
    if (!device?.mac || !session.token) return
    setLoading(true)
    setError("")
    const r = await invokeService<any>(device.mac, session.token, "GET_CELLULAR_TRAFFIC_INFO", {}, 8)
    setLoading(false)
    if (!r.ok) {
      setError(`${r.error ?? "读取失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
      return
    }
    const t = r.data ?? {}
    setDayRx(num(t.day_rx_traffic))
    setDayTx(num(t.day_tx_traffic))
    setMonRx(num(t.month_rx_traffic))
    setMonTx(num(t.month_tx_traffic))
    // 限额就在同一接口里。注意设备拼写是 limmit（双 m），两种都兼容
    setLimitMb(num(t.month_max_traffic) ?? findLimit(t))
    setDayLimitMb(num(t.day_max_traffic))
    setMonthOn(flag(t.month_limmit_enable ?? t.month_limit_enable))
    setDayOn(flag(t.day_limmit_enable ?? t.day_limit_enable))
    setMonthStartDay(num(t.month_start_day))
    const mm = num(t.month_max_traffic)
    if (mm !== null) setMonthGbText(mbToGbText(mm))
  }

  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  function needCmd(what: string) {
    flash(`${what}需要接口：抓到请求后即可开启`)
  }
  void needCmd

  /**
   * 写限额（实测：SET_CELLULAR_TRAFFIC_INFO，字段拼写带 limmit 双 m）
   */
  async function saveLimits(next: { dayOn?: boolean; dayMb?: number; monthOn?: boolean; monthMb?: number }) {
    if (!device?.mac || saving) return
    // 首次加载完成前不写（避免进页面误写）
    if (loading) return
    setSaving(true)
    setError("")
    const dOn = next.dayOn ?? dayOn
    const mOn = next.monthOn ?? monthOn
    const dMb = next.dayMb ?? (dayLimitMb && dayLimitMb > 0 ? dayLimitMb : 1024)
    const typedMb = gbTextToMb(monthGbText)
    const mMb =
      next.monthMb ??
      (limitMb && limitMb > 0 ? limitMb : Number.isFinite(typedMb) && typedMb > 0 ? typedMb : 0)
    // 上限为 0 时设备会把当月额度写成 0，进度条就变成空的——所以先拦住
    if (mOn && (!Number.isFinite(mMb) || mMb <= 0)) {
      setSaving(false)
      flash("请先填写每月流量最大值")
      setToastHint({ text: "缺少流量上限", ok: false })
      return
    }
    const param = {
      day_limmit_enable: dOn ? "1" : "0",
      day_max_traffic: String(Math.round(dMb)),
      month_limmit_enable: mOn ? "1" : "0",
      month_max_traffic: String(Math.round(mMb)),
    }
    const r = await invokeService<any>(device.mac, session.token, "SET_CELLULAR_TRAFFIC_INFO", param, 10)
    if (!r.ok) {
      setSaving(false)
      setError(`保存失败：${r.error ?? "未知"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
      setToastHint({ text: "设置失败", ok: false })
      return
    }
    // 乐观更新 + 回读校对
    setDayOn(dOn)
    setMonthOn(mOn)
    setDayLimitMb(dMb)
    setLimitMb(mMb)
    let ok = false
    for (let i = 0; i < 5; i++) {
      await new Promise<void>(res => setTimeout(res, 400))
      const c = await invokeService<any>(device.mac, session.token, "GET_CELLULAR_TRAFFIC_INFO", {}, 8)
      if (!c.ok) continue
      const t = c.data ?? {}
      const mOnBack = flag(t.month_limmit_enable ?? t.month_limit_enable)
      const dOnBack = flag(t.day_limmit_enable ?? t.day_limit_enable)
      setMonthOn(mOnBack)
      setDayOn(dOnBack)
      const mBack = num(t.month_max_traffic)
      setLimitMb(mBack)
      if (mBack !== null && mBack > 0) setMonthGbText(mbToGbText(mBack))
      setDayLimitMb(num(t.day_max_traffic))
      if (mOnBack === mOn && dOnBack === dOn) {
        ok = true
        break
      }
    }
    setSaving(false)
    if (!ok) flash("已下发，但回读未确认")
    setToastHint(ok ? { text: "设置成功" } : { text: "已下发，回读未确认", ok: false })
  }

  /**
   * 月流量校准（官方页面：输入「当月已使用流量」，保存后自动算作当月下载）
   * 实测报文：CALIBRATE_MONTH_TRAFFIC {traffic:"51200"} = 50MB（字段名小写，单位 KB）
   */
  function openCalib() {
    setCalibUnit("MB")
    setCalibText(monTotal !== null ? String(Math.round(monTotal * 10) / 10) : "")
    setCalibOpen(true)
  }

  async function saveCalib() {
    if (!device?.mac || calibSaving) return
    const n = Number(calibText)
    if (!Number.isFinite(n) || n < 0) {
      setToastHint({ text: "请填写数字", ok: false })
      return
    }
    const mb = calibUnit === "GB" ? n * 1024 : n
    const kb = String(Math.round(mb * 1024))
    setCalibSaving(true)
    const r = await invokeService<any>(device.mac, session.token, "CALIBRATE_MONTH_TRAFFIC", { traffic: kb }, 12)
    if (!r.ok) {
      setCalibSaving(false)
      setError(`校准失败：${r.error ?? "未知"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
      setToastHint({ text: "校准失败", ok: false })
      return
    }
    // 回读校对（校准后当月已用应该等于刚填的值）
    let got: number | null = null
    for (let i = 0; i < 5; i++) {
      await new Promise<void>(res => setTimeout(res, 500))
      got = await readMonTotal()
      if (got !== null && Math.abs(got - mb) <= 1.5) break
    }
    setCalibSaving(false)
    setCalibOpen(false)
    await load()
    if (got !== null && Math.abs(got - mb) <= 1.5) {
      flash(`已校准为 ${shortMb(got)}`)
      setToastHint({ text: "校准成功" })
    } else {
      flash(`已下发，但回读为 ${shortMb(got)}（可能设备未接受）`)
      setToastHint({ text: "已下发，回读不一致", ok: false })
    }
  }

  /**
   * 统计日期（每月从第几天开始算一个月）
   * 用 SET_CELLULAR_TRAFFIC_INFO 带 month_start_day；这条写没抓到包，所以靠回读确认
   */
  async function setStartDay(v: string) {
    const day = Number(v)
    if (!device?.mac || startBusy || !Number.isFinite(day)) return
    setStartBusy(true)
    const param: Record<string, any> = {
      day_limmit_enable: dayOn ? "1" : "0",
      day_max_traffic: String(Math.round(dayLimitMb ?? 1024)),
      month_limmit_enable: monthOn ? "1" : "0",
      month_max_traffic: String(Math.round(limitMb ?? 0)),
      month_start_day: String(day),
    }
    const r = await invokeService<any>(device.mac, session.token, "SET_CELLULAR_TRAFFIC_INFO", param, 10)
    if (!r.ok) {
      setStartBusy(false)
      setError(`统计日期保存失败：${r.error ?? "未知"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
      setToastHint({ text: "保存失败", ok: false })
      return
    }
    let back: number | null = null
    for (let i = 0; i < 5; i++) {
      await new Promise<void>(res => setTimeout(res, 400))
      const c = await invokeService<any>(device.mac, session.token, "GET_CELLULAR_TRAFFIC_INFO", {}, 8)
      if (!c.ok) continue
      back = num(c.data?.month_start_day)
      if (back === day) break
    }
    setStartBusy(false)
    setMonthStartDay(back)
    if (back === day) {
      flash(`统计日期已设为每月 ${day} 日`)
      setToastHint({ text: "设置成功" })
    } else {
      flash(`已下发，但回读仍是每月 ${back ?? "?"} 日`)
      setToastHint({ text: "已下发，回读未变化", ok: false })
    }
  }

  /** 读一次当月已用（MB），清零后用来校对 */
  async function readMonTotal(): Promise<number | null> {
    if (!device?.mac || !session.token) return null
    const c = await invokeService<any>(device.mac, session.token, "GET_CELLULAR_TRAFFIC_INFO", {}, 8)
    if (!c.ok) return null
    const t = c.data ?? {}
    const rx = num(t.month_rx_traffic)
    const tx = num(t.month_tx_traffic)
    if (rx === null && tx === null) return null
    return (rx ?? 0) + (tx ?? 0)
  }

  /**
   * 流量清零（双击确认）
   * 主用 CLEANUP_TAFFIC（无参，官方拼写错 TAFFIC）——一直用这条；
   * 失败时回退 CALIBRATE_MONTH_TRAFFIC {traffic:"0"}（5.har 实测字段：小写 traffic、值单位 KB）。
   */
  async function cleanup() {
    if (!device?.mac || cleaning) return
    setCleaning(true)
    setError("")
    const before = monTotal

    let used = "CLEANUP_TAFFIC"
    let r = await invokeService<any>(device.mac, session.token, "CLEANUP_TAFFIC", {}, 12)
    if (!r.ok) {
      const first = `${r.error ?? "失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`
      const r2 = await invokeService<any>(device.mac, session.token, "CALIBRATE_MONTH_TRAFFIC", { traffic: "0" }, 12)
      if (!r2.ok) {
        setCleaning(false)
        setError(`清零失败：CLEANUP_TAFFIC → ${first}；CALIBRATE_MONTH_TRAFFIC → ${r2.error ?? "失败"}`)
        setToastHint({ text: "清零失败", ok: false })
        return
      }
      r = r2
      used = "CALIBRATE_MONTH_TRAFFIC"
    }

    // 回读校对：最多 6 次 × 500ms
    let after: number | null = null
    for (let i = 0; i < 6; i++) {
      await new Promise<void>(res => setTimeout(res, 500))
      after = await readMonTotal()
      if (after !== null && (before === null || after < before)) break
    }
    setCleaning(false)
    await load()

    if (after !== null && (before === null || after < before)) {
      flash(`已清零（${used}）：${shortMb(before)} → ${shortMb(after)}`)
      setToastHint({ text: "流量已清零" })
    } else {
      flash(`已下发（${used}），但回读本月已用仍为 ${shortMb(after)}`)
      setToastHint({ text: "已下发，回读未变化", ok: false })
    }
  }

  const dayTotal = dayRx !== null || dayTx !== null ? (dayRx ?? 0) + (dayTx ?? 0) : null
  const monTotal = monRx !== null || monTx !== null ? (monRx ?? 0) + (monTx ?? 0) : null
  const day = splitMb(dayTotal)
  const mon = splitMb(monTotal)
  const monthLimitValid = limitMb !== null && limitMb > 0
  const monthRatio = monthLimitValid && limitMb ? (monTotal ?? 0) / limitMb : 0

  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
    <SettingsPage
      title="蜂窝流量管理"
      refreshable={load}
      toast={hintToast(toastHint, () => setToastHint(null))}
    >
      {error ? (
        <Group>
          <NoticeRow kind="error" text={error} />
        </Group>
      ) : null}

      {notice ? (
        <Group>
          <NoticeRow kind="info" text={notice} />
        </Group>
      ) : null}

      <Group header="当日流量">
        <Row
          content={
            <HStack spacing={12} frame={{ maxWidth: "infinity" }}>
              <VStack alignment="leading" spacing={2}>
                <Text font="caption2" foregroundStyle="secondaryLabel">
                  日总消耗
                </Text>
                <HStack spacing={4} alignment="bottom">
                  <Text font="title" fontWeight="bold" monospaced>
                    {day.value}
                  </Text>
                  <Text font="subheadline" foregroundStyle="secondaryLabel" padding={{ bottom: 3 }}>
                    {day.unit}
                  </Text>
                </HStack>
              </VStack>
              <Spacer />
              <VStack alignment="trailing" spacing={6}>
                <HStack spacing={5}>
                  <Image systemName="arrow.up" font="caption2" foregroundStyle={ACCENT} />
                  <Text font="footnote" foregroundStyle="secondaryLabel" monospaced>
                    {shortMb(dayTx)}
                  </Text>
                </HStack>
                <HStack spacing={5}>
                  <Image systemName="arrow.down" font="caption2" foregroundStyle={OK} />
                  <Text font="footnote" foregroundStyle="secondaryLabel" monospaced>
                    {shortMb(dayRx)}
                  </Text>
                </HStack>
              </VStack>
            </HStack>
          }
        />
        <SwitchRow label="每日限流" value={dayOn} onChanged={v => saveLimits({ dayOn: v })} />
      </Group>

      <Group
        header="当月流量"
        footer={`${monthStartDay !== null ? `每月 ${monthStartDay} 日重置 · ` : ""}当前 ${
          limitMb !== null ? shortMb(limitMb) : "—"
        }，超过上限则限制上网。`}
      >
        <Row
          content={
            <HStack spacing={12} frame={{ maxWidth: "infinity" }}>
              <VStack alignment="leading" spacing={2}>
                <Text font="caption2" foregroundStyle="secondaryLabel">
                  月总消耗
                </Text>
                <HStack spacing={4} alignment="bottom">
                  <Text font="title" fontWeight="bold" monospaced>
                    {mon.value}
                  </Text>
                  <Text font="subheadline" foregroundStyle="secondaryLabel" padding={{ bottom: 3 }}>
                    {mon.unit}
                  </Text>
                </HStack>
              </VStack>
              <Spacer />
              <VStack alignment="trailing" spacing={6}>
                <HStack spacing={5}>
                  <Image systemName="arrow.up" font="caption2" foregroundStyle={ACCENT} />
                  <Text font="footnote" foregroundStyle="secondaryLabel" monospaced>
                    {shortMb(monTx)}
                  </Text>
                </HStack>
                <HStack spacing={5}>
                  <Image systemName="arrow.down" font="caption2" foregroundStyle={OK} />
                  <Text font="footnote" foregroundStyle="secondaryLabel" monospaced>
                    {shortMb(monRx)}
                  </Text>
                </HStack>
              </VStack>
            </HStack>
          }
        />
        <Row
          content={
            <VStack spacing={6} frame={{ maxWidth: "infinity" }}>
              <Bar ratio={monthRatio} color={monthRatio > 0.9 ? DANGER : monthRatio > 0.7 ? ACCENT : OK} height={6} />
              <HStack>
                <Text font="caption2" foregroundStyle="tertiaryLabel">
                  {monthLimitValid ? `已用 ${Math.round(monthRatio * 100)}%` : "未设限额"}
                </Text>
                <Spacer />
                <Text font="caption2" foregroundStyle="tertiaryLabel">
                  {monthLimitValid ? `当月限流 ${shortMb(limitMb)}` : ""}
                </Text>
              </HStack>
            </VStack>
          }
        />
        <SwitchRow label="每月限流" value={monthOn} onChanged={v => saveLimits({ monthOn: v })} />
        <InputRow
          label="每月流量最大值"
          value={monthGbText}
          unit="GB"
          prompt="0"
          onChanged={v => {
            const clean = v.replace(/[^\d.]/g, "")
            const one = clean.indexOf(".")
            const fixed = one < 0 ? clean : clean.slice(0, one + 1) + clean.slice(one + 1).replace(/\./g, "")
            setMonthGbText(fixed)
          }}
        />
        <PickerRow
          label="统计日期"
          note="每月从这天开始统计（次月同日前截止）"
          value={monthStartDay !== null ? `每月 ${monthStartDay} 日` : "—"}
          selected={monthStartDay !== null ? String(monthStartDay) : undefined}
          options={Array.from({ length: 28 }, (_, i) => ({ value: String(i + 1), label: `每月 ${i + 1} 日` }))}
          onSelect={setStartDay}
          disabled={startBusy}
        />
        <Row
          label="流量校准"
          note="把当月已用改成实际值"
          value={monTotal !== null ? shortMb(monTotal) : "—"}
          chevron
          onTap={openCalib}
        />
      </Group>

      <Group>
        <ButtonRow
          title={saving ? "保存中…" : "保存限额"}
          busy={saving}
          onTap={() => saveLimits({ monthMb: gbTextToMb(monthGbText) })}
        />
      </Group>

      <Group header="维护">
        <ButtonRow
          title={cleaning ? "清零中…" : "流量清零"}
          destructive
          busy={cleaning}
          onTap={() => setConfirmClean(true)}
        />
      </Group>
    </SettingsPage>

    {confirmClean ? (
      <Overlay onDismiss={() => (cleaning ? null : setConfirmClean(false))}>
        <GlassDialog width={300}>
          <Text
            font="subheadline"
            foregroundStyle="label"
            frame={{ maxWidth: "infinity", alignment: "leading" }}
          >
            清零后，将无法恢复流量信息，确定清零吗？
          </Text>
          <DialogButtons
            accent={DANGER}
            doneTitle={cleaning ? "清零中…" : "确认"}
            onCancel={() => (cleaning ? null : setConfirmClean(false))}
            onDone={() => {
              setConfirmClean(false)
              cleanup()
            }}
          />
        </GlassDialog>
      </Overlay>
    ) : null}

    {calibOpen ? (
      <Overlay onDismiss={() => (calibSaving ? null : setCalibOpen(false))}>
        <GlassDialog width={300}>
          <Text font="subheadline" fontWeight="semibold" frame={{ maxWidth: "infinity", alignment: "leading" }}>
            月流量校准
          </Text>
          <Text font="caption" foregroundStyle="secondaryLabel" frame={{ maxWidth: "infinity", alignment: "leading" }}>
            填写「当月已使用流量」，校准后这个数值会算作当月下载消耗。
          </Text>
          <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
            <TextField
              title=""
              value={calibText}
              onChanged={v => {
                const clean = v.replace(/[^\d.]/g, "")
                const one = clean.indexOf(".")
                const fixed = one < 0 ? clean : clean.slice(0, one + 1) + clean.slice(one + 1).replace(/\./g, "")
                setCalibText(fixed)
              }}
              prompt="0"
              textFieldStyle="plain"
              padding={{ horizontal: 12, vertical: 10 }}
              frame={{ maxWidth: "infinity" }}
              background={{ style: "rgba(120,120,128,0.16)", shape: { type: "rect", cornerRadius: 10 } }}
            />
            {(["MB", "GB"] as const).map(u => (
              <Text
                key={u}
                font="footnote"
                fontWeight="semibold"
                foregroundStyle={calibUnit === u ? "white" : "secondaryLabel"}
                padding={{ horizontal: 10, vertical: 6 }}
                background={
                  calibUnit === u
                    ? { style: ACCENT, shape: "capsule" }
                    : { style: "rgba(120,120,128,0.16)", shape: "capsule" }
                }
                contentShape="rect"
                onTapGesture={() => setCalibUnit(u)}
              >
                {u}
              </Text>
            ))}
          </HStack>
          <DialogButtons
            accent={ACCENT}
            doneTitle={calibSaving ? "保存中…" : "保存"}
            onCancel={() => (calibSaving ? null : setCalibOpen(false))}
            onDone={saveCalib}
          />
        </GlassDialog>
      </Overlay>
    ) : null}
    </ZStack>
  )
}
