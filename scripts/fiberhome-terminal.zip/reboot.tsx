// ---------- 定时重启（iOS 设置风格） ----------
// 读 GET_HG_REBOOT_INFO / 写 SET_HG_REBOOT_INFO（已实测）
// 官方页面只有：定时重启开关、重启时间、重复；没有「仅一次」——OnlyOnce 固定回传 "0"。

import { Button, DatePicker, HStack, Image, Menu, Text, ZStack, useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"
import { ACCENT_WARM, Group, NoticeRow, PickerRow, Row, SettingsPage, SwitchRow } from "./lib/settings"

const GET_CMD = "GET_HG_REBOOT_INFO"
const SET_CMD = "SET_HG_REBOOT_INFO"

/** 官方顺序：周日 → 周六；协议里 1=周一 … 7=周日 */
const WEEK = [
  { d: "7", label: "周日" },
  { d: "1", label: "周一" },
  { d: "2", label: "周二" },
  { d: "3", label: "周三" },
  { d: "4", label: "周四" },
  { d: "5", label: "周五" },
  { d: "6", label: "周六" },
]

const pad2 = (s: string) => (s.length === 1 ? "0" + s : s)

export default function RebootPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices[0]

  const [on, setOn] = useState(false)
  const [days, setDays] = useState<string[]>([])
  const [time, setTime] = useState<number>(() => {
    const d = new Date()
    d.setHours(4, 40, 0, 0)
    return d.getTime()
  })

  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")
  const [notice, setNotice] = useState("")
  const [toastHint, setToastHint] = useState<Hint | null>(null)

  function toggleDay(d: string) {
    setDays(prev => (prev.includes(d) ? prev.filter(x => x !== d) : [...prev, d]))
  }

  function reset(d: any) {
    setOn(String(d?.GatewayRebootEnable ?? "0") === "1")
    setDays(
      String(d?.DaysOfWeek ?? "")
        .split(",")
        .map(s => s.trim())
        .filter(s => s !== "")
    )
    const base = new Date()
    base.setHours(Number(d?.Hour ?? 4), Number(d?.Minute ?? 0), 0, 0)
    setTime(base.getTime())
  }

  async function load() {
    if (!device?.mac || !session.token) return
    setLoading(true)
    setError("")
    const r = await invokeService<any>(device.mac, session.token, GET_CMD, { SequenceId: "reboot_q" }, 8)
    setLoading(false)
    if (r.ok) {
      reset(r.data)
    } else {
      setError(`${r.error ?? "读取失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
    }
  }
  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  async function save() {
    if (!device?.mac || saving) return
    if (on && days.length === 0) {
      setError("开启定时重启至少要选一天")
      return
    }
    setError("")
    setNotice("")
    setSaving(true)

    const d = new Date(time)
    const param = {
      SequenceId: "reboot_set",
      GatewayRebootEnable: on ? "1" : "0",
      DaysOfWeek: days.join(","),
      Hour: pad2(String(d.getHours())),
      Minute: pad2(String(d.getMinutes())),
      OnlyOnce: "0", // 官方页面没有这个选项，固定 0
    }
    const r = await invokeService<any>(device.mac, session.token, SET_CMD, param, 10)
    if (!r.ok) {
      setSaving(false)
      setError(`保存失败：${r.error ?? "未知"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
      setToastHint({ text: "设置失败", ok: false })
      return
    }

    let ok = false
    for (let i = 0; i < 5; i++) {
      await new Promise<void>(res => setTimeout(res, 400))
      const c = await invokeService<any>(device.mac, session.token, GET_CMD, { SequenceId: "reboot_q" }, 8)
      if (!c.ok) continue
      if (String(c.data?.Hour ?? "") === param.Hour && String(c.data?.Minute ?? "") === param.Minute) {
        reset(c.data)
        ok = true
        break
      }
    }
    setSaving(false)
    if (!ok) setNotice("已下发，但回读未确认")
    setToastHint(ok ? { text: "设置成功" } : { text: "已下发，回读未确认", ok: false })
    setTimeout(() => setNotice(""), 2500)
  }

  const daysText =
    days.length === 0 ? "未选择" : days.length === 7 ? "每天" : days.map(d => WEEK.find(w => w.d === d)?.label ?? d).join(" ")

  /** 重复周期的预设：全部 7 天 / 周一~周五 / 周六周日 / 其它=自定义 */
  const preset =
    days.length === 7
      ? "every"
      : days.length === 5 && ["1", "2", "3", "4", "5"].every(d => days.includes(d))
        ? "work"
        : days.length === 2 && ["6", "7"].every(d => days.includes(d))
          ? "weekend"
          : "custom"

  function applyPreset(v: string) {
    if (v === "every") setDays(WEEK.map(w => w.d))
    else if (v === "work") setDays(["1", "2", "3", "4", "5"])
    else if (v === "weekend") setDays(["6", "7"])
    else setDays([])
  }

  return (
    <ZStack
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      toolbar={{
        topBarTrailing: (
          <Button
            title={saving ? "保存中" : "保存"}
            action={() => {
              if (!saving && !loading) save()
            }}
            disabled={saving || loading}
          />
        ),
      }}
    >
      <SettingsPage
        title="定时重启"
        refreshable={load}
        toast={hintToast(toastHint, () => setToastHint(null))}
      >
        {error ? (
          <Group>
            <NoticeRow kind="error" text={error} />
          </Group>
        ) : null}

        {notice ? (
          <Group>
            <NoticeRow kind="ok" text={notice} />
          </Group>
        ) : null}

        <Group footer="开启后，设备将在设定的时间内自动重启。">
          <SwitchRow label="定时重启" value={on} onChanged={v => setOn(v)} />
        </Group>

        {on ? (
          <Group header="时间">
            <Row
              label="重启时间"
              trailing={
                <DatePicker
                  title=""
                  displayedComponents={["hourAndMinute"]}
                  datePickerStyle="compact"
                  value={time}
                  onChanged={v => setTime(v)}
                />
              }
            />
            <PickerRow
              label="重复"
              value={
                preset === "every"
                  ? "每天"
                  : preset === "work"
                    ? "工作日"
                    : preset === "weekend"
                      ? "周末"
                      : "自定义"
              }
              options={[
                { value: "every", label: "每天" },
                { value: "work", label: "工作日" },
                { value: "weekend", label: "周末" },
                { value: "custom", label: "自定义" },
              ]}
              selected={preset}
              onSelect={v => applyPreset(v)}
            />
            <Row
              label="生效日"
              trailing={
                <Menu
                  label={
                    <HStack spacing={3} contentShape="rect">
                      <Text foregroundStyle="secondaryLabel" lineLimit={1}>
                        {daysText}
                      </Text>
                      <Image
                        systemName="chevron.up.chevron.down"
                        font="caption2"
                        fontWeight="semibold"
                        foregroundStyle="tertiaryLabel"
                      />
                    </HStack>
                  }
                >
                  {WEEK.map(w => (
                    <Button
                      key={w.d}
                      title={`${days.includes(w.d) ? "✓ " : ""}${w.label}`}
                      action={() => toggleDay(w.d)}
                    />
                  ))}
                </Menu>
              }
            />
          </Group>
        ) : null}
      </SettingsPage>
    </ZStack>
  )
}
