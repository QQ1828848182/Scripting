// ---------- 烽火终端 · 远程控制台（Scripting / TSX + Liquid Glass） ----------
// 三页结构对齐官方 App：首页 / 工具箱 / 路由设置，最右侧多一个常驻的「退出」图标页签。
//
// 目录结构：
//   index.tsx       入口 / 页签容器
//   login.tsx       登录页
//   home.tsx        首页（设备总览 + 关闭退出）
//   toolbox.tsx     工具箱（官方功能宫格）
//   router.tsx      路由设置（设备设置 + 账号 + 退出登录）
//   lib/api.ts      接口层（登录、设备、用户信息）
//   lib/sha256.ts   纯 JS SHA-256
//   lib/config.ts   云端端点配置
//   lib/store.ts    Keychain 会话存储
//   lib/ui.tsx      液态玻璃组件

import {
  NavigationStack,
  TabView,
  Tab,
  Text,
  VStack,
  ZStack,
  Image,
  Spacer,
  useState,
  useEffect,
  useObservable,
  Script,
  Navigation,
} from "scripting"
import type { DynamicShapeStyle } from "scripting"

import { DeviceInfo, Session } from "./lib/api"
import { loadSession, clearSession } from "./lib/store"
import { glassStyle, fill } from "./lib/ui"

import LoginPage from "./login"
import { LoginResult } from "./login"
import HomePage from "./home"
import ToolboxPage from "./toolbox"
import RouterPage from "./router"

/** 退出页：内容只是空白占位（点底栏「退出」就会直接结束脚本） */
function ExitPage() {
  return <VStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }} background={pageBackground()} />
}

/** 抖音式的底栏：四个页签（首页 / 工具箱 / 路由设置 / 退出）在同一个胶囊里 */
function RootView() {
  const [session, setSession] = useState<Session | null>(loadSession())
  const [loginVisible, setLoginVisible] = useState(!loadSession())
  const [devices, setDevices] = useState<DeviceInfo[]>([])
  const [expired, setExpired] = useState(false)
  const tab = useObservable<string>("home")

  function handleLoginDone(r: LoginResult) {
    if ("session" in r) {
      setSession(r.session)
      setExpired(false)
      setLoginVisible(false)
    } else if ("cancelled" in r) {
      if (!session) Script.exit()
      setLoginVisible(false)
    } else {
      setLoginVisible(false)
    }
  }

  function handleLogout() {
    clearSession()
    setSession(null)
    setDevices([])
    setLoginVisible(true)
  }

  // 退出 App
  function exitApp() {
    Script.exit()
  }

  // 底栏「退出」页签：切过去就直接结束脚本（无二次确认）
  useEffect(() => {
    const listener = (v: string) => {
      if (v === "exit") Script.exit()
    }
    tab.subscribe(listener)
    return () => tab.unsubscribe(listener)
  }, [])

  function sessionExpired() {
    setExpired(true)
    setLoginVisible(true)
  }

  return (
    <NavigationStack>
      <ZStack
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        background={pageBackground()}
      >
        <TabView
          selection={tab}
          frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        >
          <Tab title="首页" systemImage="house.fill" value="home">
            {session ? (
              <HomePage
                session={session}
                devices={devices}
                onDevices={setDevices}
                onUnauthorized={sessionExpired}
                onExit={exitApp}
              />
            ) : (
              <EmptyState onLogin={() => setLoginVisible(true)} />
            )}
          </Tab>

          <Tab title="工具箱" systemImage="square.grid.2x2.fill" value="tools">
            {session ? (
              <ToolboxPage session={session} devices={devices} />
            ) : (
              <EmptyState onLogin={() => setLoginVisible(true)} />
            )}
          </Tab>

          <Tab title="路由设置" systemImage="gearshape.fill" value="router">
            {session ? (
              <RouterPage
                session={session}
                devices={devices}
                onDevices={setDevices}
                onLogout={handleLogout}
                onSessionExpired={sessionExpired}
              />
            ) : (
              <EmptyState onLogin={() => setLoginVisible(true)} />
            )}
          </Tab>

          <Tab title="退出" systemImage="power" value="exit">
            <ExitPage />
          </Tab>
        </TabView>
      </ZStack>

      {/* 登录以全屏模态呈现 */}
      <VStack
        fullScreenCover={{
          isPresented: loginVisible,
          onChanged: v => {
            setLoginVisible(v)
            if (!v && !session) Script.exit()
          },
          content: (
            <NavigationStack>
              <LoginPage
                onDone={handleLoginDone}
                initialError={expired ? "登录状态已失效，请重新登录" : undefined}
              />
            </NavigationStack>
          ),
        }}
      />
    </NavigationStack>
  )
}

function EmptyState(props: { onLogin: () => void }) {
  return (
    <VStack
      spacing={14}
      padding={{ horizontal: 30 }}
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
    >
      <Image
        systemName="wifi.router"
        font={44}
        foregroundStyle="tertiaryLabel"
      />
      <Text font="headline" foregroundStyle="secondaryLabel">
        尚未登录云端账号
      </Text>
      <Text font="footnote" foregroundStyle="tertiaryLabel" multilineTextAlignment="center">
        烽火终端仅支持远程登录，请使用账号密码或 Token 接入 home.mifon.com
      </Text>
      <Text
        font="headline"
        foregroundStyle="white"
        padding={{ horizontal: 22, vertical: 12 }}
        glassEffect={glassStyle({ cornerRadius: 14 })}
        background={fill("#0A84FF", 14)}
        contentShape={"rect"}
        onTapGesture={props.onLogin}
      >
        立即登录
      </Text>
    </VStack>
  )
}

function pageBackground(): DynamicShapeStyle {
  return {
    light: {
      gradient: [
        { color: "#EEF3FF", location: 0 },
        { color: "#F7F7FA", location: 0.55 },
        { color: "#EDF7F1", location: 1 },
      ],
      startPoint: { x: 0, y: 0 },
      endPoint: { x: 1, y: 1 },
    },
    dark: {
      gradient: [
        { color: "#0B1020", location: 0 },
        { color: "#12161F", location: 0.55 },
        { color: "#0A1418", location: 1 },
      ],
      startPoint: { x: 0, y: 0 },
      endPoint: { x: 1, y: 1 },
    },
  }
}

async function run() {
  await Navigation.present({
    element: <RootView />,
    modalPresentationStyle: "fullScreen",
  })
  Script.exit()
}

run()
