// ---------- 短信：会话列表 / 会话详情 / 发短信 ----------
// 命令（12.har 实测 + 探测确认）：
//   SMS_UPGRADE_MESSAGE  {}                          → recv_index_list / send_index_list（含 Isopened）
//   SMS_GET_MESSAGE      {...}                       → 正文；取正文时设备侧置为已读
//   SMS_DEL_MESSAGE_LIST {...}
//   SMS_SEND_MESSAGE     {Receiver, Msg, Encode}      ← Encode 必填
// 视觉：列表页/发送页用 iOS 设置分组；会话详情保留原生 iMessage 式气泡

import {
  Button,
  HStack,
  Image,
  ProgressView,
  RoundedRectangle,
  ScrollView,
  Spacer,
  Text,
  TextField,
  VStack,
  ZStack,
  useState,
  useEffect,
} from "scripting"
import type { Color } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import type { SmsMessage, SmsSlot } from "./lib/cmds"
import { deleteSmsMessages, fetchSmsIndex, fetchSmsMessages, markSmsRead, sendSms } from "./lib/cmds"
import { fill, capsuleFill, OK, ACCENT, ACCENT_WARM, DANGER, hintToast } from "./lib/ui"
import { ButtonRow, Group, NoticeRow, Row, SettingsPage } from "./lib/settings"

export type Conv = {
  peer: string
  list: SmsMessage[]
  last: SmsMessage | undefined
  unread: number
}

const WEEK = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"]

/** "2026/10/25 13:06:13" → Date（解析不了返回 null） */
function parseTs(t: string): Date | null {
  const m = /^(\d{4})\/(\d{1,2})\/(\d{1,2})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?/.exec(t)
  if (!m) return null
  return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4]), Number(m[5]), Number(m[6] ?? "0"))
}

/** "2026/10/25 13:06:13" → "10/25 13:06" */
function shortTime(t: string): string {
  const m = /^(\d{4})\/(\d{1,2})\/(\d{1,2})[ T](\d{1,2}):(\d{2})/.exec(t)
  if (!m) return t
  return `${m[2]}/${m[3]} ${m[4].padStart(2, "0")}:${m[5]}`
}

/** "2026/10/25 13:06:13" → "周日 13:06" */
function dayLabel(t: string): string {
  const d = parseTs(t)
  const m = /[ T](\d{1,2}):(\d{2})/.exec(t)
  const hm = m ? `${m[1].padStart(2, "0")}:${m[2]}` : ""
  return d ? `${WEEK[d.getDay()]} ${hm}` : t
}

function timeMs(t: string): number {
  const d = parseTs(t)
  return d ? d.getTime() : 0
}

function withReplyNumber(peer: string): string {
  return peer.replace(/^\+?86(?=1\d{10}$)/, "")
}

function msgKey(m: SmsMessage): string {
  return `${m.dir}${m.index}`
}

/** 拉全量短信（索引 + 正文）；取正文会把收件置为已读 */
async function loadMessages(mac: string, token: string): Promise<{
  ok: boolean
  error?: string
  list: SmsMessage[]
  recv: SmsSlot[]
  send: SmsSlot[]
}> {
  const idx = await fetchSmsIndex(mac, token)
  if (!idx.ok) return { ok: false, error: idx.error ?? "读取失败", list: [], recv: [], send: [] }
  const body = await fetchSmsMessages(mac, token, idx.recv, idx.send)
  if (!body.ok && body.error) return { ok: false, error: body.error, list: [], recv: idx.recv, send: idx.send }
  // 回读一次索引，对齐未读数
  const again = await fetchSmsIndex(mac, token)
  return {
    ok: true,
    list: body.list,
    recv: again.ok ? again.recv : idx.recv,
    send: again.ok ? again.send : idx.send,
  }
}

// ---------------- 小组件 ----------------

export function Chip(props: { text: string; systemName?: string; color?: Color; busy?: boolean; onTap: () => void }) {
  const c = props.color ?? ACCENT
  return (
    <HStack
      spacing={4}
      padding={{ horizontal: 11, vertical: 6 }}
      contentShape="rect"
      onTapGesture={props.onTap}
      glassEffect={true}
      background={capsuleFill(c, 0.16)}
    >
      {props.busy ? <ProgressView /> : null}
      {props.systemName ? <Image systemName={props.systemName} font="caption" foregroundStyle={c} /> : null}
      <Text font="footnote" fontWeight="semibold" foregroundStyle={c}>
        {props.text}
      </Text>
    </HStack>
  )
}

/** 消息气泡：收件靠左（玻璃灰），发件靠右（玻璃暖橙），带小尖角 */
export function Bubble(props: { m: SmsMessage; editing: boolean; selected: boolean; onTap: () => void }) {
  const { m, editing, selected, onTap } = props
  const send = m.dir === "send"
  const bubbleShape: any = send
    ? { type: "rect", cornerRadii: { topLeading: 16, topTrailing: 16, bottomLeading: 16, bottomTrailing: 4 } }
    : { type: "rect", cornerRadii: { topLeading: 16, topTrailing: 16, bottomTrailing: 16, bottomLeading: 4 } }
  const bubbleBg: any = send
    ? { style: { color: ACCENT_WARM, opacity: 0.9 }, shape: bubbleShape }
    : { style: "rgba(120,120,128,0.22)", shape: bubbleShape }
  return (
    <HStack spacing={8} frame={{ maxWidth: "infinity" }} contentShape="rect" onTapGesture={onTap}>
      {send ? <Spacer minLength={56} /> : null}
      {editing ? (
        <Image
          systemName={selected ? "checkmark.circle.fill" : "circle"}
          font={19}
          foregroundStyle={selected ? ACCENT : "tertiaryLabel"}
        />
      ) : null}
      <Text
        font="subheadline"
        foregroundStyle={send ? "white" : "label"}
        multilineTextAlignment={send ? "trailing" : "leading"}
        fixedSize={{ horizontal: false, vertical: true }}
        padding={{ horizontal: 14, vertical: 10 }}
        background={bubbleBg}
        overlay={{
          alignment: send ? "bottomTrailing" : "bottomLeading",
          content: (
            <RoundedRectangle
              cornerRadius={0.5}
              fill={send ? { color: ACCENT_WARM, opacity: 0.9 } : "rgba(120,120,128,0.22)"}
              frame={{ width: 11, height: 11 }}
              rotationEffect={45}
              offset={{ x: send ? 2 : -2, y: 3 }}
            />
          ),
        }}
      >
        {m.body || "（空白短信）"}
      </Text>
      {send ? null : <Spacer minLength={56} />}
    </HStack>
  )
}

// ---------------- 会话列表 ----------------

export default function SmsPage(props: {
  session: Session
  devices: DeviceInfo[]
  onBack: () => void
  onPush: (key: string) => void
}) {
  const { session, devices, onPush } = props
  const device = devices[0]

  const [messages, setMessages] = useState<SmsMessage[]>([])
  const [recvSlots, setRecvSlots] = useState<SmsSlot[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [hint, setHint] = useState("")
  const [editing, setEditing] = useState(false)
  const [sel, setSel] = useState<string[]>([])
  const [confirmDel, setConfirmDel] = useState(false)

  function flash(msg: string) {
    setHint(msg)
    setTimeout(() => setHint(""), 2600)
  }

  function resetEditing() {
    setEditing(false)
    setSel([])
    setConfirmDel(false)
  }

  async function load() {
    if (!device?.mac || !session.token) return
    setLoading(true)
    setError("")
    const r = await loadMessages(device.mac, session.token)
    setLoading(false)
    if (!r.ok) {
      setError(r.error ?? "读取失败")
      return
    }
    setMessages(r.list)
    setRecvSlots(r.recv)
  }

  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  // 按号码归并成会话（+86 前缀归一到同一会话）
  const buckets: Record<string, SmsMessage[]> = {}
  for (const m of messages) {
    const key = withReplyNumber(m.peer)
    if (!buckets[key]) buckets[key] = []
    buckets[key].push(m)
  }
  const convs: Conv[] = Object.keys(buckets).map(p => {
    const sorted = [...buckets[p]].sort((a, b) => timeMs(a.time) - timeMs(b.time))
    return {
      peer: p,
      list: sorted,
      last: sorted[sorted.length - 1],
      unread: sorted.filter(m => m.dir === "recv" && !m.opened).length,
    }
  })
  convs.sort((a, b) => timeMs(b.last?.time ?? "") - timeMs(a.last?.time ?? ""))
  const unreadTotal = convs.reduce((n, c) => n + c.unread, 0)

  async function deleteConversations() {
    if (!device?.mac || sel.length === 0) return
    if (!confirmDel) {
      setConfirmDel(true)
      setTimeout(() => setConfirmDel(false), 4000)
      return
    }
    const picked = messages.filter(m => sel.includes(withReplyNumber(m.peer)))
    setLoading(true)
    const r = await deleteSmsMessages(
      device.mac,
      session.token,
      picked.filter(m => m.dir === "recv").map(m => m.index),
      picked.filter(m => m.dir === "send").map(m => m.index)
    )
    setLoading(false)
    const count = sel.length
    resetEditing()
    if (!r.ok) {
      flash(`删除失败：${r.error ?? ""}`)
      return
    }
    setMessages(list => list.filter(m => !picked.includes(m)))
    flash(`已删除 ${count} 个会话`)
  }

  const toast = hintToast(hint ? { text: hint } : null, () => setHint(""))

  return (
    <ZStack
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      toolbar={{
        topBarTrailing: [
          <Button
            key="edit"
            title={editing ? "完成" : "编辑"}
            action={() => (editing ? resetEditing() : setEditing(true))}
          />,
          <Button
            key="compose"
            systemImage="square.and.pencil"
            title="写短信"
            action={() => onPush("smsCompose")}
          />,
        ],
      }}
    >
      <SettingsPage title="短信消息" toast={toast} refreshable={load}>
      {error ? (
        <Group>
          <NoticeRow kind="error" text={error} />
        </Group>
      ) : null}

      <Group
        header="会话"
        footer={`${convs.length} 个会话 · 收件 ${recvSlots.length} · 未读 ${unreadTotal}。发消息由设备 SIM 卡发出。`}
      >
        {convs.length === 0 ? (
          <Row label={loading ? "正在读取…" : "设备上没有短信记录"} icon="tray" spinner={loading} />
        ) : (
          convs.map(c => (
            <Row
              key={c.peer}
              icon={c.unread > 0 ? "message.badge.fill" : "message"}
              iconColor={c.unread > 0 ? ACCENT : "secondaryLabel"}
              label={withReplyNumber(c.peer)}
              note={c.last?.body || "（空白短信）"}
              value={
                (c.unread > 0 ? `${c.unread} · ` : "") + shortTime(c.last?.time ?? "")
              }
              valueColor={c.unread > 0 ? DANGER : "secondaryLabel"}
              selected={editing ? sel.includes(c.peer) : undefined}
              chevron={!editing}
              onTap={() => {
                if (editing) {
                  setSel(s => (s.includes(c.peer) ? s.filter(x => x !== c.peer) : [...s, c.peer]))
                  return
                }
                onPush(`smsChat:${encodeURIComponent(c.peer)}`)
              }}
            />
          ))
        )}
      </Group>

      {editing ? (
        <Group footer={sel.length === 0 ? "先选择要删除的会话" : `已选 ${sel.length} 个会话`}>
          <Row
            label={sel.length === convs.length ? "取消全选" : "全选"}
            onTap={() => setSel(sel.length === convs.length ? [] : convs.map(c => c.peer))}
          />
          <ButtonRow
            title={confirmDel ? "确认删除" : `删除${sel.length > 0 ? `（${sel.length}）` : ""}`}
            destructive
            disabled={sel.length === 0}
            onTap={deleteConversations}
          />
        </Group>
      ) : null}
      </SettingsPage>
    </ZStack>
  )
}

// ---------------- 会话详情（iMessage 式气泡） ----------------

export function SmsChatPage(props: { session: Session; devices: DeviceInfo[]; peer: string; onBack: () => void }) {
  const { session, devices, peer } = props
  const device = devices[0]

  const [messages, setMessages] = useState<SmsMessage[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [hint, setHint] = useState("")
  const [editing, setEditing] = useState(false)
  const [sel, setSel] = useState<string[]>([])
  const [confirmDel, setConfirmDel] = useState(false)
  const [draft, setDraft] = useState("")
  const [sending, setSending] = useState(false)

  function flash(msg: string) {
    setHint(msg)
    setTimeout(() => setHint(""), 2600)
  }

  async function load() {
    if (!device?.mac || !session.token) return
    setLoading(true)
    setError("")
    const r = await loadMessages(device.mac, session.token)
    setLoading(false)
    if (!r.ok) {
      setError(r.error ?? "读取失败")
      return
    }
    setMessages(r.list.filter(m => withReplyNumber(m.peer) === peer))
  }

  useEffect(() => {
    load()
  }, [device?.mac, session.token, peer])

  const list = [...messages].sort((a, b) => timeMs(a.time) - timeMs(b.time))

  async function deleteMessages() {
    if (!device?.mac || sel.length === 0) return
    if (!confirmDel) {
      setConfirmDel(true)
      setTimeout(() => setConfirmDel(false), 4000)
      return
    }
    const picked = messages.filter(m => sel.includes(msgKey(m)))
    setLoading(true)
    const r = await deleteSmsMessages(
      device.mac,
      session.token,
      picked.filter(m => m.dir === "recv").map(m => m.index),
      picked.filter(m => m.dir === "send").map(m => m.index)
    )
    setLoading(false)
    setEditing(false)
    setSel([])
    setConfirmDel(false)
    if (!r.ok) {
      flash(`删除失败：${r.error ?? ""}`)
      return
    }
    setMessages(list => list.filter(m => !picked.includes(m)))
    flash(`已删除 ${picked.length} 条`)
  }

  async function markRead() {
    if (!device?.mac) return
    const picked = messages.filter(m => m.dir === "recv" && (sel.length === 0 || sel.includes(msgKey(m))))
    if (!picked.length) {
      flash("没有可标记的接收短信")
      return
    }
    const r = await markSmsRead(device.mac, session.token, picked.map(m => m.index))
    if (!r.ok) {
      flash(`标记失败：${r.error ?? ""}`)
      return
    }
    flash(`已标记 ${picked.length} 条为已读`)
  }

  async function send() {
    if (!device?.mac || sending) return
    if (!draft.trim()) {
      flash("短信内容不能为空")
      return
    }
    setSending(true)
    const r = await sendSms(device.mac, session.token, peer, draft)
    setSending(false)
    if (!r.ok) {
      flash(`发送失败：${r.error ?? ""}`)
      return
    }
    setDraft("")
    flash("发送指令已下发")
    load()
  }

  const toast = hintToast(hint ? { text: hint } : null, () => setHint(""))

  return (
    <VStack
      spacing={0}
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      navigationTitle={peer}
      toolbar={{
        topBarTrailing: (
          <Button
            title={editing ? "完成" : "选择"}
            tint={editing ? ACCENT_WARM : ACCENT}
            action={() => {
              if (editing) {
                setEditing(false)
                setSel([])
              } else {
                setEditing(true)
              }
            }}
          />
        ),
      }}
    >
      <HStack spacing={8} padding={{ horizontal: 16, vertical: 6 }} frame={{ maxWidth: "infinity" }}>
        <VStack alignment="leading" spacing={1}>
          <Text font="headline" lineLimit={1}>
            {peer}
          </Text>
          <Text font="caption2" foregroundStyle="tertiaryLabel">
            {editing ? `已选 ${sel.length} 条` : `${list.length} 条${loading ? " · 刷新中" : ""}`}
          </Text>
        </VStack>
        <Spacer />
        {loading && !editing ? <ProgressView /> : null}
      </HStack>

      <ScrollView frame={{ maxWidth: "infinity", maxHeight: "infinity" }} toast={toast}>
        <VStack alignment="leading" spacing={14} padding={{ horizontal: 14, top: 8, bottom: 18 }} frame={{ maxWidth: "infinity" }}>
          {error ? (
            <HStack spacing={8} padding={12} frame={{ maxWidth: "infinity" }} background={fill(DANGER, 12, 0.12)}>
              <Image systemName="exclamationmark.triangle.fill" font="footnote" foregroundStyle={DANGER} />
              <Text font="footnote" foregroundStyle={DANGER} frame={{ maxWidth: "infinity", alignment: "leading" }}>
                {error}
              </Text>
            </HStack>
          ) : null}

          {list.map(m => {
            const key = msgKey(m)
            return (
              <VStack key={key} alignment="leading" spacing={6} frame={{ maxWidth: "infinity" }}>
                <HStack spacing={0} frame={{ maxWidth: "infinity" }}>
                  <Spacer />
                  <Text font="caption2" foregroundStyle="tertiaryLabel">
                    {dayLabel(m.time)}
                  </Text>
                  <Spacer />
                </HStack>
                <Bubble
                  m={m}
                  editing={editing}
                  selected={sel.includes(key)}
                  onTap={() => {
                    if (!editing) return
                    setSel(s => (s.includes(key) ? s.filter(x => x !== key) : [...s, key]))
                  }}
                />
              </VStack>
            )
          })}
        </VStack>
      </ScrollView>

      {editing ? (
        <HStack
          spacing={10}
          padding={{ horizontal: 16, vertical: 10 }}
          frame={{ maxWidth: "infinity" }}
          background={fill("rgba(120,120,128,0.10)", 0)}
        >
          <Text font="footnote" foregroundStyle="secondaryLabel">
            已选 {sel.length} 条
          </Text>
          <Spacer />
          <Chip text="标为已读" systemName="envelope.open" color={ACCENT} onTap={markRead} />
          <Chip
            text={confirmDel ? "确认删除" : `删除${sel.length > 0 ? `（${sel.length}）` : ""}`}
            systemName="trash"
            color={DANGER}
            onTap={deleteMessages}
          />
        </HStack>
      ) : (
        <HStack
          spacing={8}
          padding={{ horizontal: 12, vertical: 8 }}
          frame={{ maxWidth: "infinity" }}
          background={fill("rgba(120,120,128,0.10)", 0)}
        >
          <TextField
            title=""
            value={draft}
            onChanged={setDraft}
            prompt="请输入消息"
            textFieldStyle="plain"
            padding={{ horizontal: 12, vertical: 9 }}
            frame={{ maxWidth: "infinity" }}
            background={fill("rgba(120,120,128,0.18)", 10)}
          />
          <Text
            font="subheadline"
            fontWeight="semibold"
            foregroundStyle="white"
            padding={{ horizontal: 14, vertical: 9 }}
            background={fill(draft.trim() && !sending ? ACCENT_WARM : "rgba(120,120,128,0.45)", 10)}
            contentShape="rect"
            onTapGesture={send}
          >
            {sending ? "发送中…" : "发消息"}
          </Text>
        </HStack>
      )}
    </VStack>
  )
}

// ---------------- 发短信 ----------------

export function SmsComposePage(props: { session: Session; devices: DeviceInfo[]; onSent: (peer: string) => void }) {
  const { session, devices, onSent } = props
  const device = devices[0]

  const [to, setTo] = useState("")
  const [draft, setDraft] = useState("")
  const [sending, setSending] = useState(false)
  const [hint, setHint] = useState("")

  function flash(msg: string) {
    setHint(msg)
    setTimeout(() => setHint(""), 2600)
  }

  async function send() {
    if (!device?.mac || sending) return
    const number = to.trim()
    if (!number) {
      flash("请填写收件人号码")
      return
    }
    if (!draft.trim()) {
      flash("短信内容不能为空")
      return
    }
    setSending(true)
    const r = await sendSms(device.mac, session.token, number, draft)
    setSending(false)
    if (!r.ok) {
      flash(`发送失败：${r.error ?? ""}`)
      return
    }
    setDraft("")
    onSent(withReplyNumber(number))
  }

  const toast = hintToast(hint ? { text: hint } : null, () => setHint(""))

  return (
    <SettingsPage title="发短信" toast={toast}>
      <Group header="收件人" footer="由设备 SIM 卡发出。">
        <Row
          content={
            <HStack spacing={10} frame={{ maxWidth: "infinity" }}>
              <Image systemName="person.crop.circle" font={16} foregroundStyle="secondaryLabel" />
              <TextField
                title=""
                value={to}
                onChanged={setTo}
                prompt="手机号码"
                textFieldStyle="plain"
                frame={{ maxWidth: "infinity" }}
              />
            </HStack>
          }
        />
      </Group>

      <Group header="内容" footer={`${draft.length} 字`}>
        <Row
          content={
            <TextField
              title=""
              value={draft}
              onChanged={setDraft}
              prompt="短信内容"
              axis="vertical"
              lineLimit={{ min: 3, max: 8 }}
              textFieldStyle="plain"
              frame={{ maxWidth: "infinity" }}
            />
          }
        />
      </Group>

      <Group>
        <ButtonRow
          title={sending ? "发送中…" : "发消息"}
          busy={sending}
          disabled={!draft.trim() || !to.trim()}
          onTap={send}
        />
      </Group>
    </SettingsPage>
  )
}
