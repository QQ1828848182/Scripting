// ---------- 绑定设备（iOS 设置风格） ----------
// 手机连着 CPE 的 Wi-Fi 时自动发现设备并回填 MAC，填入家庭 ID 即可绑定。

import {
  HStack,
  Image,
  Text,
  VStack,
  useState,
  useEffect,
} from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { bindDevice, fetchBoundPhone, fetchDevices, fmtMac, friendlyName, renameDevice, resolveFamily } from "./lib/api"
import { LocalWebSession, discover } from "./lib/localWeb"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"
import { ACCENT, ButtonRow, Group, InputRow, NoticeRow, OK, Row, SettingsPage } from "./lib/settings"

export default function BindPage(props: {
  session: Session
  mac?: string
  onBack: () => void
  /** 原生导航推送时隐藏自带返回条，保留系统滑动返回 */
  hideBackBar?: boolean
  onBound: (list: DeviceInfo[]) => void
}) {
  const { session, onBack, onBound } = props

  const [mac, setMac] = useState(props.mac ?? "")
  const [familyId, setFamilyId] = useState("")
  const [familyName, setFamilyName] = useState("")
  const [busy, setBusy] = useState(false)
  const [hint, setHint] = useState<Hint | null>(null)
  const [phone, setPhone] = useState<string | null>(null)
  const [phoneLoading, setPhoneLoading] = useState(false)
  /** 绑定成功后先在本页显示结果，用户点「完成」才真正回上层 */
  const [boundMac, setBoundMac] = useState("")
  const [boundList, setBoundList] = useState<DeviceInfo[] | null>(null)

  // 局域网自动发现
  const [scanning, setScanning] = useState(true)
  const [host, setHost] = useState("")
  const [model, setModel] = useState("")

  const macOk = /^[0-9A-Fa-f]{12}$/.test(mac)

  async function scan() {
    setScanning(true)
    try {
      const found = await discover()
      if (!found) {
        setHost("")
        return
      }
      setHost(found.host)
      const s = new LocalWebSession(found.host)
      try {
        const info = await s.deviceInfo()
        if (info) {
          setModel(info.model)
          if (!props.mac && info.mac) setMac(info.mac)
        }
      } finally {
        s.dispose()
      }
    } finally {
      setScanning(false)
    }
  }

  useEffect(() => {
    scan()
    // 官方 App 绑新设备时用的是账号自己的家庭 ID，这里直接推出来填好
    resolveFamily(session)
      .then(f => {
        if (f.id) setFamilyId(prev => prev || f.id)
        if (f.name) setFamilyName(f.name)
      })
      .catch(() => {})
  }, [])

  async function queryPhone(target = mac) {
    if (!/^[0-9A-Fa-f]{12}$/.test(target) || phoneLoading) return
    setPhoneLoading(true)
    try {
      setPhone(await fetchBoundPhone(session, target))
    } catch {
      setPhone(null)
    } finally {
      setPhoneLoading(false)
    }
  }

  useEffect(() => {
    if (macOk) queryPhone(mac)
  }, [macOk])

  async function doBind(useMac: string, useFamily: string) {
    if (!/^[0-9A-Fa-f]{12}$/.test(useMac)) {
      setHint({ text: "MAC 需要 12 位十六进制", ok: false })
      return
    }
    if (!/^\d+$/.test(useFamily)) {
      setHint({ text: "家庭 ID 是纯数字", ok: false })
      return
    }
    setBusy(true)
    try {
      await bindDevice(session, useMac, useFamily)
      const name = friendlyName(model)
      if (name) {
        try {
          await renameDevice(session, useMac, name)
        } catch {
          /* 改名字失败不影响绑定 */
        }
      }
      setHint({ text: "绑定成功" })
      const { devices } = await fetchDevices(session)
      // 不在本页做任何导航：直接切到结果页，由用户点「完成」交给上层
      setBoundMac(useMac)
      setBoundList(devices)
    } catch (e: any) {
      setHint({ text: e?.message ?? "绑定失败", ok: false })
    } finally {
      setBusy(false)
    }
  }

  const discovered = !!host

  // 绑定成功：整页换成结果页，用户点「完成」才回上层
  if (boundList) {
    // 显示设备名称（绑定后已按型号改成友好名），拿不到再退回型号
    const boundDevice = boundList.find(d => d.mac === boundMac)
    const boundName = boundDevice?.name || boundDevice?.model || friendlyName(model) || model || "设备"
    return (
      <SettingsPage title="绑定设备">
        <Group>
          <Row
            content={
              <VStack alignment="center" spacing={10} frame={{ maxWidth: "infinity" }}>
                <Image systemName="checkmark.circle.fill" font={52} foregroundStyle={OK} />
                <Text font="headline" multilineTextAlignment="center">
                  绑定成功
                </Text>
                <Text font="footnote" foregroundStyle="secondaryLabel" multilineTextAlignment="center">
                  {`${boundName} 已加入账号，可在首页查看。`}
                </Text>
              </VStack>
            }
          />
        </Group>
        <Group>
          <ButtonRow title="完成" onTap={() => onBound(boundList)} />
        </Group>
      </SettingsPage>
    )
  }

  return (
    <SettingsPage title="绑定设备" toast={hintToast(hint, () => setHint(null))}>
      <Group footer="连上 CPE 的 Wi-Fi 后会自动发现设备；也可以手动填写 MAC。">
        <Row
          icon="wifi.router.fill"
          iconColor={ACCENT}
          label={discovered ? model || "FiberHome CPE" : "未发现局域网设备"}
          note={
            scanning
              ? "正在扫描同一 Wi-Fi 下的 CPE…"
              : discovered
                ? `${host}${macOk ? ` · ${fmtMac(mac)}` : ""}`
                : "请先连接到 CPE 的 Wi-Fi，或手动填写下面的 MAC"
          }
          spinner={scanning}
        />
        <ButtonRow title={scanning ? "扫描中…" : "重新扫描"} busy={scanning} onTap={scan} />
      </Group>

      <Group header="绑定信息">
        <InputRow
          label="设备 MAC"
          value={mac}
          prompt="例如 7430AF998A80"
          onChanged={v => setMac(v.replace(/[^0-9A-Fa-f]/g, "").toUpperCase().slice(0, 12))}
        />
        <InputRow
          label="家庭 ID"
          value={familyId}
          prompt="纯数字"
          onChanged={v => setFamilyId(v.replace(/[^\d]/g, ""))}
        />
        <Row
          label="校验"
          value={
            mac.length === 0
              ? "12 位十六进制"
              : macOk
                ? `将绑定 ${fmtMac(mac)}`
                : `还差 ${12 - mac.length} 位`
          }
        />
        {familyName ? <Row label="所属家庭" value={familyName} /> : null}
      </Group>

      <Group>
        <ButtonRow title={busy ? "绑定中…" : "绑定"} busy={busy} onTap={() => doBind(mac, familyId)} />
      </Group>

      <Group footer="查询这个 MAC 当前绑在哪个账号上（找回设备用）。">
        <ButtonRow
          title={phoneLoading ? "查询中…" : "查绑定手机号"}
          busy={phoneLoading}
          onTap={() => queryPhone()}
        />
      </Group>

      {phoneLoading || phone !== null ? (
        <Group>
          <NoticeRow
            kind={phoneLoading ? "info" : phone ? "ok" : "info"}
            text={
              phoneLoading
                ? "正在查询绑定信息…"
                : phone
                  ? `已绑定到 ${phone}`
                  : "该 MAC 目前未绑定任何账号"
            }
          />
        </Group>
      ) : null}

      {props.hideBackBar ? null : (
        <Group>
          <ButtonRow title="取消" destructive onTap={onBack} />
        </Group>
      )}
    </SettingsPage>
  )
}