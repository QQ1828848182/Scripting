// ---------- 桌面小组件：CPE 运行状态（布局与首页一致） ----------
// 沿用首页 home.tsx 的信息结构：
//   卡① 运营商图标 · 运营商 · 制式胶囊 · 频段 · 信号柱
//        签约下行 / 签约上行 / QCI 三块
//        RSRP / SINR / RSRQ 三列（带评价色 + 细进度条）
//   套餐流量：剩余 / 已用 / 细条 / 今日·本月两个小块
//   CPU / 内存 两个小卡 + 在线设备行
//
// 尺寸取舍：小号 = 卡①精简 + 本月已用 + 在线设备；中号 = 卡①；大号 = 卡① + 套餐流量 + 资源 + 在线设备
// 不显示实时网速（用户指定）。

import { HStack, Image, ProgressView, Spacer, Text, VStack, Widget, Script } from "scripting"
import type { WidgetFamily } from "scripting"
import { fetchDevices, fmtMac, isOnline } from "./lib/api"
import { brandOf } from "./lib/brand"
import { BrandMark } from "./lib/brandMark"
import { fetchSnapshot, fmtMb, levelColor, levelText, loadSnapshot, ratio, saveSnapshot, signalBars } from "./lib/deviceData"
import type { DeviceSnapshot } from "./lib/deviceData"
import { loadSession } from "./lib/store"
import { fill } from "./lib/ui"

const ACTIVE_MAC_KEY = "cpe.activeMac.v1"

const OK = "#30D158"
const ACCENT = "#0A84FF"
const WARM = "#FF9F0A"
const PURPLE = "#BF5AF2"
const DANGER = "#FF453A"

type Model = {
  loggedIn: boolean
  stale: boolean
  name: string
  online: boolean
  operator: string
  workMode: string
  band: string
  bars: number
  rsrp: number | null
  sinr: number | null
  rsrq: number | null
  qci: string
  pci: string
  arfcn: string
  ambrDownKbps: number | null
  ambrUpKbps: number | null
  monthRxMb: number | null
  monthTxMb: number | null
  dayRxMb: number | null
  dayTxMb: number | null
  monthMb: number | null
  dayMb: number | null
  limitMb: number | null
  limitOn: boolean
  cpuPct: number | null
  ramPct: number | null
  onlineDevices: number
  at: number
}

const EMPTY: Model = {
  loggedIn: false,
  stale: false,
  name: "烽火终端",
  online: false,
  operator: "",
  workMode: "",
  band: "",
  bars: 0,
  rsrp: null,
  sinr: null,
  rsrq: null,
  qci: "",
  pci: "",
  arfcn: "",
  ambrDownKbps: null,
  ambrUpKbps: null,
  monthRxMb: null,
  monthTxMb: null,
  dayRxMb: null,
  dayTxMb: null,
  monthMb: null,
  dayMb: null,
  limitMb: null,
  limitOn: false,
  cpuPct: null,
  ramPct: null,
  onlineDevices: 0,
  at: 0,
}

// ---------------- 与首页同款的小组件 ----------------

/** 卡片：半透明圆角底 + 内缩内容 */
function Card(props: { children?: any; padding?: number; spacing?: number; bg?: string; fill?: boolean }) {
  const padding = props.padding ?? 9
  const spacing = props.spacing ?? 6
  const bg = props.bg ?? "rgba(120,120,128,0.10)"
  return (
    <VStack
      alignment="leading"
      spacing={spacing}
      padding={padding}
      frame={props.fill ? { maxWidth: "infinity", maxHeight: "infinity" } : { maxWidth: "infinity" }}
      background={fill(bg, 16)}
    >
      {props.children}
    </VStack>
  )
}

/** 四格信号柱（首页同款比例） */
function Bars(props: { level: number; color?: string }) {
  const heights = [5, 7.5, 10, 12.5]
  return (
    <HStack spacing={2} alignment="bottom">
      {heights.map((h, i) => (
        <VStack
          key={String(i)}
          frame={{ width: 3, height: h }}
          background={i < props.level ? fill(props.color ?? OK, 1) : fill("rgba(120,120,128,0.32)", 1)}
        />
      ))}
    </HStack>
  )
}

/** 细进度条 */
function Meter(props: { value: number; color: string; height?: number }) {
  const r = Number.isFinite(props.value) ? Math.max(0, Math.min(1, props.value)) : 0
  return <ProgressView value={r * 100} total={100} tint={props.color as any} />
}

/** 小信息块：上标签、下数值（首页 InfoBox 同款） */
function InfoBox(props: { label: string; value: string }) {
  return (
    <VStack
      alignment="leading"
      spacing={1}
      padding={{ horizontal: 7, vertical: 5 }}
      frame={{ maxWidth: "infinity" }}
      background={fill("rgba(120,120,128,0.18)", 10)}
    >
      <Text font="caption2" foregroundStyle="label" lineLimit={1}>
        {props.label}
      </Text>
      <Text font="footnote" fontWeight="semibold" monospacedDigit lineLimit={1} minScaleFactor={0.65}>
        {props.value}
      </Text>
    </VStack>
  )
}

/** 信号三列里的一列（首页 SignalCol 同款：标签+评价 / 数值+单位 / 细条） */
function SignalCol(props: { label: string; value: number | null; unit: string; kind: "rsrp" | "sinr" | "rsrq" }) {
  const color = levelColor(props.kind, props.value)
  return (
    <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity" }}>
      <HStack spacing={4} frame={{ maxWidth: "infinity" }}>
        <Text font="caption2" foregroundStyle="label">
          {props.label}
        </Text>
        <Spacer />
        <Text font="caption2" foregroundStyle={color as any} lineLimit={1}>
          {levelText(props.kind, props.value)}
        </Text>
      </HStack>
      <HStack spacing={3} alignment="firstTextBaseline" frame={{ maxWidth: "infinity" }}>
        <Text font="subheadline" fontWeight="bold" monospacedDigit lineLimit={1} minScaleFactor={0.8}>
          {props.value !== null ? String(props.value) : "—"}
        </Text>
        <Text font="caption2" foregroundStyle="label" lineLimit={1}>
          {props.value !== null ? props.unit : ""}
        </Text>
        <Spacer />
      </HStack>
      <Meter value={ratio(props.kind, props.value)} color={color as any} />
    </VStack>
  )
}

/** 签约速率：kbps → 「1000 Mbps」 */
function ambrText(kbps: number | null): string {
  if (kbps === null || !Number.isFinite(kbps) || kbps <= 0) return "—"
  const mbps = kbps / 1024
  return mbps >= 100 ? `${Math.round(mbps)} Mbps` : `${mbps.toFixed(1)} Mbps`
}

/** 签约速率的纯数字（小号用）：1000 Mbps → 1000，200 Mbps → 200 */
function ambrNum(kbps: number | null): string {
  if (kbps === null || !Number.isFinite(kbps) || kbps <= 0) return "—"
  const mbps = kbps / 1024
  return mbps >= 100 ? `${Math.round(mbps)}` : mbps.toFixed(1)
}

/** 剩余一句话 */
function remainText(m: Model): string {
  if (!m.limitOn || m.limitMb === null || m.monthMb === null) return "—"
  return fmtMb(Math.max(0, m.limitMb - m.monthMb))
}

// ---------------- 卡①：运营商 + 信号 ----------------

function NetworkCard(props: { m: Model; compact?: boolean; fill?: boolean; boxed?: boolean }) {
  const m = props.m
  const brand = brandOf(m.operator)
  const compact = props.compact === true
  return (
    <Card
      padding={8}
      spacing={5}
      fill={props.fill}
      bg={props.boxed === false ? "rgba(0,0,0,0)" : undefined}
    >
      {/* 图标 · 运营商 · 制式 · 频段 · 信号柱 */}
      <HStack spacing={6} frame={{ maxWidth: "infinity" }}>
        {brand ? <BrandMark brand={brand} size={compact ? 20 : 26} /> : null}
        <Text font={compact ? "subheadline" : "headline"} fontWeight="bold" lineLimit={1} minScaleFactor={0.6}>
          {m.operator || m.name}
        </Text>
        <Text
          font="caption2"
          fontWeight="semibold"
          foregroundStyle="#FFFFFF"
          padding={{ horizontal: 4, vertical: 1 }}
          background={fill(ACCENT, 6)}
          lineLimit={1}
        >
          {m.workMode || "—"}
        </Text>
        {!compact ? (
          <Text font="caption2" fontWeight="semibold" foregroundStyle="label" lineLimit={1} minScaleFactor={0.7}>
            {m.band || "—"}
          </Text>
        ) : null}
        <Spacer />
        <Bars level={m.bars} />
      </HStack>

      {/* 签约下行 / 签约上行 / QCI */}
      <HStack spacing={5} frame={{ maxWidth: "infinity" }}>
        <InfoBox label="签约下行" value={ambrText(m.ambrDownKbps)} />
        <InfoBox label="签约上行" value={ambrText(m.ambrUpKbps)} />
        {!compact ? <InfoBox label="QCI" value={m.qci || "—"} /> : null}
      </HStack>

      {/* RSRP / SINR / RSRQ */}
      <HStack spacing={12} frame={{ maxWidth: "infinity" }}>
        <SignalCol label="RSRP" value={m.rsrp} unit="dBm" kind="rsrp" />
        <SignalCol label="SINR" value={m.sinr} unit="dB" kind="sinr" />
        {!compact ? <SignalCol label="RSRQ" value={m.rsrq} unit="dB" kind="rsrq" /> : null}
      </HStack>
    </Card>
  )
}

// ---------------- 套餐流量卡 ----------------

function TrafficCard(props: { m: Model }) {
  const m = props.m
  const limitValid = m.limitMb !== null && m.limitMb > 0
  const usedPct = limitValid && m.monthMb !== null ? Math.min(100, (m.monthMb / (m.limitMb as number)) * 100) : 0
  const barColor = usedPct > 90 ? DANGER : usedPct > 70 ? WARM : ACCENT
  return (
    <Card padding={8} spacing={5}>
      <HStack spacing={6} frame={{ maxWidth: "infinity" }}>
        <Image systemName="chart.bar.fill" font="caption2" foregroundStyle={ACCENT} widgetAccentedRenderingMode="accented" />
        <Text font="footnote" fontWeight="semibold">
          {"套餐流量"}
        </Text>
        <Spacer />
        <Text font="caption2" foregroundStyle="label" lineLimit={1}>
          {limitValid ? (m.limitOn ? "限额已开启" : "限额已关闭") : "未设限额"}
        </Text>
      </HStack>

      {/* 只有设了套餐限额才显示「剩余 / 已用 / 进度条」，没限额时省下高度 */}
      {limitValid ? (
        <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
          <Text font="caption2" foregroundStyle="label">
            {"剩余"}
          </Text>
          <Text font="footnote" fontWeight="bold" monospacedDigit lineLimit={1} minScaleFactor={0.7}>
            {remainText(m)}
          </Text>
          <Spacer />
          <Text font="caption2" foregroundStyle="label" lineLimit={1} minScaleFactor={0.7}>
            {`已用 ${fmtMb(m.monthMb)} / ${fmtMb(m.limitMb)}`}
          </Text>
        </HStack>
      ) : null}

      {limitValid ? <Meter value={usedPct / 100} color={barColor} /> : null}

      {/* 今日 / 本月 两个小块 */}
      <HStack spacing={6} frame={{ maxWidth: "infinity" }}>
        <TrafficBox icon="sun.max.fill" color={WARM} label="今日流量" total={m.dayMb} />
        <TrafficBox icon="calendar" color={ACCENT} label="本月已用" total={m.monthMb} />
      </HStack>
    </Card>
  )
}

function TrafficBox(props: { icon: string; color: string; label: string; total: number | null }) {
  return (
    <VStack
      alignment="leading"
      spacing={2}
      padding={6}
      frame={{ maxWidth: "infinity" }}
      background={fill("rgba(120,120,128,0.18)", 10)}
    >
      <HStack spacing={4} frame={{ maxWidth: "infinity" }}>
        <Image systemName={props.icon} font="caption2" foregroundStyle={props.color as any} widgetAccentedRenderingMode="accented" />
        <Text font="caption2" foregroundStyle="label" lineLimit={1}>
          {props.label}
        </Text>
        <Spacer />
      </HStack>
      <Text font="footnote" fontWeight="semibold" monospacedDigit lineLimit={1} minScaleFactor={0.7} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        {fmtMb(props.total)}
      </Text>
    </VStack>
  )
}

// ---------------- 资源与在线设备 ----------------

function MiniStat(props: { icon: string; color: string; label: string; pct: number | null; text?: string }) {
  return (
    <VStack
      alignment="leading"
      spacing={2}
      padding={7}
      frame={{ maxWidth: "infinity" }}
      background={fill("rgba(120,120,128,0.18)", 12)}
    >
      <HStack spacing={4} frame={{ maxWidth: "infinity" }}>
        <Image systemName={props.icon} font="caption2" foregroundStyle={props.color as any} widgetAccentedRenderingMode="accented" />
        <Text font="caption2" foregroundStyle="label" lineLimit={1}>
          {props.label}
        </Text>
        <Spacer />
      </HStack>
      <Text font="headline" fontWeight="bold" monospacedDigit lineLimit={1} minScaleFactor={0.7} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        {props.text !== undefined ? props.text : props.pct !== null ? `${props.pct.toFixed(0)}%` : "—"}
      </Text>
      {props.text === undefined ? <Meter value={props.pct !== null ? props.pct / 100 : 0} color={props.color} /> : null}
    </VStack>
  )
}

function DeviceRow(props: { m: Model }) {
  return (
    <HStack spacing={6} padding={{ horizontal: 9, vertical: 8 }} frame={{ maxWidth: "infinity" }} background={fill("rgba(120,120,128,0.18)", 12)}>
      <Image systemName="wifi" font="caption2" foregroundStyle={OK} widgetAccentedRenderingMode="accented" />
      <Text font="caption2" foregroundStyle="label" lineLimit={1}>
        {"Wi-Fi 连接设备"}
      </Text>
      <Spacer />
      <Text font="footnote" fontWeight="semibold" lineLimit={1}>
        {`${props.m.onlineDevices} 台`}
      </Text>
      <Text font="caption2" foregroundStyle="label" lineLimit={1}>
        {props.m.stale ? "缓存" : props.m.online ? "在线" : "离线"}
      </Text>
    </HStack>
  )
}

// ---------------- 三种尺寸 ----------------

function SmallWidget(props: { m: Model }) {
  const m = props.m
  const brand = brandOf(m.operator)
  const limitValid = m.limitMb !== null && m.limitMb > 0
  const usedPct = limitValid && m.monthMb !== null ? Math.min(100, (m.monthMb / (m.limitMb as number)) * 100) : 0
  return (
    <VStack
      alignment="leading"
      spacing={0}
      padding={13}
      frame={{ maxWidth: "infinity", maxHeight: "infinity", alignment: "topLeading" }}
      widgetBackground={{ light: "white", dark: "black" }}
    >
      {/* 小号不画底框：内容直接坐在小组件背景上，靠行均分填满 */}
      <VStack
        alignment="leading"
        spacing={9}
        frame={{ maxWidth: "infinity", maxHeight: "infinity", alignment: "topLeading" }}
      >
        <HStack spacing={5} frame={{ maxWidth: "infinity" }}>
          {brand ? <BrandMark brand={brand} size={18} /> : null}
          <Text font="caption" fontWeight="bold" lineLimit={1} minScaleFactor={0.55}>
            {m.operator || m.name}
          </Text>
          <Spacer />
          <Text font="caption2" foregroundStyle={m.stale ? WARM : m.online ? OK : "label"} lineLimit={1}>
            {m.stale ? "缓存" : m.online ? "在线" : "离线"}
          </Text>
        </HStack>

        <HStack spacing={5} frame={{ maxWidth: "infinity" }}>
          <Text
            font="caption2"
            fontWeight="semibold"
            foregroundStyle="#FFFFFF"
            padding={{ horizontal: 4, vertical: 1 }}
            background={fill(ACCENT, 5)}
            lineLimit={1}
            minScaleFactor={0.7}
          >
            {m.workMode || "—"}
          </Text>
          <Text font="caption2" fontWeight="semibold" foregroundStyle="label" lineLimit={1} minScaleFactor={0.7}>
            {m.band || "—"}
          </Text>
          <Spacer />
          <Bars level={m.bars} />
        </HStack>

        <Text font="caption2" fontWeight="semibold" monospacedDigit lineLimit={1} minScaleFactor={0.65}>
          {`签约 ${ambrNum(m.ambrDownKbps)} / ${ambrNum(m.ambrUpKbps)} Mbps`}
        </Text>

        <VStack alignment="leading" spacing={3} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <Text font="caption2" foregroundStyle="label" lineLimit={1}>
            {limitValid ? `本月已用 · 上限 ${fmtMb(m.limitMb)}` : "本月已用"}
          </Text>
          <Text font="title3" fontWeight="bold" monospacedDigit lineLimit={1} minScaleFactor={0.6}>
            {fmtMb(m.monthMb)}
          </Text>
          <Meter value={limitValid ? usedPct / 100 : 0} color={usedPct > 90 ? DANGER : usedPct > 70 ? WARM : ACCENT} />
        </VStack>

        <HStack spacing={5} frame={{ maxWidth: "infinity" }}>
          <Image systemName="wifi" font="caption2" foregroundStyle={OK} widgetAccentedRenderingMode="accented" />
          <Text font="caption2" foregroundStyle="label" lineLimit={1} minScaleFactor={0.75}>
            {"在线设备"}
          </Text>
          <Spacer />
          <Text font="caption2" fontWeight="semibold" lineLimit={1}>
            {`${m.onlineDevices} 台`}
          </Text>
        </HStack>
      </VStack>
    </VStack>
  )
}

function MediumWidget(props: { m: Model }) {
  return (
    <VStack
      alignment="leading"
      spacing={0}
      padding={11}
      frame={{ maxWidth: "infinity", maxHeight: "infinity", alignment: "topLeading" }}
      widgetBackground={{ light: "white", dark: "black" }}
    >
      <NetworkCard m={props.m} fill boxed={false} />
    </VStack>
  )
}

function LargeWidget(props: { m: Model }) {
  return (
    <VStack
      alignment="leading"
      spacing={0}
      padding={11}
      frame={{ maxWidth: "infinity", maxHeight: "infinity", alignment: "topLeading" }}
      widgetBackground={{ light: "white", dark: "black" }}
    >
      <VStack alignment="leading" spacing={7} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <NetworkCard m={props.m} />
        <TrafficCard m={props.m} />
        <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
          <MiniStat icon="cpu" color={ACCENT} label="CPU" pct={props.m.cpuPct} />
          <MiniStat icon="memorychip" color={PURPLE} label="内存" pct={props.m.ramPct} />
          <MiniStat icon="wifi" color={OK} label="Wi-Fi" pct={null} text={`${props.m.onlineDevices} 台`} />
        </HStack>
      </VStack>
    </VStack>
  )
}

function LoginWidget() {
  return (
    <VStack
      spacing={8}
      padding={14}
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      widgetBackground={{ light: "white", dark: "black" }}
    >
      <Image systemName="wifi.router.fill" font="title2" foregroundStyle={ACCENT} widgetAccentedRenderingMode="accented" />
      <Text font="footnote" fontWeight="semibold">
        {"未登录"}
      </Text>
      <Text font="caption2" foregroundStyle="label" multilineTextAlignment="center">
        {"用「烽火终端」登录一次，再回来刷新小组件"}
      </Text>
    </VStack>
  )
}

function Root(props: { m: Model; family: WidgetFamily }) {
  if (!props.m.loggedIn) return <LoginWidget />
  if (props.family === "systemSmall" || props.family === "accessoryRectangular") return <SmallWidget m={props.m} />
  if (props.family === "systemLarge" || props.family === "systemExtraLarge") return <LargeWidget m={props.m} />
  return <MediumWidget m={props.m} />
}

// ---------------- 数据 ----------------

function pctOf(s: string): number | null {
  const n = parseFloat(String(s ?? "").replace("%", ""))
  return Number.isFinite(n) ? n : null
}

function toModel(snap: DeviceSnapshot, name: string, online: boolean, stale: boolean): Model {
  const bars =
    snap.signalLevel !== null && snap.signalLevel !== undefined
      ? Math.round(Math.min(4, Math.max(0, snap.signalLevel)))
      : signalBars(snap.rsrp)
  const monthMb = snap.monthRxMb !== null && snap.monthTxMb !== null ? snap.monthRxMb + snap.monthTxMb : null
  const dayMb = snap.dayRxMb !== null && snap.dayTxMb !== null ? snap.dayRxMb + snap.dayTxMb : null
  return {
    loggedIn: true,
    stale,
    name,
    online,
    operator: snap.operator && snap.operator !== "—" ? snap.operator : "",
    workMode: snap.workMode && snap.workMode !== "—" ? snap.workMode : "",
    band: snap.band && snap.band !== "—" ? snap.band : "",
    bars,
    rsrp: snap.rsrp,
    sinr: snap.sinr,
    rsrq: snap.rsrq,
    qci: snap.qci && snap.qci !== "—" ? snap.qci : "",
    pci: snap.pci || "",
    arfcn: snap.arfcn || "",
    ambrDownKbps: snap.dlAmbrKbps,
    ambrUpKbps: snap.ulAmbrKbps,
    monthRxMb: snap.monthRxMb,
    monthTxMb: snap.monthTxMb,
    dayRxMb: snap.dayRxMb,
    dayTxMb: snap.dayTxMb,
    monthMb,
    dayMb,
    limitMb: snap.monthLimitMb,
    limitOn: snap.monthLimitOn === true,
    cpuPct: pctOf(snap.cpu),
    ramPct: pctOf(snap.ram),
    onlineDevices: snap.onlineDevices,
    at: snap.at,
  }
}

async function build(): Promise<Model> {
  const session = loadSession()
  const cached = loadSnapshot()

  if (!session) return { ...EMPTY, loggedIn: false }

  let name = "烽火终端"
  let online = false
  let mac = ""
  try {
    const { devices } = await fetchDevices(session)
    const saved = String(Storage.get(ACTIVE_MAC_KEY) ?? "")
    const d = devices.find(x => x.mac === saved) ?? devices[0]
    if (d) {
      mac = d.mac
      name = d.name || d.model || fmtMac(d.mac)
      online = isOnline(d)
    }
  } catch {
    /* 云端不通：继续用缓存 */
  }

  if (!mac) {
    return cached ? toModel(cached, name, false, true) : { ...EMPTY, loggedIn: true, name, online: false }
  }

  try {
    const r = await fetchSnapshot(mac, session.token)
    saveSnapshot(r.snapshot)
    return toModel(r.snapshot, name, online, false)
  } catch {
    return cached ? toModel(cached, name, online, true) : { ...EMPTY, loggedIn: true, name, online }
  }
}

const family = Widget.family

build()
  .then(m => {
    Widget.present(<Root m={m} family={family} />, {
      policy: "after",
      date: new Date(Date.now() + 15 * 60 * 1000),
    })
    Script.exit()
  })
  .catch(() => {
    Widget.present(<Root m={{ ...EMPTY }} family={family} />)
    Script.exit()
  })
