// ---------- 移动网络（入口，对齐官方四项目录） ----------
// SIM 卡信息            → GET_SIM_INFO
// 移动网络设置          → GET_/SET_MOBILE_NETWORK（读写）
// 载波聚合参数          → GET_CARRIER_AGGREGATION_INFO
// 射频信号参数          → GET_RF_SIGNAL_INFO

import type { DeviceInfo, Session } from "./lib/api"
import { ACCENT, Group, OK, Row, SettingsPage } from "./lib/settings"

type Sub = "sim" | "mnet" | "ca" | "rf"

const ITEMS: { key: Sub; label: string; desc: string; icon: string; color: any }[] = [
  { key: "sim", label: "SIM 卡信息", desc: "状态 / IMEI / IMSI / 号码", icon: "simcard.fill", color: OK },
  { key: "mnet", label: "移动网络设置", desc: "飞行模式 / 数据网络 / 制式", icon: "switch.2", color: ACCENT },
  { key: "ca", label: "载波聚合参数", desc: "上下行带宽 / MCS / ARFCN", icon: "square.3.layers.3d", color: "#FF9F0A" },
  { key: "rf", label: "射频信号参数", desc: "RSRP / SINR / 邻居小区", icon: "antenna.radiowaves.left.and.right", color: "#5E5CE6" },
]

export default function MobilePage(props: {
  session: Session
  devices: DeviceInfo[]
  onBack: () => void
  onPush: (key: string) => void
}) {
  const { onPush } = props

  return (
    <SettingsPage title="移动网络">
      <Group>
        {ITEMS.map(it => (
          <Row
            key={it.key}
            label={it.label}
            note={it.desc}
            icon={it.icon}
            iconColor={it.color}
            chevron
            onTap={() => onPush(it.key)}
          />
        ))}
      </Group>
    </SettingsPage>
  )
}
