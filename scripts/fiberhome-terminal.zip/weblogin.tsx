// ---------- 路由器管理密码（GET_WEB_LOGIN_INFO / SET_WEB_LOGIN_INFO，13.har 抓包确认写入字段） ----------
// 写入参数：{ Password, WebLoginType:"", Status:0, SequenceId:"weblogin_set" }
// 就是 192.168.8.1 网页版的登录密码；页面把当前密码预填进输入框，直接在原密码上改。

import {
  Button,
  HStack,
  Image,
  SecureField,
  Text,
  TextField,
  useState,
  useEffect,
  ZStack,
} from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"
import { ACCENT, Group, NoticeRow, Row, SettingsPage } from "./lib/settings"

export default function WebLoginPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices[0]

  const [cur, setCur] = useState<any>(null)
  const [pwd, setPwd] = useState("")
  const [loaded, setLoaded] = useState(false)
  const [reveal, setReveal] = useState(true)
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [hint, setHint] = useState("")
  const [toastHint, setToastHint] = useState<Hint | null>(null)

  async function load() {
    if (!device?.mac || !session.token) return
    setLoading(true)
    const r = await invokeService<any>(device.mac, session.token, "GET_WEB_LOGIN_INFO", {}, 10)
    setLoading(false)
    setLoaded(true)
    if (!r.ok) {
      setHint(`读取当前密码失败：${r.error ?? ""}（可以直接输入新密码保存）`)
      return
    }
    setCur(r.data ?? {})
    const p = String(r.data?.Password ?? "")
    if (p !== "") setPwd(p)
  }

  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  const current = String(cur?.Password ?? "")
  const dirty = loaded && pwd !== current

  async function save() {
    if (!device?.mac || saving) return
    const p = pwd.trim()
    if (p.length < 6) {
      setHint("密码至少 6 位")
      return
    }
    setSaving(true)
    setHint("")
    const r = await invokeService<any>(
      device.mac,
      session.token,
      "SET_WEB_LOGIN_INFO",
      {
        Password: p,
        WebLoginType: String(cur?.WebLoginType ?? ""),
        Status: 0,
        SequenceId: "weblogin_set",
      },
      15
    )
    setSaving(false)
    if (!r.ok) {
      setHint(`写入失败：${r.error ?? ""}`)
      setToastHint({ text: "设置失败", ok: false })
      return
    }
    const status = String(r.data?.Status ?? "")
    if (status !== "" && status !== "0") {
      setHint(`设备拒绝：${String(r.data?.FailReason ?? `Status=${status}`)}`)
      setToastHint({ text: "设置失败", ok: false })
      return
    }
    setToastHint({ text: "设置成功" })
    setCur({ ...(cur ?? {}), Password: p })
  }

  return (
    <ZStack
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      toolbar={{
        topBarTrailing: (
          <Button
            title={saving ? "保存中…" : "保存"}
            action={save}
            disabled={saving || loading || !dirty}
          />
        ),
      }}
    >
      <SettingsPage
        title="路由器管理密码"
        refreshable={load}
        toast={hintToast(toastHint, () => setToastHint(null))}
      >
      {hint ? (
        <Group>
          <NoticeRow kind="info" text={hint} />
        </Group>
      ) : null}

      <Group
        header="密码"
        footer={`登录 192.168.8.1 网页版用的密码，至少 6 位。当前${dirty ? "已修改但未保存" : "与设备一致"}。`}
      >
        <Row
          content={
            <HStack spacing={10} frame={{ maxWidth: "infinity" }}>
              <Text>密码</Text>
              {reveal ? (
                <TextField title="" value={pwd} onChanged={setPwd} prompt="至少 6 位" frame={{ maxWidth: "infinity" }} />
              ) : (
                <SecureField title="" value={pwd} onChanged={setPwd} prompt="至少 6 位" frame={{ maxWidth: "infinity" }} />
              )}
              <Image
                systemName={reveal ? "eye.slash" : "eye"}
                font="body"
                foregroundStyle={ACCENT}
                onTapGesture={() => setReveal(!reveal)}
              />
            </HStack>
          }
        />
      </Group>
      </SettingsPage>
    </ZStack>
  )
}
