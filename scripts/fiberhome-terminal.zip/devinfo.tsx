// ---------- 设备信息（全部只读，2026-10-29 逐条实测支持） ----------
// 用到的命令（探测确认「支持」，见 COMMANDS.md）：
//   GET_SN_INFO / GET_HG_BASE_INFO / GET_HG_DHCP_INFO / GET_PORT_STATISTICS
// 结构按「有什么显示什么」渲染（lib/kv.tsx），不同固件少字段也不会空白。

import { useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { bytesText, KVGroup } from "./lib/kv"
import { ACCENT, Group, NoticeRow, Row, SettingsPage } from "./lib/settings"

export default function DevInfoPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices?.[0]

  const [sn, setSn] = useState<any>(null)
  const [base, setBase] = useState<any>(null)
  const [dhcp, setDhcp] = useState<any>(null)
  const [ports, setPorts] = useState<any[]>([])
  const [failed, setFailed] = useState<string[]>([])

  async function load() {
    const mac = device?.mac
    const token = session.token
    if (!mac || !token) return
    const bad: string[] = []

    const get = async (cmd: string) => {
      const r = await invokeService<any>(mac, token, cmd, {}, 8)
      if (!r.ok) {
        bad.push(cmd)
        return null
      }
      return r.data
    }

    const [snD, baseD, dhcpD, portD] = await Promise.all([
      get("GET_SN_INFO"),
      get("GET_HG_BASE_INFO"),
      get("GET_HG_DHCP_INFO"),
      get("GET_PORT_STATISTICS"),
    ])

    setSn(snD)
    setBase(baseD)
    setDhcp(dhcpD)
    const list = portD?.port_stat_list
    setPorts(Array.isArray(list) ? list : [])
    setFailed(bad)
  }

  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  return (
    <SettingsPage title="设备信息" refreshable={load}>
      {failed.length >= 5 ? (
        <Group>
          <NoticeRow kind="error" text={`多条命令读取失败：${failed.join("、")}`} />
        </Group>
      ) : null}

      <KVGroup header="标识" data={sn} />

      <KVGroup header="运行状态" data={base} skip={["MeshInfo", "DownSpeed", "UpSpeed"]} />

      <KVGroup header="DHCP 服务器" data={dhcp} />

      <Group header="网口与 Wi-Fi 统计" footer={ports.length ? "收/发为累计字节，右侧为包数。" : "设备没有返回端口统计（CPE 可能只有无线口）。"}>
        {ports.length ? (
          ports.map((p, i) => {
            const portName = String(p.Port ?? `LAN${i + 1}`)
            const nameMap: Record<string, string> = { "2.4G": "2.4G Wi-Fi", "5G": "5G Wi-Fi", LAN1: "网口 LAN1", LAN2: "网口 LAN2", LAN3: "网口 LAN3" }
            const label = nameMap[portName] ?? `端口 ${portName}`
            const ssid = p.SSID ? ` · ${String(p.SSID)}` : ""
            return (
              <Row
                key={`${portName}-${i}`}
                label={label}
                note={`收 ${bytesText(p.rx_traffic)} · 发 ${bytesText(p.tx_traffic)}${ssid}`}
                icon={ssid ? "wifi" : "cable.connector"}
                iconColor={ACCENT}
                value={`${Number(p.rx_packets ?? 0)} / ${Number(p.tx_packets ?? 0)}`}
              />
            )
          })
        ) : (
          <Row label="没有端口数据" icon="minus.circle" />
        )}
      </Group>
    </SettingsPage>
  )
}
