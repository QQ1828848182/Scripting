// ---------- 旧页面骨架（已改为 iOS 设置风格，保留导出名以免页面报错） ----------
// 新代码请直接用 ./settings 里的 SettingsPage / Group / Row / SwitchRow / NoticeRow / ButtonRow。
// 这里只做兼容：PageShell → SettingsPage，Section → Group，Row/Notice → 同名新组件。

import { HStack, Image, Spacer, Text, VStack, useState } from "scripting"
import type { Color } from "scripting"
import { Group, NoticeRow, Row as KitRow, SettingsPage } from "./settings"
import { fill, capsuleFill, DANGER, OK } from "./ui"

export function BackBar(_props: { onBack: () => void; busy?: boolean }) {
  return null
}

/** 兼容旧签名：label/value/note/icon/color/trailing/last/onTap */
export function Row(props: {
  label: string
  value?: string
  note?: string
  icon?: string
  color?: Color
  trailing?: any
  last?: boolean
  onTap?: () => void
}) {
  return (
    <KitRow
      label={props.label}
      value={props.value}
      note={props.note}
      icon={props.icon}
      iconColor={props.color}
      trailing={props.trailing}
      onTap={props.onTap}
    />
  )
}

/** 只读开关胶囊：0=关 / 1=开，其它值原样展示 */
export function StatePill(props: { value: any; onText?: string; offText?: string }) {
  const { value, onText = "开", offText = "关" } = props
  const s = String(value ?? "").trim()
  if (s === "" || s === "undefined" || s === "null") {
    return (
      <Text font="footnote" foregroundStyle="tertiaryLabel">
        —
      </Text>
    )
  }
  const on = s === "1"
  const known = s === "0" || s === "1"
  return (
    <Text
      font="caption"
      fontWeight="semibold"
      foregroundStyle={known ? (on ? OK : "secondaryLabel") : "secondaryLabel"}
      padding={{ horizontal: 10, vertical: 4 }}
      background={capsuleFill(known ? (on ? OK : "rgba(120,120,128,0.55)") : "rgba(120,120,128,0.35)", known && on ? 0.16 : undefined)}
    >
      {known ? (on ? onText : offText) : s}
    </Text>
  )
}

/** 兼容旧签名：Section title → Group header */
export function Section(props: { title?: string; children?: any }) {
  return <Group header={props.title}>{props.children}</Group>
}

export function Notice(props: { kind?: "error" | "ok" | "info"; text: string }) {
  return <NoticeRow kind={props.kind} text={props.text} />
}

/** 兼容旧签名：PageShell → SettingsPage（+ 可选原始返回数据折叠区） */
export default function PageShell(props: {
  title: string
  subtitle?: string
  onBack: () => void
  hideBackBar?: boolean
  loading?: boolean
  busy?: boolean
  error?: string
  notice?: string
  raw?: string
  children?: any
  footer?: string
  toast?: any
}) {
  const { title, error, notice, raw, children, footer, toast } = props
  const [showRaw, setShowRaw] = useState(false)

  return (
    <SettingsPage title={title} toast={toast}>
      {notice ? (
        <Group>
          <NoticeRow kind="ok" text={notice} />
        </Group>
      ) : null}

      {error ? (
        <Group>
          <NoticeRow kind="error" text={error} />
        </Group>
      ) : null}

      {children}

      {raw ? (
        <Group footer={footer}>
          <KitRow
            label={showRaw ? "收起原始返回" : "查看原始返回"}
            chevron={!showRaw}
            onTap={() => setShowRaw(!showRaw)}
          />
          {showRaw ? (
            <Text font="caption2" monospaced foregroundStyle="secondaryLabel" frame={{ maxWidth: "infinity" }}>
              {raw}
            </Text>
          ) : null}
        </Group>
      ) : footer ? (
        <Group footer={footer}>{null}</Group>
      ) : null}
    </SettingsPage>
  )
}
