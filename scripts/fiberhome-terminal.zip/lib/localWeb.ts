// ---------- 局域网直连 CPE（自动发现 + 管理密码登录） ----------
// 事实（2026-10-28 在 LG6851F 上实测）：
//   1) 免登录接口：GET /fh_api/tmp/FHNCAPIS?ajaxmethod=get_refresh_sessionid → {"sessionid":"..."}
//      返回纯文本 JSON，用来判断「当前是否连着这台 CPE 的 Wi-Fi」。
//   2) 其余 ajaxmethod 的 body 是 AES-CBC（key 每次随机、6 位前缀 + hex），
//      私钥派生逻辑在混淆 JS 里，TS 侧不重写；改为**在隐藏 WebView 里跑官方页面自己的 $post**。
//   3) 登录动作：$post('DO_WEB_LOGIN', {username, password}) → {result:0 成功 / 1..4 失败原因}
//      （见 login.js onSumit；密钥/加密完全由页面负责，我们只读返回值）

import { fetch } from "scripting"

export const DETECT_HOSTS = ["192.168.8.1", "192.168.1.1", "192.168.0.1", "192.168.101.1"]

export type Discovered = {
  host: string
  sessionid: string
}

function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  return Promise.race([
    p,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error("timeout")), ms)),
  ])
}

/** 纯 HTTP 探测：能拿到 sessionid 就说明手机正连着这台 CPE 的 Wi-Fi */
export async function discover(hosts: string[] = DETECT_HOSTS): Promise<Discovered | null> {
  for (const host of hosts) {
    try {
      const res = await withTimeout(
        fetch(`http://${host}/fh_api/tmp/FHNCAPIS?ajaxmethod=get_refresh_sessionid`, {
          method: "GET",
          headers: { Accept: "application/json, text/plain, */*" },
          timeout: 4,
          debugLabel: "cpe.discover",
        } as any),
        5000
      )
      if (!res.ok) continue
      const text = await res.text()
      const m = String(text).match(/"sessionid"\s*:\s*"([^"]+)"/)
      if (m) return { host, sessionid: m[1] }
    } catch {
      /* 下一个 */
    }
  }
  return null
}

/** 在隐藏 WebView 里执行官方页面自己的接口调用（body 加密交给页面） */
export class LocalWebSession {
  private wv: WebViewController | null = null
  readonly host: string
  private ready = false

  constructor(host: string) {
    this.host = host
  }

  async open(): Promise<void> {
    if (this.ready) return
    const wv = new WebViewController({ ephemeral: true })
    await wv.loadURL(`http://${this.host}/login.html`)
    this.wv = wv
    // 等 $post 就绪
    const t0 = Date.now()
    while (Date.now() - t0 < 8000) {
      try {
        const ok = await wv.evaluateJavaScript<any>("return typeof window.$post === 'function'")
        if (ok === true || ok === 1 || ok === "true") break
      } catch {
        /* retry */
      }
      await new Promise<void>(r => setTimeout(r, 250))
    }
    this.ready = true
  }

  /** 调用一个 ajaxmethod，返回解析后的对象 */
  async call(method: string, dataObj: any = null, flag?: string): Promise<any> {
    await this.open()
    const wv = this.wv!
    const token = Math.random().toString(36).slice(2)
    const flagArg = flag ? `, ${JSON.stringify(flag)}` : ""
    await wv.evaluateJavaScript<any>(
      `window.__fhcall = window.__fhcall || {};` +
        `window.__fhcall[${JSON.stringify(token)}] = null;` +
        `(function(){ try { $post(${JSON.stringify(method)}, ${JSON.stringify(dataObj)}${flagArg})` +
        `.then(function(r){ window.__fhcall[${JSON.stringify(token)}] = { ok: true, data: r }; })` +
        `.catch(function(e){ window.__fhcall[${JSON.stringify(token)}] = { ok: false, err: String(e) }; }); }` +
        `catch(e) { window.__fhcall[${JSON.stringify(token)}] = { ok: false, err: String(e) }; } })(); return 1`
    )
    const t0 = Date.now()
    while (Date.now() - t0 < 12000) {
      const v = await wv.evaluateJavaScript<any>(
        `var v = (window.__fhcall || {})[${JSON.stringify(token)}];` +
          `if (v) { delete window.__fhcall[${JSON.stringify(token)}]; } return v === undefined ? null : v`
      )
      if (v && typeof v === "object") {
        try {
          delete (globalThis as any).__fhcall
        } catch {
          /* ignore */
        }
        if (v.ok) return v.data
        throw new Error(String(v.err ?? "调用失败"))
      }
      await new Promise<void>(r => setTimeout(r, 300))
    }
    throw new Error("设备响应超时")
  }

  /** 设备信息（登录前也能读）：型号 / MAC / 是否设了密码 */
  async deviceInfo(): Promise<{ model: string; mac: string; pwdEnable: boolean } | null> {
    try {
      const d = await this.call("get_device_info", null, "nocheck")
      if (!d || typeof d !== "object") return null
      return {
        model: String(d.model_name ?? "FiberHome CPE"),
        mac: String(d.brmac ?? "").replace(/[^0-9A-Fa-f]/g, "").toUpperCase(),
        pwdEnable: String(d.pwd_enable_flag ?? "0") === "1",
      }
    } catch {
      return null
    }
  }

  /**
   * 管理密码登录：result 0 = 成功，1..4 = 页面里定义的失败原因。
   * 返回 result 原值（0 表示成功）。
   */
  async login(username: string, password: string): Promise<number> {
    const r = await this.call("DO_WEB_LOGIN", { username, password })
    const n = Number(r?.result ?? NaN)
    return Number.isFinite(n) ? n : -1
  }

  /**
   * 登录后从设备里找家庭 ID（云端绑定要用）。
   * 固件各版本的 ajaxmethod 名不完全一样，这里按候选名依次试，命中即返回。
   */
  async findFamilyId(): Promise<string | null> {
    const methods = [
      "get_filink_info",
      "get_cloud_info",
      "get_device_filink_info",
      "get_filink_status",
      "get_cloud_bind_info",
      "get_device_bind_info",
      "get_remote_manage_info",
      "get_family_info",
      "get_bind_info",
      "get_app_bind_info",
      "get_cloud_register_info",
    ]
    for (const m of methods) {
      try {
        const r = await this.call(m)
        const hit = pickFamilyId(r)
        if (hit) return hit
      } catch {
        /* 下一个 */
      }
    }
    return null
  }

  dispose() {
    try {
      this.wv?.dispose()
    } catch {
      /* ignore */
    }
    this.wv = null
    this.ready = false
  }
}

/** 在任意结构里找 familyId / FamilyId / family_id */
function pickFamilyId(v: any, depth = 0): string | null {
  if (!v || typeof v !== "object" || depth > 4) return null
  for (const k of Object.keys(v)) {
    const val = (v as any)[k]
    if (/^family_?id$/i.test(k) && (typeof val === "number" || typeof val === "string")) {
      const s = String(val).trim()
      if (/^\d+$/.test(s)) return s
    }
  }
  for (const k of Object.keys(v)) {
    const found = pickFamilyId((v as any)[k], depth + 1)
    if (found) return found
  }
  return null
}

/** 登录失败原因（对齐 lang/login_res.js 的 loginErr1..5） */
export function loginErrorText(result: number): string {
  switch (result) {
    case 1:
      return "当前已有用户在别处登录，请稍后"
    case 2:
      return "连续错误登录 3 次，请 1 分钟后再试"
    case 3:
      return "管理帐号已被禁用"
    case 4:
      return "用户名或密码错误"
    default:
      return "登录失败（未知错误）"
  }
}
