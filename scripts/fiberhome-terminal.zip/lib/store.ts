// ---------- 会话存储（Keychain） ----------

// Keychain 是 Scripting 的全局对象，不能从 "scripting" 导入。
import { KEYCHAIN_LAST_ACCOUNT, KEYCHAIN_SESSION, KEYCHAIN_UUID } from "./config"
import { randomUuid32 } from "./sign"
import type { Session } from "./api"

export function saveSession(s: Session) {
  try {
    Keychain.set(KEYCHAIN_SESSION, JSON.stringify(s))
    Keychain.set(KEYCHAIN_LAST_ACCOUNT, s.username)
    return true
  } catch {
    return false
  }
}

export function loadSession(): Session | null {
  try {
    const raw = Keychain.get(KEYCHAIN_SESSION)
    if (!raw) return null
    const s = JSON.parse(raw) as Session
    if (!s?.token || !s?.username) return null
    return s
  } catch {
    return null
  }
}

export function clearSession() {
  try {
    Keychain.remove(KEYCHAIN_SESSION)
  } catch {}
}

export function lastAccount(): string {
  try {
    return Keychain.get(KEYCHAIN_LAST_ACCOUNT) ?? ""
  } catch {
    return ""
  }
}

/**
 * 稳定的终端 uuid（32 位大写 HEX）。
 * 真实客户端跨请求复用同一个值，签名里也要用它，所以首次生成后存 Keychain。
 */
export function deviceUuid(): string {
  try {
    const v = Keychain.get(KEYCHAIN_UUID)
    if (v && /^[0-9A-Fa-f]{32}$/.test(v)) return v.toUpperCase()
  } catch {}
  const u = randomUuid32()
  try {
    Keychain.set(KEYCHAIN_UUID, u)
  } catch {}
  return u
}
