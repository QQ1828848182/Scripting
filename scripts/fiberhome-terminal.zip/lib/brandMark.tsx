// ---------- 运营商图标：内嵌官方图形（透明 PNG，base64 解码，不读文件） ----------

import { Image, VStack } from "scripting"
import type { Brand } from "./brand"
import { brandImage } from "./brandImages"

/**
 * 运营商官方图标，默认 34pt 正方形。
 * 图片自带透明通道，所以直接坐在外层卡片背景上，不再套白底方块。
 */
export function BrandMark(props: { brand: Brand; size?: number }) {
  const s = props.size ?? 34
  const img = brandImage(props.brand.key)
  if (!img) return <VStack frame={{ width: s, height: s }} />
  return <Image image={img} resizable frame={{ width: s, height: s }} />
}
