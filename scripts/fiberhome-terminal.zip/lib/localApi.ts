// ---------- 本地 CPE 接口层（局域网 http://192.168.8.1） ----------
// 三条通道（来自 LG6121F 研究文章，已在本机 LG6851F 上验证过存在性）：
//   /api/tmp/FHTOOLAPIS  APP 级登录，明文 —— 本文件的主通道
//   /api/tmp/FHNCAPIS    免登录，AES-CBC 加密（本固件实测已要求登录）
//   /api/tmp/FHAPIS      superadmin 登录，AES-CBC 加密
//
// 已实测：
//   GET  /api/tmp/FHTOOLAPIS?ajaxmethod=get_refresh_sessionid  → 200 {"sessionid":"..."}
//   POST /api/tmp/FHTOOLAPIS {ajaxmethod,sessionid,dataObj}    → 403（未完成 APP 级登录）
// 因此这里把「登录动作名 / 令牌字段」留成配置项，拿到真实值后填上即可。

import { fetch } from "scripting"

export const DEFAULT_HOST = "192.168.8.1"
const HOST_KEY = "cpe.host.v1"
const TOOL_LOGIN_ACTION_KEY = "cpe.toolLogin.v1"

export type LocalResult = {
  ok: boolean
  status: number
  data?: any
  text?: string
  error?: string
  took?: number
}

export function normalizeHost(input: string): string {
  let h = (input || "").trim()
  if (!h) h = DEFAULT_HOST
  h = h.replace(/^https?:\/\//i, "").replace(/\/+$/, "")
  return h || DEFAULT_HOST
}

export function getHost(): string {
  try {
    const v = Storage.get<string>(HOST_KEY)
    if (v && String(v).trim()) return normalizeHost(v)
  } catch {
    /* ignore */
  }
  return DEFAULT_HOST
}

export function setHost(host: string) {
  try {
    Storage.set(HOST_KEY, normalizeHost(host))
  } catch {
    /* ignore */
  }
}

/** APP 级登录用的 ajaxmethod（拿到真实名字后填这里，或用 setToolLoginAction 保存） */
export function getToolLoginAction(): string {
  try {
    return Storage.get<string>(TOOL_LOGIN_ACTION_KEY) ?? ""
  } catch {
    return ""
  }
}

export function setToolLoginAction(action: string) {
  try {
    Storage.set(TOOL_LOGIN_ACTION_KEY, action.trim())
  } catch {
    /* ignore */
  }
}

async function request(url: string, init: any, timeout: number): Promise<LocalResult> {
  const t0 = Date.now()
  try {
    const res = await fetch(url, { ...init, timeout, debugLabel: "cpe.local" })
    const text = await res.text()
    let data: any = undefined
    try {
      data = JSON.parse(text)
    } catch {
      /* 非 JSON 时只看 text */
    }
    return { ok: res.ok, status: res.status, data, text, took: Date.now() - t0 }
  } catch (e: any) {
    return { ok: false, status: 0, error: e?.message ?? String(e), took: Date.now() - t0 }
  }
}

/** 设备是否在线（同网段才通） */
export async function ping(host = getHost()): Promise<boolean> {
  const r = await request(`http://${normalizeHost(host)}/`, { method: "GET" }, 4)
  return r.status > 0
}

/** get_refresh_sessionid 的响应开头带 \r，去掉再解析 */
export async function getSessionId(host = getHost()): Promise<string> {
  const r = await request(
    `http://${normalizeHost(host)}/api/tmp/FHTOOLAPIS?ajaxmethod=get_refresh_sessionid`,
    { method: "GET" },
    6
  )
  const text = (r.text ?? "").replace(/^[\s\u0000]+/, "")
  let sid = r.data?.sessionid
  if (!sid) {
    const m = text.match(/"sessionid"\s*:\s*"([^"]+)"/)
    if (m) sid = m[1]
  }
  if (!sid) throw new Error(`获取 sessionid 失败（HTTP ${r.status}）`)
  return String(sid)
}

export type ToolOptions = {
  sessionid?: string
  /** APP 登录后拿到的令牌，字段名待确认；确认后改这里即可 */
  token?: string
  timeout?: number
  /** 带上 referer / origin / cookie，模拟网页同源请求（部分固件用它做校验） */
  browserLike?: boolean
}

function sameOriginHeaders(host: string, sid?: string): Record<string, string> {
  const h: Record<string, string> = {
    "content-type": "application/json",
    referer: `http://${host}/login.html`,
    origin: `http://${host}`,
  }
  if (sid) h.cookie = `sessionid=${sid}`
  return h
}

/**
 * 调一个明文工具接口。
 * 未完成 APP 级登录时服务端返回 403，属预期。
 */
export async function toolCall(
  action: string,
  dataObj: any = {},
  opts: ToolOptions = {}
): Promise<LocalResult> {
  const host = getHost()
  let sid = opts.sessionid
  if (!sid) {
    try {
      sid = await getSessionId(host)
    } catch {
      sid = ""
    }
  }
  const body: Record<string, any> = { ajaxmethod: action, sessionid: sid ?? "", dataObj }
  if (opts.token) body.token = opts.token
  const headers =
    opts.browserLike === false
      ? { "content-type": "application/json" }
      : sameOriginHeaders(host, sid ?? undefined)
  return request(
    `http://${host}/api/tmp/FHTOOLAPIS`,
    { method: "POST", headers, body: JSON.stringify(body) },
    opts.timeout ?? 10
  )
}

/** 原样发送一段 JSON（调试台用），不做任何字段拼装 */
export async function toolRaw(body: any, timeout = 10, browserLike = true): Promise<LocalResult> {
  const host = getHost()
  const headers = browserLike
    ? sameOriginHeaders(host, typeof body?.sessionid === "string" ? body.sessionid : undefined)
    : { "content-type": "application/json" }
  return request(
    `http://${host}/api/tmp/FHTOOLAPIS`,
    { method: "POST", headers, body: JSON.stringify(body) },
    timeout
  )
}

/** 原样抓一个路径的文本（HTML / JS / JSON），用于静态提取 ajaxmethod */
export async function fetchText(path: string, timeout = 10): Promise<LocalResult> {
  const host = getHost()
  let p = (path || "/").trim()
  if (!p.startsWith("/")) p = "/" + p
  return request(`http://${host}${p}`, { method: "GET" }, timeout)
}

/** 从文本里抽出所有可能的 ajaxmethod / 接口名 */
export function extractActions(text: string): string[] {
  const found = new Set<string>()
  const push = (s: string) => {
    const v = s.trim()
    if (v && v.length >= 3 && v.length <= 48) found.add(v)
  }
  // ajaxmethod":"get_xxx" / ajaxmethod = 'get_xxx'
  const re1 = /ajaxmethod[\s"']*[:=][\s"']*([A-Za-z0-9_.\-]{3,48})/gi
  let m: RegExpExecArray | null
  while ((m = re1.exec(text)) !== null) push(m[1])
  // 通用：get_xxx / set_xxx 形式的字符串字面量
  const re2 = /["']((?:get|set|del|add|query|update)_[a-z0-9_]{2,40})["']/gi
  while ((m = re2.exec(text)) !== null) push(m[1])
  // url 里带 action=xxx
  const re3 = /[?&]action=([A-Za-z0-9_.\-]{3,48})/gi
  while ((m = re3.exec(text)) !== null) push(m[1])
  return Array.from(found)
}

/** 把结果压成可读文本，便于调试台直接展示 */
export function describeResult(r: LocalResult): string {
  const head = r.error
    ? `❌ ${r.error}`
    : `HTTP ${r.status}${r.ok ? " ✅" : " ⚠️"} · ${r.took ?? 0}ms`
  return r.text ? `${head}\n\n${r.text}` : head
}
