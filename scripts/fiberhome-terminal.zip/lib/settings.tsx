// ---------- iOS「设置」风格页面组件 ----------
// 目标外观：insetGroup 分组列表 —— 灰底、白卡片、分组标题在卡片外、行内左标题右值/开关/箭头。
//
// 使用约定（很重要）：
// - 页面根节点用 <SettingsPage>，它的**直接子节点只能是 <Group>**（List 的直接子节点会被当成一行）。
// - 不要把 Group 再包进 VStack / ScrollView，否则整段会挤成一行。
// - 行与行之间的分隔线由系统画，不需要手动画线，也不需要 `last`。
// - 只读值用 Row 的 value；需要强调/自定义的右侧内容用 trailing 或 children。

import {
  HStack,
  Image,
  List,
  Menu,
  Picker,
  ProgressView,
  Rectangle,
  Section,
  SecureField,
  Spacer,
  Text,
  TextField,
  Toggle,
  VStack,
  ZStack,
  Button,
  useState,
} from "scripting"
import type { Color } from "scripting"
import { ACCENT, ACCENT_WARM, DANGER, OK } from "./ui"

export { ACCENT, ACCENT_WARM, DANGER, OK }

/** 组外脚注（说明文字） */
function Footnote(props: { children?: any }) {
  return (
    <VStack alignment="leading" spacing={4} frame={{ maxWidth: "infinity" }}>
      {props.children}
    </VStack>
  )
}

export function SettingsPage(props: {
  /** 导航栏标题（inline 居中） */
  title?: string
  /** 下拉刷新 */
  refreshable?: () => Promise<void>
  /** 轻提示：传 hintToast(hint, () => setHint(null)) 的返回值 */
  toast?: any
  /** 接 NavigationDestination（原生路由推送） */
  navigationDestination?: any
  children?: any
}) {
  // 重要：不要把 toolbar 作为 prop 转发进来再挂到内部视图上 —— 经由自定义组件转发会让
  // 导航栏按钮重复渲染两份。需要导航栏按钮的页面，自己在外层写：
  //   <ZStack frame={{maxWidth:"infinity",maxHeight:"infinity"}} toolbar={{topBarTrailing: <Button …/>}}>
  //     <SettingsPage …>…</SettingsPage>
  //   </ZStack>
  const props2: any = {}
  if (props.navigationDestination !== undefined && props.navigationDestination !== null) {
    props2.navigationDestination = props.navigationDestination
  }

  // 注意：toolbar 一律由页面外层 ZStack 提供（见上方说明）。
  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      <List
        listStyle="insetGroup"
        listSectionSpacing={24}
        navigationTitle={props.title}
        navigationBarTitleDisplayMode="inline"
        refreshable={props.refreshable}
        toast={props.toast}
        {...props2}
      >
        {props.children}
      </List>
    </ZStack>
  )
}

export function Group(props: {
  /** 分组标题（卡片上方的小灰字） */
  header?: string
  /** 分组脚注：字符串或任意视图 */
  footer?: any
  children?: any
}) {
  const footer =
    props.footer === undefined || props.footer === null
      ? undefined
      : typeof props.footer === "string"
        ? <Footnote><Text>{props.footer}</Text></Footnote>
        : <Footnote>{props.footer}</Footnote>

  return (
    <Section
      header={props.header ? <Text>{props.header}</Text> : undefined}
      footer={footer}
    >
      {props.children}
    </Section>
  )
}

export function Row(props: {
  label?: string
  /** 副标题（第二行小灰字） */
  note?: string
  /** SF Symbol */
  icon?: string
  iconColor?: Color
  /** 右侧值（灰色、单行） */
  value?: string
  valueColor?: Color
  /** 标题颜色（Menu 里的行会被染成蓝色，需要传 "label" 压回去） */
  labelColor?: Color
  mono?: boolean
  /** 右侧箭头：true/"right" = 进入下一页；"updown" = 展开选项菜单（iOS 设置里的 ⇅） */
  chevron?: boolean | "right" | "updown"
  /** 右侧蓝勾（单选行） */
  selected?: boolean
  /** 右侧转圈（提交中） */
  spinner?: boolean
  /** 右侧自定义内容 */
  trailing?: any
  onTap?: () => void
  /** 整行自定义内容（给了就不渲染 label/value）。不要叫 children：组件的 children 总会被注入 */
  content?: any
  /** 兼容旧代码，无实际作用：分隔线由系统绘制 */
  last?: boolean
}) {
  const { label, note, icon, iconColor, value, valueColor, mono, chevron, selected, spinner, trailing, onTap, content, labelColor } = props

  // 注意：不能给 HStack 传 Fragment（<>…</>），Scripting 会渲染成空白行，必须用子节点数组
  const parts: any[] = []
  if (content) {
    parts.push(content)
  } else {
    if (icon) {
      parts.push(<Image systemName={icon} font={16} foregroundStyle={iconColor ?? "secondaryLabel"} frame={{ width: 22 }} />)
    }
    if (label !== undefined || note !== undefined) {
      parts.push(
        <VStack alignment="leading" spacing={2} foregroundStyle={labelColor}>
          {label !== undefined ? <Text>{label}</Text> : null}
          {note ? (
            <Text font="caption" foregroundStyle="secondaryLabel">
              {note}
            </Text>
          ) : null}
        </VStack>
      )
    }
    parts.push(<Spacer />)
    if (trailing) parts.push(trailing)
    if (value !== undefined && value !== null) {
      parts.push(
        <Text
          font="body"
          monospaced={mono}
          foregroundStyle={valueColor ?? "secondaryLabel"}
          lineLimit={1}
          multilineTextAlignment="trailing"
        >
          {value}
        </Text>
      )
    }
    if (spinner) parts.push(<ProgressSpinner key="spin" />)
    if (selected) {
      parts.push(<Image key="check" systemName="checkmark" font="body" fontWeight="semibold" foregroundStyle={ACCENT} />)
    }
    if (chevron) parts.push(chevron === "updown" ? <UpDownGlyph key="chev" /> : <ChevronGlyph key="chev" />)
  }

  return (
    <HStack
      spacing={10}
      frame={{ maxWidth: "infinity", minHeight: 24 }}
      contentShape="rect"
      onTapGesture={onTap}
    >
      {parts}
    </HStack>
  )
}

/** 开关行：标题在左、系统开关在右（可选图标，和工具箱其它行对齐） */
export function SwitchRow(props: {
  label: string
  note?: string
  icon?: string
  iconColor?: Color
  value: boolean
  onChanged: (v: boolean) => void
}) {
  const inner: any[] = []
  if (props.icon) {
    inner.push(<Image systemName={props.icon} font={16} foregroundStyle={props.iconColor ?? "secondaryLabel"} frame={{ width: 22 }} />)
  }
  inner.push(
    <VStack alignment="leading" spacing={2}>
      <Text>{props.label}</Text>
      {props.note ? (
        <Text font="caption" foregroundStyle="secondaryLabel">
          {props.note}
        </Text>
      ) : null}
    </VStack>
  )
  return (
    <Toggle value={props.value} onChanged={props.onChanged}>
      <HStack spacing={10}>{inner}</HStack>
    </Toggle>
  )
}

/** 输入行：标题在左、输入框在右（右对齐）；unit 是数字后面的单位（如 GB） */
export function InputRow(props: {
  label: string
  value: string
  onChanged: (v: string) => void
  prompt?: string
  unit?: string
  secure?: boolean
  autocapitalization?: any
  autocorrectionDisabled?: boolean
}) {
  return (
    <HStack spacing={10} frame={{ maxWidth: "infinity" }}>
      <Text>{props.label}</Text>
      {props.secure ? (
        <SecureFieldRow {...props} />
      ) : (
        <TextFieldRow {...props} />
      )}
      {props.unit ? <Text foregroundStyle="secondaryLabel">{props.unit}</Text> : null}
    </HStack>
  )
}

function TextFieldRow(props: { value: string; onChanged: (v: string) => void; prompt?: string; autocapitalization?: any; autocorrectionDisabled?: boolean }) {
  return (
    <TextField
      title=""
      value={props.value}
      onChanged={props.onChanged}
      prompt={props.prompt}
      textInputAutocapitalization={props.autocapitalization}
      autocorrectionDisabled={props.autocorrectionDisabled}
      multilineTextAlignment="trailing"
      frame={{ maxWidth: "infinity" }}
    />
  )
}

function SecureFieldRow(props: { value: string; onChanged: (v: string) => void; prompt?: string }) {
  return (
    <SecureField
      title=""
      value={props.value}
      onChanged={props.onChanged}
      prompt={props.prompt}
      multilineTextAlignment="trailing"
      frame={{ maxWidth: "infinity" }}
    />
  )
}

/** 密码输入行：右侧输入框 + 小眼睛切换明文（不点眼睛看不到密码） */
export function PasswordRow(props: {
  label: string
  value: string
  onChanged: (v: string) => void
  prompt?: string
  autocorrectionDisabled?: boolean
}) {
  const [shown, setShown] = useState(false)
  const parts: any[] = []
  parts.push(
    <Text key="label">{props.label}</Text>
  )
  parts.push(
    shown ? (
      <TextFieldRow
        key="field"
        value={props.value}
        onChanged={props.onChanged}
        prompt={props.prompt}
        autocorrectionDisabled={props.autocorrectionDisabled}
      />
    ) : (
      <SecureFieldRow key="field" value={props.value} onChanged={props.onChanged} prompt={props.prompt} />
    )
  )
  parts.push(
    <Image
      key="eye"
      systemName={shown ? "eye.slash" : "eye"}
      font={15}
      foregroundStyle="secondaryLabel"
      frame={{ width: 24 }}
      onTapGesture={() => setShown(!shown)}
    />
  )
  return (
    <HStack spacing={10} frame={{ maxWidth: "infinity", minHeight: 24 }}>
      {parts}
    </HStack>
  )
}

/** 只读密码行：默认圆点，点整行（或右侧小眼睛）才显示明文 */
export function SecretRow(props: { label: string; value: string }) {
  const [shown, setShown] = useState(false)
  const v = props.value ?? ""
  const text = !v ? "—" : shown ? v : "•".repeat(Math.min(v.length, 12))
  const parts: any[] = []
  parts.push(<Text key="label">{props.label}</Text>)
  parts.push(<Spacer key="sp" />)
  parts.push(
    <Text key="val" foregroundStyle="secondaryLabel" lineLimit={1} multilineTextAlignment="trailing">
      {text}
    </Text>
  )
  parts.push(
    <Image
      key="eye"
      systemName={shown ? "eye.slash" : "eye"}
      font={15}
      foregroundStyle="secondaryLabel"
      frame={{ width: 24 }}
    />
  )
  return (
    <Row
      content={
        <HStack spacing={10} frame={{ maxWidth: "infinity", minHeight: 24 }}>
          {parts}
        </HStack>
      }
      onTap={() => setShown(!shown)}
    />
  )
}

/** 提示行：红/绿/灰文字的整行提示（错误、成功、说明） */
export function NoticeRow(props: { kind?: "error" | "ok" | "info"; text: string }) {
  const { kind = "info", text } = props
  const color: Color = kind === "error" ? DANGER : kind === "ok" ? OK : "secondaryLabel"
  const icon =
    kind === "error"
      ? "exclamationmark.triangle.fill"
      : kind === "ok"
        ? "checkmark.circle.fill"
        : "info.circle.fill"
  return (
    <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
      <Image systemName={icon} font="footnote" foregroundStyle={color} />
      <Text font="footnote" foregroundStyle={color} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        {text}
      </Text>
    </HStack>
  )
}

/** 单选行：右侧蓝勾 */
export function ChoiceRow(props: { title: string; note?: string; selected: boolean; onTap: () => void; spinner?: boolean }) {
  return (
    <Row label={props.title} note={props.note} selected={props.selected} spinner={props.spinner} onTap={props.onTap} />
  )
}

/** 居中文字按钮行（登录 / 保存 / 退出登录等） */
export function ButtonRow(props: {
  title: string
  /** 危险操作：红色 */
  destructive?: boolean
  /** 不可用：灰色且不响应 */
  disabled?: boolean
  busy?: boolean
  onTap: () => void
}) {
  const color: Color = props.disabled ? "secondaryLabel" : props.destructive ? DANGER : ACCENT
  return (
    <HStack
      frame={{ maxWidth: "infinity", minHeight: 24 }}
      contentShape="rect"
      onTapGesture={() => {
        if (!props.disabled && !props.busy) props.onTap()
      }}
    >
      {props.busy ? (
        <HStack spacing={6} frame={{ maxWidth: "infinity" }}>
          <Spacer />
          <ProgressSpinner />
          <Text fontWeight="semibold" foregroundStyle="secondaryLabel">
            {props.title}
          </Text>
          <Spacer />
        </HStack>
      ) : (
        <Text fontWeight="semibold" foregroundStyle={color} frame={{ maxWidth: "infinity" }}>
          {props.title}
        </Text>
      )}
    </HStack>
  )
}

/** 一行两个文字按钮（表单底部：取消 | 保存），取代两个分开的 ButtonRow */
export function ButtonPairRow(props: {
  cancelTitle?: string
  confirmTitle: string
  confirmDisabled?: boolean
  busy?: boolean
  onCancel: () => void
  onConfirm: () => void
}) {
  const color: Color = props.confirmDisabled ? "secondaryLabel" : ACCENT
  const parts: any[] = []
  parts.push(
    <HStack key="cancel" frame={{ maxWidth: "infinity" }} contentShape="rect" onTapGesture={props.onCancel}>
      <Text fontWeight="semibold" foregroundStyle="secondaryLabel" frame={{ maxWidth: "infinity" }}>
        {props.cancelTitle ?? "取消"}
      </Text>
    </HStack>
  )
  parts.push(<Rectangle key="sep" fill="#C7C7CC" frame={{ width: 1, height: 20 }} />)
  parts.push(
    <HStack
      key="confirm"
      frame={{ maxWidth: "infinity" }}
      contentShape="rect"
      onTapGesture={() => {
        if (!props.confirmDisabled && !props.busy) props.onConfirm()
      }}
    >
      {props.busy ? (
        <HStack spacing={6} frame={{ maxWidth: "infinity" }}>
          <Spacer />
          <ProgressSpinner />
          <Text fontWeight="semibold" foregroundStyle="secondaryLabel">
            {props.confirmTitle}
          </Text>
          <Spacer />
        </HStack>
      ) : (
        <Text fontWeight="semibold" foregroundStyle={color} frame={{ maxWidth: "infinity" }}>
          {props.confirmTitle}
        </Text>
      )}
    </HStack>
  )
  return (
    <HStack spacing={8} frame={{ maxWidth: "infinity", minHeight: 24 }}>
      {parts}
    </HStack>
  )
}

function ChevronGlyph() {
  return <Image systemName="chevron.right" font="footnote" fontWeight="semibold" foregroundStyle="tertiaryLabel" />
}

/** iOS 设置里「点开选项菜单」的上下小箭头 */
function UpDownGlyph() {
  return (
    <Image systemName="chevron.up.chevron.down" font="caption2" fontWeight="semibold" foregroundStyle="tertiaryLabel" />
  )
}

/**
 * 选项行：右侧显示当前值 + 上下箭头，点一下在**行附近**弹出选项菜单（原生 Menu）。
 * 全项目所有“单选/切换值”的入口都用它，不要再用居中弹窗。
 */
export function PickerRow(props: {
  label: string
  note?: string
  icon?: string
  iconColor?: Color
  /** 当前值（展示用） */
  value?: string
  valueColor?: Color
  /** 用于比对的真实值（不传则用 value） */
  selected?: string
  options: { value: string; label: string }[]
  onSelect: (v: string) => void
  /** 不可用：只显示、不弹菜单 */
  disabled?: boolean
}) {
  const cur = props.selected ?? props.value ?? ""
  const found = props.options.some(o => o.value === cur)

  if (props.disabled) {
    return (
      <Row
        label={props.label}
        note={props.note}
        icon={props.icon}
        iconColor={props.iconColor}
        value={props.value}
        valueColor={props.valueColor ?? "tertiaryLabel"}
        labelColor="label"
      />
    )
  }

  // 用系统 Picker(menu) 而不是 Menu：菜单会贴着右侧的值弹出（与 iOS 设置一致）
  return (
    <Picker
      label={
        <HStack spacing={10} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          {props.icon ? (
            <Image
              systemName={props.icon}
              font={16}
              foregroundStyle={props.iconColor ?? "secondaryLabel"}
              frame={{ width: 22 }}
            />
          ) : null}
          <VStack alignment="leading" spacing={2} foregroundStyle="label">
            <Text>{props.label}</Text>
            {props.note ? (
              <Text font="caption" foregroundStyle="secondaryLabel">
                {props.note}
              </Text>
            ) : null}
          </VStack>
        </HStack>
      }
      value={cur}
      onChanged={(v: string) => props.onSelect(v)}
      pickerStyle="menu"
      menuIndicator="visible"
      tint="secondaryLabel"
    >
      {found ? null : <Text tag={cur}>{props.value ?? "—"}</Text>}
      {props.options.map(o => (
        <Text key={o.value} tag={o.value}>
          {o.label}
        </Text>
      ))}
    </Picker>
  )
}

function ProgressSpinner() {
  return <ProgressView progressViewStyle="circular" controlSize="small" />
}
