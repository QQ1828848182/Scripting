// ---------- 烽火终端 · 云端接口层 ----------
// 请求形态按已验证可用的实现对齐：
// - 只有 Content-Type: application/json，不需要 signature / uuid / timestamp 请求头
// - 登录：loginName + SHA256(密码) 小写 hex + areaCode + clientType + randomCode + appVersion
// - Token 校验 / 用户信息：queryUserInfo（areaCode + appType + loginName + token + appVersion）
// - 设备列表：username + appType + appVersion + token

import { fetch } from "scripting"
import { AREA_CODE, BIND_URL, DEVICE_LIST_URL, DEVICE_RENAME_URL, LOGIN_URL, NOTICE_URL, PHONE_URL, REQUEST_TIMEOUT, SEND_SIGNATURE, UNBIND_URL, USER_INFO_URL, VERSION_URL } from "./config"
import { sha256 } from "./sha256"
import { makeSignature } from "./sign"
import { deviceUuid } from "./store"

export const APP_VERSION = "2.2.51"
export const APP_TYPE = "terminal"
export const USER_AGENT = `FHTerminal/${APP_VERSION} (iPhone; iOS 27.0.1; Scale/3.00)`

/** 接口路径（用于日志 / debugLabel） */
export function pathOf(url: string): string {
  const m = url.match(/^https?:\/\/[^/]+(\/[^?]*)/)
  return m ? m[1] : url
}

/** 后端统一信封（部分接口不带 resultCode，只看关键字段） */
export type Envelope<T = any> = {
  resultCode?: number
  resultDesc?: string
  rspParam?: any
} & T

/** 绑定设备（抓包 §3.2 的 bindDeviceInfoVOs） */
export type DeviceInfo = {
  id?: number | null
  name: string
  model: string
  mac: string
  sn?: string | null
  familyId?: number | null
  roomId?: number | null
  position?: string | null
  bindTime?: number | null
  online?: boolean
  filinkStatus?: string | number
  areaCode?: string | null
  firmVersion?: string | null
  br0Ip?: string | null
  slaveDeviceInfos?: DeviceInfo[]
  wanConMode?: string | null
}

/** 用户信息（queryUserInfo 返回的字段，宽松解析） */
export type UserInfo = {
  username?: string
  nickName?: string
  phone?: string | number
  email?: string
  areaCode?: string
  [k: string]: any
}

export type Session = {
  /** 登录用的账号（手机号） */
  loginName: string
  /** 服务端返回的用户名 */
  username: string
  token: string
  loginAt: number
  mode: "password" | "token"
  raw?: any
}

export class ApiError extends Error {
  code?: number
  constructor(message: string, code?: number) {
    super(message)
    this.code = code
  }
}

// ---------------- 网络请求 ----------------

export type WireInfo = {
  url: string
  method: string
  requestHeaders: Record<string, string>
  requestBody: string
  status?: number
  responseHeaders?: Record<string, string>
  responseBody?: string
  ms?: number
  error?: string
}

async function postJson<T = any>(
  url: string,
  body: any,
  token?: string
): Promise<{ data: T; wire: WireInfo }> {
  const bodyStr = JSON.stringify(body)
  const timestamp = String(Date.now())
  const uuid = deviceUuid()

  const headers: Record<string, string> = {
    "content-type": "application/json",
    "user-agent": USER_AGENT,
    accept: "*/*",
    "accept-language": "zh-Hans-CN;q=1",
  }
  if (SEND_SIGNATURE) {
    headers.apptype = APP_TYPE
    headers.uuid = uuid
    headers.timestamp = timestamp
    headers.signature = makeSignature(timestamp, uuid, bodyStr)
  }
  if (token) headers.token = token
  const wire: WireInfo = {
    url,
    method: "POST",
    requestHeaders: headers,
    requestBody: bodyStr,
  }

  const t0 = Date.now()
  try {
    const resp = await fetch(url, {
      method: "POST",
      headers,
      body: bodyStr,
      timeout: REQUEST_TIMEOUT,
      debugLabel: pathOf(url),
    })
    wire.status = resp.status
    const text = await resp.text()
    wire.responseBody = text
    wire.ms = Date.now() - t0

    let data: any = null
    try {
      data = JSON.parse(text)
    } catch {
      throw new ApiError(`响应不是 JSON（HTTP ${resp.status}）`, resp.status)
    }
    if (!resp.ok) {
      throw new ApiError(describe(data) || `HTTP ${resp.status}`, resp.status)
    }
    return { data: data as T, wire }
  } catch (e: any) {
    wire.ms = wire.ms ?? Date.now() - t0
    wire.error = e?.message ?? String(e)
    if (e instanceof ApiError) throw e
    throw new ApiError(humanizeNetworkError(e), undefined)
  }
}

function describe(data: any): string {
  if (!data) return ""
  if (data.resultDesc) return String(data.resultDesc)
  if (data.message) return String(data.message)
  if (data.msg) return String(data.msg)
  return ""
}

function humanizeNetworkError(e: any): string {
  const msg = e?.message ?? String(e)
  if (/timed? ?out/i.test(msg) || e?.name === "AbortError") return "请求超时，请检查网络"
  if (/offline|not connected|internet/i.test(msg)) return "网络未连接"
  if (/certificate|SSL|TLS/i.test(msg)) return "证书校验失败"
  return msg
}

// ---------------- 请求体（导出便于自测 / 排查） ----------------

/** 登录请求体：密码为 SHA-256 小写 hex */
export function buildLoginBody(loginName: string, password: string) {
  return {
    loginName,
    password: sha256(password).toLowerCase(),
    areaCode: AREA_CODE,
    clientType: 0,
    randomCode: "",
    appVersion: APP_VERSION,
  }
}

/** 用户信息 / Token 校验请求体 */
export function buildUserInfoBody(loginName: string, token: string) {
  return {
    areaCode: AREA_CODE,
    appType: APP_TYPE,
    loginName,
    token,
    appVersion: APP_VERSION,
  }
}

/** 设备列表请求体 */
export function buildDeviceListBody(username: string, token: string) {
  return {
    username,
    appType: APP_TYPE,
    appVersion: APP_VERSION,
    token,
  }
}

function normalizeMac(mac: string): string {
  return String(mac ?? "").replace(/[^0-9a-fA-F]/g, "").toUpperCase()
}

/** 修改设备名称请求体（字段顺序对齐抓包） */
export function buildRenameBody(mac: string, name: string, token: string) {
  return {
    appVersion: APP_VERSION,
    appType: APP_TYPE,
    name,
    mac: normalizeMac(mac),
    token,
  }
}

/** 修改设备名称（/rest/deviceInfo/editDeviceName，已用抓包验证签名可过） */
/** 固件版本信息（/operVersionManage/queryRouterVerInfo） */
export type RouterVersion = {
  id: number
  name: string
  model: string
  version: string
  hardwareVer: string
  softwareVer: string
  areaCode: string
  descriptions: string
  url: string
  /** 服务端单位是 KB */
  size: number | null
  verMd5: string
  uploadTime: string
  reStatus: number | null
}

/** 查询该型号可选固件；没新版本时数组为空 */
export async function queryRouterVersion(session: Session, mac: string, model: string): Promise<RouterVersion[]> {
  const body = {
    model,
    appType: APP_TYPE,
    mac: normalizeMac(mac),
    token: session.token,
    appVersion: APP_VERSION,
  }
  const { data } = await postJson<any>(VERSION_URL, body, session.token)
  const code = Number(data?.resultCode ?? -1)
  if (code !== 0) throw new ApiError(describe(data) || "查询固件版本失败", code)
  const list: any[] = Array.isArray(data?.routerVerInfos) ? data.routerVerInfos : []
  return list.map(v => ({
    id: Number(v.id ?? 0),
    name: String(v.name ?? ""),
    model: String(v.model ?? model),
    version: String(v.version ?? ""),
    hardwareVer: String(v.hardwareVer ?? ""),
    softwareVer: String(v.softwareVer ?? ""),
    areaCode: String(v.areaCode ?? ""),
    descriptions: String(v.descriptions ?? ""),
    url: String(v.url ?? ""),
    size: Number.isFinite(Number(v.size)) ? Number(v.size) : null,
    verMd5: String(v.verMd5 ?? ""),
    uploadTime: String(v.uploadTime ?? ""),
    reStatus: Number.isFinite(Number(v.reStatus)) ? Number(v.reStatus) : null,
  }))
}

/** 解绑设备：body 只有 username / appType / mac / appVersion（实测 75 字节） */
export function buildUnbindBody(username: string, mac: string) {
  return { username, appType: APP_TYPE, mac, appVersion: APP_VERSION }
}

/** 用户公告：body 只有 username（实测 24 字节） */
export function buildNoticeBody(username: string) {
  return { username }
}

export type Notice = { title: string | null; content: string | null }

/** 拉公告，没公告时 title/content 均为 null */
export async function fetchNotice(session: Session): Promise<Notice> {
  const body = buildNoticeBody(session.username || session.loginName)
  const { data } = await postJson<any>(NOTICE_URL, body, session.token)
  const code = Number(data?.resultCode ?? -1)
  if (code !== 0) throw new ApiError(describe(data) || "获取公告失败", code)
  return { title: data?.title ?? null, content: data?.content ?? null }
}

/** 绑定设备：body = username / appVersion / appType / mac / token / familyId（抓包实测 152 字节） */
export function buildBindBody(username: string, mac: string, token: string, familyId: string) {
  return { username, appVersion: APP_VERSION, appType: APP_TYPE, mac: normalizeMac(mac), token, familyId }
}

/** 把设备绑到当前账号。familyId 是官方 App 绑定页里的“家庭 ID”（纯数字）。 */
export async function bindDevice(session: Session, mac: string, familyId: string): Promise<void> {
  const body = buildBindBody(session.username || session.loginName, mac, session.token, familyId)
  const { data } = await postJson<any>(BIND_URL, body, session.token)
  const code = Number(data?.resultCode ?? -1)
  if (code !== 0) throw new ApiError(describe(data) || "绑定失败", code)
}

/** 从任意响应里找 familyId（不同接口包裹层级不同，深度扫描） */
export function pickFamilyId(obj: any, depth = 0): string {
  if (!obj || typeof obj !== "object" || depth > 4) return ""
  for (const k of Object.keys(obj)) {
    if (/^family_?id$/i.test(k)) {
      const v = obj[k]
      if (v !== null && v !== undefined && String(v).trim() !== "") return String(v)
    }
  }
  for (const k of Object.keys(obj)) {
    const r = pickFamilyId(obj[k], depth + 1)
    if (r) return r
  }
  return ""
}

/** 官方机型名 → 展示名（绑定后官方 App 会把设备名改成这个） */
const FRIENDLY_NAME: Record<string, string> = { LG6851F: "5G CPE Pro" }

export function friendlyName(model?: string | null): string {
  const m = (model ?? "").trim()
  return FRIENDLY_NAME[m] ?? m ?? ""
}

/**
 * 推导家庭信息：登录返回 → 已绑定设备 → queryUserInfo。
 * 10.har 证实 queryUserInfo 直接回 familyId / familyName / familyInfos[]，
 * 官方 App 绑新设备时用的就是这个 familyId（与设备无关）。
 */
export async function resolveFamily(session: Session): Promise<{ id: string; name: string }> {
  const fromSession = pickFamilyId(session.raw)
  if (fromSession) return { id: fromSession, name: String(session.raw?.familyName ?? "") }
  try {
    const { devices } = await fetchDevices(session)
    for (const d of devices) if (d.familyId) return { id: String(d.familyId), name: d.position ?? "" }
  } catch {
    /* ignore */
  }
  try {
    const body = buildUserInfoBody(session.username || session.loginName, session.token)
    const { data } = await postJson<any>(USER_INFO_URL, body, session.token)
    return { id: pickFamilyId(data), name: String(data?.familyName ?? "") }
  } catch {
    return { id: "", name: "" }
  }
}

/** 只要 ID 的便捷版 */
export async function resolveFamilyId(session: Session): Promise<string> {
  const f = await resolveFamily(session)
  return f.id
}

/** 查这台设备绑定的是哪个手机号；未绑定时返回 null（resultCode 20024） */
export async function fetchBoundPhone(session: Session, mac: string): Promise<string | null> {
  const body = { appType: APP_TYPE, mac: normalizeMac(mac), token: session.token, appVersion: APP_VERSION }
  const { data } = await postJson<any>(PHONE_URL, body, session.token)
  const code = Number(data?.resultCode ?? -1)
  if (code === 0) return data?.phone ? String(data.phone) : null
  if (code === 20024) return null
  throw new ApiError(describe(data) || "查询绑定手机号失败", code)
}

/** 解绑设备。成功后需要重新拉设备列表。 */
export async function unbindDevice(session: Session, mac: string): Promise<void> {
  const body = buildUnbindBody(session.username || session.loginName, normalizeMac(mac))
  const { data } = await postJson<any>(UNBIND_URL, body, session.token)
  const code = Number(data?.resultCode ?? -1)
  if (code !== 0) throw new ApiError(describe(data) || "解绑失败", code)
}

export async function renameDevice(session: Session, mac: string, name: string) {  const { data, wire } = await postJson<any>(
    DEVICE_RENAME_URL,
    buildRenameBody(mac, name, session.token),
    session.token
  )
  const code = Number(data?.resultCode ?? -1)
  if (code !== 0) throw new ApiError(describe(data) || "修改设备名称失败", code)
  return { wire, data }
}

// ---------------- 业务接口 ----------------

/** 账号 + 密码登录（密码在本地做 SHA-256，小写 hex） */
export async function loginWithPassword(
  loginName: string,
  password: string
): Promise<{ session: Session; wire: WireInfo; data: any }> {
  const body = buildLoginBody(loginName, password)
  const { data, wire } = await postJson<any>(LOGIN_URL, body)
  const token = data?.token ? String(data.token) : ""
  if (!token) {
    throw new ApiError(describe(data) || "登录失败，请检查账号密码")
  }
  const session: Session = {
    loginName,
    username: String(data?.username ?? loginName),
    token,
    loginAt: Date.now(),
    mode: "password",
    raw: data,
  }
  // 顺手把用户信息（含 familyId / familyName）合并进 session，绑定页就不用再问一次服务端
  try {
    const u = await queryUser(session.username || loginName, token)
    const fid = pickFamilyId(u.raw) || pickFamilyId(u.user)
    session.raw = { ...(data as any), ...(u.user as any), ...(fid ? { familyId: fid } : {}) }
  } catch {
    /* 拿不到用户信息不影响登录 */
  }
  return { session, wire, data }
}

/** 查询用户信息，同时充当 Token 校验 */
async function queryUser(loginName: string, token: string) {
  const { data, wire } = await postJson<any>(USER_INFO_URL, buildUserInfoBody(loginName, token), token)
  const code = Number(data?.resultCode ?? -1)
  const username = data?.username ? String(data.username) : ""
  if (code !== 0 || !username) {
    throw new ApiError(describe(data) || "Token 无效或已失效", code)
  }
  const { resultCode, resultDesc, ...rest } = data
  return { username, user: rest as UserInfo, raw: data, wire }
}

/** 账号 + Token 登录（先用 queryUserInfo 校验） */
export async function loginWithToken(
  loginName: string,
  token: string
): Promise<{ session: Session; wire: WireInfo; data: any }> {
  const trimmed = token.trim()
  if (!trimmed) throw new ApiError("请输入 Token")
  const r = await queryUser(loginName, trimmed)
  const session: Session = {
    loginName,
    username: r.username,
    token: trimmed,
    loginAt: Date.now(),
    mode: "token",
    raw: r.raw,
  }
  return { session, wire: r.wire, data: r.raw }
}

/** 已绑定设备列表 */
export async function fetchDevices(session: Session): Promise<{ devices: DeviceInfo[]; wire: WireInfo }> {
  const { data, wire } = await postJson<any>(DEVICE_LIST_URL, buildDeviceListBody(session.username, session.token), session.token)
  const code = Number(data?.resultCode ?? -1)
  if (code !== 0) throw new ApiError(describe(data) || "获取设备列表失败", code)
  const list: DeviceInfo[] = data?.bindDeviceInfoVOs ?? data?.devices ?? []
  return { devices: list, wire }
}

/** 用户资料 */
export async function fetchUserInfo(session: Session): Promise<{ user: UserInfo | null; wire: WireInfo; raw: any }> {
  const r = await queryUser(session.loginName, session.token)
  return { user: r.user, wire: r.wire, raw: r.raw }
}

// ---------------- 工具 ----------------

export function fmtMac(mac?: string | null): string {
  if (!mac) return "—"
  const s = String(mac).replace(/[^0-9a-fA-F]/g, "").toUpperCase()
  if (s.length !== 12) return String(mac)
  return s.match(/.{2}/g)!.join(":")
}

export function fmtTime(ms?: number | null): string {
  if (!ms) return "—"
  const d = new Date(ms)
  const p = (n: number) => String(n).padStart(2, "0")
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`
}

export function isOnline(d: DeviceInfo): boolean {
  if (typeof d.online === "boolean") return d.online
  return String(d.filinkStatus ?? "") === "1"
}

export function maskToken(t: string): string {
  if (!t) return "—"
  if (t.length <= 8) return t
  return `${t.slice(0, 4)}••••${t.slice(-4)}`
}
