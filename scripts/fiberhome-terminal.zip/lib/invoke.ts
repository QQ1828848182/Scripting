// ---------- 设备级 RPC 网关 ----------
// POST /NetworkPlatform/rest/device/invokeService
//
// 三层信封（已由可用的 Scriptable 实现验证，注意这条链路不需要签名头）：
//   外层      { appVersion, mac, timeout, token, appType, reqParam, operatorId }
//   reqParam  = JSON 字符串 { ID, Version, Plugin_Name, RPCMethod, Parameter }
//   Parameter = JSON 字符串 { CmdType, SequenceId }
//
// 响应：rspParam(字符串) → { Result, return_Parameter } → 去转义 → base64 → JSON

import { fetch } from "scripting"
import { APP_TYPE, APP_VERSION } from "./api"
import { randomUuid32 } from "./sign"

export const INVOKE_URL = "https://home.mifon.com/NetworkPlatform/rest/device/invokeService"

export type InvokeResult<T = any> = {
  ok: boolean
  cmdType: string
  data?: T
  error?: string
  /** 服务端 resultCode；-1000/10001/10002 = 登录失效，20007/20012 = 设备离线 */
  code?: number
  /** 原始响应文本（诊断用，截断到 600 字） */
  raw?: string
}

/** 登录失效（需要重新登录） */
export const AUTH_ERROR_CODES = [-1000, 10001, 10002]
/** 设备离线或未绑定（实测 20007 = "绑定关系不存在"） */
export const DEVICE_ERROR_CODES = [20007, 20012]

/** 设备/服务端的英文 FailReason 翻成中文（已是中文就透传） */
export function zhReason(raw: string): string {
  const s = String(raw ?? "").trim()
  if (!s) return "未知原因"
  if (/[\u4e00-\u9fa5]/.test(s)) return s
  const t = s.toLowerCase()
  if (/not support|unsupport|not implemented/.test(t)) return "设备不支持该操作"
  if (/timeout|timed out/.test(t)) return "设备响应超时"
  if (/not exist|not found|unknown/.test(t)) return "设备不认识这条命令"
  if (/permission|forbidden|unauthor/.test(t)) return "没有权限"
  if (/get .*info failed|get .*failed/.test(t)) return "设备读不到这项数据（硬件或固件不支持）"
  if (/fail/.test(t)) return "设备执行失败"
  return "设备返回异常"
}

export function normalizeMac(mac: string): string {
  return String(mac ?? "").replace(/[^0-9a-fA-F]/g, "").toUpperCase()
}

/** return_Parameter 是「转义过的 base64」，三步剔开 */
export function decodeReturnParam(text: string): any {
  const cleaned = text.replace(/\\\//g, "/").replace(/\\n/g, "").replace(/\\/g, "").trim()
  const bin = Data.fromBase64String(cleaned)
  if (!bin) throw new Error("base64 解码失败")
  const str = bin.toRawString()
  if (!str) throw new Error("base64 内容为空")
  return JSON.parse(str)
}

/** 判断是不是「未实现」的回显包：
 *  设备对不存在的 CmdType 会原样把 Parameter 转成 base64 放回 return_Parameter
 *  判定：返回里没有任何 Status/Result/Error 类字段，且每个 key 都是 CmdType / SequenceId
 *  或我们发过去的自定义字段（即把请求参数原样吐回来）。
 */
export function isEcho(data: any, cmdType: string, paramKeys: string[] = []): boolean {
  if (!data || typeof data !== "object" || Array.isArray(data)) return false
  const keys = Object.keys(data)
  if (keys.length === 0) return true
  // 真实响应一定带状态字段
  if (keys.some(k => /^(Status|status|Result|result|resultCode|Error|error)$/.test(k))) return false
  const allowed = new Set(["CmdType", "SequenceId", "ContentType", ...paramKeys])
  if (!keys.every(k => allowed.has(k))) return false
  const echoed = String((data as any).CmdType ?? "").toUpperCase()
  return echoed === cmdType.toUpperCase()
}

/** 设备业务层失败：外层 Result=0，但载荷里 Status 非 0（通常同时带 FailReason）
 *  例：GET_LED_STATUS 带 {"Status":""} → {Status:"1", FailReason:"get led info failed"} */
export function businessError(data: any): string | null {
  if (!data || typeof data !== "object" || Array.isArray(data)) return null
  const st = String((data as any).Status ?? (data as any).status ?? "")
  const reason = (data as any).FailReason ?? (data as any).failReason
  if (st !== "" && st !== "0" && st !== "00") {
    return reason ? String(reason) : `Status=${st}`
  }
  return null
}

export async function invokeService<T = any>(
  mac: string,
  token: string,
  cmdType: string,
  params: Record<string, any> = {},
  timeout = 8
): Promise<InvokeResult<T>> {
  // SequenceId 每次唯一，避免服务端缓存/去重
  const parameter = { CmdType: cmdType, SequenceId: `${cmdType}_${Date.now().toString(36)}`, ...params }
  const reqParam = JSON.stringify({
    ID: randomUuid32(),
    Version: "1",
    Plugin_Name: "Plugin_ID",
    RPCMethod: "Post",
    Parameter: JSON.stringify(parameter),
  })

  const body = {
    appVersion: APP_VERSION,
    mac: normalizeMac(mac),
    timeout: 3,
    token,
    appType: APP_TYPE,
    reqParam,
    operatorId: String(Date.now()),
  }

  try {
    const res = await fetch(INVOKE_URL, {
      method: "POST",
      headers: { "content-type": "application/json", token },
      body: JSON.stringify(body),
      timeout,
      debugLabel: `invoke.${cmdType}`,
    })
    const text = await res.text()
    if (!res.ok) return { ok: false, cmdType, error: `HTTP ${res.status}`, code: res.status, raw: text.slice(0, 600) }

    let outer: any
    try {
      outer = JSON.parse(text)
    } catch {
      return { ok: false, cmdType, error: "响应不是 JSON", raw: text.slice(0, 600) }
    }
    if (!outer?.rspParam) {
      const code = typeof outer?.resultCode === "number" ? outer.resultCode : undefined
      const desc = String(outer?.resultDesc ?? "")
      let msg = desc || "响应缺少 rspParam"
      if (code === 20012) msg = "设备离线：云端连不上终端，请确认 CPE 已联网"
      else if (code === 20029) msg = "设备响应超时：终端在线但没回，稍后再试"
      else if (code === 20007) msg = "设备离线：云端不在线"
      return {
        ok: false,
        cmdType,
        error: msg,
        code,
        raw: text.slice(0, 600),
      }
    }

    let inner: any
    try {
      inner = JSON.parse(outer.rspParam)
    } catch {
      return { ok: false, cmdType, error: "rspParam 不是 JSON", raw: text.slice(0, 600) }
    }
    if (Number(inner?.Result) !== 0 || !inner?.return_Parameter) {
      // 失败时设备通常还会带 FailReason，尽量解出来给用户看（如锁频写入的 "json node null"）
      let failData: any = undefined
      if (inner?.return_Parameter) {
        try {
          failData = decodeReturnParam(String(inner.return_Parameter))
        } catch {
          failData = undefined
        }
      }
      const reason = failData?.FailReason ?? failData?.failReason
      return {
        ok: false,
        cmdType,
        data: failData,
        error: reason ? `设备拒绝：${zhReason(String(reason))}` : `设备拒绝（Result=${inner?.Result ?? "?"}）`,
        code: typeof inner?.Result === "number" ? inner.Result : undefined,
        raw: text.slice(0, 600),
      }
    }

    try {
      const data = decodeReturnParam(String(inner.return_Parameter)) as T
      if (isEcho(data, cmdType, Object.keys(params))) {
        return {
          ok: false,
          cmdType,
          error: "命令未实现（设备原样回显请求）",
          raw: text.slice(0, 600),
        }
      }
      return { ok: true, cmdType, data, raw: text.slice(0, 600) }
    } catch (e: any) {
      return { ok: false, cmdType, error: "设备返回的数据解不开（格式不对）", raw: text.slice(0, 600) }
    }
  } catch (e: any) {
    return { ok: false, cmdType, error: `请求没发成功（${zhReason(String(e?.name ?? "网络异常"))}）` }
  }
}
