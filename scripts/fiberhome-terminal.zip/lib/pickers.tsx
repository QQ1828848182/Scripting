// ---------- 小尺寸液态玻璃弹层 ----------
// 系统 sheet 会把弹窗拉成整屏、而且没法控宽高；这里改成页内覆盖层 + 居中玻璃卡（宽 300）。
// 定时重启的时间轮、生效日都用它。

import { VStack, HStack, Text, Image, Spacer, ZStack, useColorScheme } from "scripting"
import type { Color } from "scripting"
import { glassStyle, fill } from "./ui"

/** 半透明遮罩：点空白处关闭 */
export function Overlay(props: { onDismiss: () => void; children?: any }) {
  return (
    <ZStack
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      background={"rgba(0,0,0,0.32)" as Color}
      contentShape={"rect"}
      onTapGesture={props.onDismiss}
    >
      {props.children}
    </ZStack>
  )
}

/** 居中玻璃卡（点卡片本身不关闭） */
export function GlassDialog(props: { width?: number; children?: any }) {
  const scheme = useColorScheme()
  const bg = scheme === "dark" ? "rgba(58,58,64,0.94)" : "rgba(250,250,252,0.92)"
  return (
    <VStack
      spacing={10}
      padding={14}
      frame={{ width: props.width ?? 300 }}
      glassEffect={glassStyle({ cornerRadius: 26 })}
      background={fill(bg, 26)}
      contentShape={"rect"}
      onTapGesture={() => {}}
    >
      {props.children}
    </VStack>
  )
}

/** 底部两颗小胶囊按钮 */
export function DialogButtons(props: {
  accent: Color
  onCancel: () => void
  onDone: () => void
  doneTitle?: string
}) {
  const { accent, onCancel, onDone, doneTitle = "确定" } = props
  const scheme = useColorScheme()
  const cancelBg = scheme === "dark" ? "rgba(255,255,255,0.16)" : "rgba(120,120,128,0.18)"
  return (
    <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
      <HStack
        spacing={0}
        padding={{ vertical: 8 }}
        frame={{ maxWidth: "infinity" }}
        background={fill(cancelBg, 12)}
        contentShape={"rect"}
        onTapGesture={onCancel}
      >
        <Spacer />
        <Text font="subheadline">取消</Text>
        <Spacer />
      </HStack>
      <HStack
        spacing={0}
        padding={{ vertical: 8 }}
        frame={{ maxWidth: "infinity" }}
        background={fill(accent, 12, 0.92)}
        contentShape={"rect"}
        onTapGesture={onDone}
      >
        <Spacer />
        <Text font="subheadline" fontWeight="semibold" foregroundStyle={"#FFFFFF" as Color}>
          {doneTitle}
        </Text>
        <Spacer />
      </HStack>
    </HStack>
  )
}

/** 星期多选：紧凑列表 */
export function WeekdayDialog(props: {
  title?: string
  week: { d: string; label: string }[]
  days: string[]
  accent: Color
  onToggle: (d: string) => void
  onCancel: () => void
  onDone: () => void
}) {
  const { title = "生效日", week, days, accent, onToggle, onCancel, onDone } = props
  return (
    <GlassDialog width={280}>
      <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
        <Text font="subheadline" fontWeight="semibold">
          {title}
        </Text>
        <Spacer />
        <Text font="caption" foregroundStyle="secondaryLabel">
          已选 {days.length} 天
        </Text>
      </HStack>

      <VStack spacing={0} frame={{ maxWidth: "infinity" }}>
        {week.map(w => (
          <HStack
            key={w.d}
            spacing={10}
            padding={{ vertical: 7, horizontal: 10 }}
            frame={{ maxWidth: "infinity" }}
            contentShape={"rect"}
            onTapGesture={() => onToggle(w.d)}
          >
            <Text font="subheadline">{w.label}</Text>
            <Spacer />
            <Image
              systemName={days.includes(w.d) ? "checkmark.circle.fill" : "circle"}
              font="subheadline"
              foregroundStyle={days.includes(w.d) ? accent : "quaternaryLabel"}
            />
          </HStack>
        ))}
      </VStack>

      <DialogButtons accent={accent} onCancel={onCancel} onDone={onDone} />
    </GlassDialog>
  )
}
