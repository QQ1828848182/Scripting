// ---------- 12.har 落实的 6 个新命令（都实测 Status=0） ----------
// GET_WIFI_LIST_INFO / GET_GUEST_WIFI_LIST_INFO / SMS_GET_MESSAGE
// SMS_DEL_MESSAGE_LIST / QUERY_WAN_INFO / SET_HG_BASE_INFO

import { invokeService } from "./invoke"

export type WifiEntry = {
  /** "0" = 2.4G， "1" = 5G */
  type: string
  ssid: string
  pwd: string
  encrypt: string
  enable: string
  bandwidth: string
  power: string
  index: string
  advertise: string
  mode: string
  channel: string
  isolation: string
}

export type WifiRadioSet = {
  radio2: string
  radio5: string
  staCtrl: string
  mloCtrl: string
  list: WifiEntry[]
}

function str(v: any): string {
  if (v === null || v === undefined) return ""
  return String(v)
}

function parseWifiList(data: any): WifiEntry[] {
  const arr: any[] = Array.isArray(data?.WIFIList) ? data.WIFIList : []
  return arr.map(it => ({
    type: str(it.Type),
    ssid: str(it.SSID),
    pwd: str(it.PWD),
    encrypt: str(it.ENCRYPT),
    enable: str(it.Enable),
    bandwidth: str(it.Bandwidth),
    power: str(it.PowerLevel),
    index: str(it.SSIDIndex),
    advertise: str(it.AdvertisementEnable),
    mode: str(it.Mode),
    channel: str(it.Channel),
    isolation: str(it.Isolation),
  }))
}

async function fetchRadioSet(
  mac: string,
  token: string,
  cmd: string
): Promise<{ ok: boolean; error?: string; data?: WifiRadioSet; raw?: any }> {
  const r = await invokeService<any>(mac, token, cmd, {}, 10)
  if (!r.ok) return { ok: false, error: `${r.error ?? "读取失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}` }
  const d = r.data ?? {}
  return {
    ok: true,
    raw: d,
    data: {
      radio2: str(d.radio_enable_2),
      radio5: str(d.radio_enable_5),
      staCtrl: str(d.StaCtrl),
      mloCtrl: str(d.MloCtrl),
      list: parseWifiList(d),
    },
  }
}

/** 主 Wi-Fi（2.4G + 5G 全部 SSID 槽位） */
export function fetchMainWifi(mac: string, token: string) {
  return fetchRadioSet(mac, token, "GET_WIFI_LIST_INFO")
}

/** 访客 Wi-Fi */
export function fetchGuestWifi(mac: string, token: string) {
  return fetchRadioSet(mac, token, "GET_GUEST_WIFI_LIST_INFO")
}

// ---------------- 短信 ----------------

export type SmsSlot = { index: string; opened: boolean }

export type SmsMessage = {
  index: string
  dir: "recv" | "send"
  /** 收件 = 发件人，发件 = 收件人 */
  peer: string
  body: string
  time: string
  opened: boolean
  encode: string
}

/** SMS_UPGRADE_MESSAGE：只给索引（+ 已读状态） */
export async function fetchSmsIndex(mac: string, token: string): Promise<{
  ok: boolean
  error?: string
  recv: SmsSlot[]
  send: SmsSlot[]
}> {
  const r = await invokeService<any>(mac, token, "SMS_UPGRADE_MESSAGE", {}, 10)
  if (!r.ok) return { ok: false, error: `${r.error ?? "读取失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`, recv: [], send: [] }
  const d = r.data ?? {}
  const pick = (re: RegExp): any[] => {
    for (const k of Object.keys(d)) {
      const v = (d as any)[k]
      if (Array.isArray(v) && re.test(k)) return v
    }
    return []
  }
  const toSlots = (arr: any[]): SmsSlot[] =>
    arr
      .map(it => ({ index: str(it?.Index ?? it?.index), opened: str(it?.Isopened ?? it?.iSopened ?? "1") === "1" }))
      .filter(s => s.index !== "")
  return { ok: true, recv: toSlots(pick(/recv/i)), send: toSlots(pick(/send/i)) }
}

/** SMS_GET_MESSAGE：一次最多 20 条，返回正文 */
export async function fetchSmsMessages(
  mac: string,
  token: string,
  recv: SmsSlot[],
  send: SmsSlot[]
): Promise<{ ok: boolean; error?: string; list: SmsMessage[]; sensitive: boolean }> {
  const out: SmsMessage[] = []
  let sensitive = false
  let lastError = ""
  for (let i = 0; i < Math.max(recv.length, send.length); i += 20) {
    const rc = recv.slice(i, i + 20)
    const sd = send.slice(i, i + 20)
    if (rc.length === 0 && sd.length === 0) break
    const r = await invokeService<any>(
      mac,
      token,
      "SMS_GET_MESSAGE",
      {
        recv_index_list: rc.map(s => ({ Index: s.index, iSopened: s.opened ? "1" : "0" })),
        send_index_list: sd.map(s => ({ Index: s.index })),
      },
      12
    )
    if (!r.ok) {
      lastError = `${r.error ?? "读取失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`
      continue
    }
    const d = r.data ?? {}
    if (str(d.SensitiveInfo) === "1") sensitive = true
    for (const m of Array.isArray(d.recv_msg_list) ? d.recv_msg_list : []) {
      out.push({
        index: str(m.Index),
        dir: "recv",
        peer: str(m.Sender) || "未知号码",
        body: str(m.Msg),
        time: str(m.Recvtime),
        opened: str(m.Isopened ?? "1") === "1",
        encode: str(m.Encode),
      })
    }
    for (const m of Array.isArray(d.send_msg_list) ? d.send_msg_list : []) {
      out.push({
        index: str(m.Index),
        dir: "send",
        peer: str(m.Receiver) || "未知号码",
        body: str(m.Msg),
        time: str(m.Sendtime),
        opened: true,
        encode: str(m.Encode),
      })
    }
  }
  return { ok: out.length > 0, error: out.length > 0 ? undefined : lastError, list: out, sensitive }
}

/** SMS_SEND_MESSAGE：{Receiver, Msg, Encode} —— Encode 必填（缺了设备报 param json is null） */
export async function sendSms(
  mac: string,
  token: string,
  receiver: string,
  msg: string
): Promise<{ ok: boolean; error?: string }> {
  const r = await invokeService<any>(
    mac,
    token,
    "SMS_SEND_MESSAGE",
    {
      Receiver: receiver,
      Msg: msg,
      // 设备只要 Encode 不为空就收；含中文时用 UCS2
      Encode: /[^\x00-\x7F]/.test(msg) ? "UCS2" : "GSM",
    },
    30
  )
  if (!r.ok) return { ok: false, error: `${r.error ?? "发送失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}` }
  const status = str(r.data?.Status)
  if (status !== "" && status !== "0") return { ok: false, error: str(r.data?.FailReason) || `设备返回 Status=${status}` }
  return { ok: true }
}

/** SMS_DEL_MESSAGE_LIST：按索引删短信 */
export async function deleteSmsMessages(
  mac: string,
  token: string,
  recvIndexes: string[],
  sendIndexes: string[]
): Promise<{ ok: boolean; error?: string }> {
  if (recvIndexes.length === 0 && sendIndexes.length === 0) return { ok: true }
  const r = await invokeService<any>(
    mac,
    token,
    "SMS_DEL_MESSAGE_LIST",
    {
      recv_index_list: recvIndexes.map(i => ({ Index: i })),
      send_index_list: sendIndexes.map(i => ({ Index: i })),
    },
    12
  )
  if (!r.ok) return { ok: false, error: `${r.error ?? "删除失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}` }
  const status = str(r.data?.Status)
  if (status !== "" && status !== "0") return { ok: false, error: `设备返回 Status=${status}` }
  return { ok: true }
}

/** SMS_SET_MESSAGE_OPENSTATE：把接收短信标为已读（字段名来自逆向分析包，尚未实测） */
export async function markSmsRead(
  mac: string,
  token: string,
  recvIndexes: string[]
): Promise<{ ok: boolean; error?: string }> {
  if (recvIndexes.length === 0) return { ok: true }
  const r = await invokeService<any>(
    mac,
    token,
    "SMS_SET_MESSAGE_OPENSTATE",
    { recv_index_list: recvIndexes.map(i => ({ Index: i, iSopened: "1" })) },
    12
  )
  if (!r.ok) return { ok: false, error: `${r.error ?? "标记失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}` }
  const status = str(r.data?.Status)
  if (status !== "" && status !== "0") return { ok: false, error: `设备返回 Status=${status}` }
  return { ok: true }
}

// ---------------- WAN ----------------

export type WanInfo = {
  connectionStatus: string
  connectionType: string
  addressType: string
  ip: string
  mask: string
  gateway: string
  dns1: string
  dns2: string
  natEnable: string
  vlanId: string
  vlanPriority: string
  serviceList: string
  protocol: string
  linkMode: string
  percent: string
  /** IPv6 */
  v6Status: string
  v6Ip: string
  v6PrefixLen: string
  v6Gateway: string
  v6Dns1: string
  v6Dns2: string
  pppUser: string
  raw: any
}

export async function fetchWanInfo(mac: string, token: string): Promise<{ ok: boolean; error?: string; data?: WanInfo }> {
  const r = await invokeService<any>(mac, token, "QUERY_WAN_INFO", { WANName: "" }, 12)
  if (!r.ok) return { ok: false, error: `${r.error ?? "读取失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}` }
  const d = r.data ?? {}
  return {
    ok: true,
    data: {
      connectionStatus: str(d.CONNECTIONSTATUS),
      connectionType: str(d.CONNECTIONTYPE),
      addressType: str(d.ADDRESSTYPE),
      ip: str(d.IPADDRESS),
      mask: str(d.SUBNETMASK),
      gateway: str(d.GATEWAY),
      dns1: str(d.DNS1),
      dns2: str(d.DNS2),
      natEnable: str(d.NATENABLE),
      vlanId: str(d.VLANID),
      vlanPriority: str(d.VLANPRIORITY),
      serviceList: str(d.SERVICELIST),
      protocol: str(d.PROTOCOL),
      linkMode: str(d.LinkMode),
      percent: str(d.Percent),
      v6Status: str(d.IPV6_CONNECTIONSTATUS),
      v6Ip: str(d.IPV6_IPADDRESS),
      v6PrefixLen: str(d.IPV6_PREFIXLENGTH),
      v6Gateway: str(d.IPV6_GATEWAY),
      v6Dns1: str(d.IPV6_DNS1),
      v6Dns2: str(d.IPV6_DNS2),
      pppUser: str(d.PPPOE_USR_NAME),
      raw: d,
    },
  }
}

/** SET_WIFI_LIST_INFO：整份 Wi-Fi 配置原样回写（只改用户动过的字段） */
export async function setWifiList(
  mac: string,
  token: string,
  payload: { WIFIList: any[]; StaCtrl?: string; MloCtrl?: string }
): Promise<{ ok: boolean; error?: string }> {
  // 13.har 实测：真命令是 SET_WIFI_INFO_LIST，Parameter 只带 WIFILIST / StaCtrl / MloCtrl
  // （没有 radio_enable_*，槽位里也不带 isLoading 以外的多余字段；isLoading 固定 false）
  const list = (payload.WIFIList ?? []).map(it => {
    const { isLoading, ...rest } = it ?? {}
    return { isLoading: false, ...rest }
  })
  const r = await invokeService<any>(
    mac,
    token,
    "SET_WIFI_INFO_LIST",
    {
      SequenceId: "wifi_m_set",
      WIFILIST: list,
      StaCtrl: payload.StaCtrl ?? "0",
      MloCtrl: payload.MloCtrl ?? "0",
    },
    25
  )
  if (!r.ok) return { ok: false, error: `${r.error ?? "写入失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}` }
  const status = str(r.data?.Status)
  if (status !== "" && status !== "0") {
    return { ok: false, error: `设备拒绝：${str(r.data?.FailReason) || `Status=${status}`}` }
  }
  return { ok: true }
}

// ---------------- 接入设备 ----------------

/** SET_HG_BASE_INFO.OfflineDevSwitch：是否保留/显示离线设备 */
export async function setOfflineDevSwitch(mac: string, token: string, on: boolean): Promise<{ ok: boolean; error?: string }> {
  const r = await invokeService<any>(mac, token, "SET_HG_BASE_INFO", { OfflineDevSwitch: on ? "1" : "0" }, 12)
  if (!r.ok) return { ok: false, error: `${r.error ?? "写入失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}` }
  const status = str(r.data?.Status)
  if (status !== "" && status !== "0") return { ok: false, error: `设备返回 Status=${status}` }
  return { ok: true }
}

// ---------------- 固件升级 ----------------

/** HG_GET_UPDATE_STATUS 的设备侧升级状态（6.har 实测） */
export type UpdateStatus = {
  /** 设备当前固件版本，如 RP0110 */
  fwVersion: string
  /** 固件编译时间，如 2025-12-04 21:09:53 +0800 */
  fwData: string
  hwVersion: string
  deviceType: string
  /** "0" = 没有新版本 / 空闲；1 = 已受理；2 = 下载/升级中 */
  upStatus: string
  /** 区域码，HG_IMAGE_DOWNLOAD 必须带上（7.har 实测） */
  areaCode: string
  /** 服务端给的目标版本（选了包才有） */
  updateUrl: string
  image: string
  progress: string
}

/**
 * 读设备升级状态
 * 6.har：HG_GET_UPDATE_STATUS {} → Status / DeviceType / FWDATA / name / AreaCode / HWVersion / FWVersion / up_status
 * 旧接口 GET_UPDATE_STATUS 包在 MainRouter 里，作回退
 */
export async function fetchUpdateStatus(mac: string, token: string): Promise<{ ok: boolean; data?: UpdateStatus; error?: string }> {
  let r = await invokeService<any>(mac, token, "HG_GET_UPDATE_STATUS", {}, 10)
  if (!r.ok) {
    const back = await invokeService<any>(mac, token, "GET_UPDATE_STATUS", {}, 10)
    if (!back.ok) return { ok: false, error: r.error ?? "读取升级状态失败" }
    r = back
  }
  const d = r.data?.MainRouter ?? r.data ?? {}
  return {
    ok: true,
    data: {
      fwVersion: str(d.FWVersion),
      fwData: str(d.FWDATA).trim(),
      hwVersion: str(d.HWVersion),
      deviceType: str(d.DeviceType),
      upStatus: str(d.up_status),
      areaCode: str(d.AreaCode),
      updateUrl: str(d.UpdateUrl ?? d.update_url),
      image: str(d.Image ?? d.image),
      progress: str(d.Progress ?? d.progress),
    },
  }
}
