// ---------- 设备快照：并发拉 5 个 CmdType 并归一化 ----------

import { invokeService, AUTH_ERROR_CODES } from "./invoke"
import type { Color } from "scripting"

const CACHE_KEY = "cpe.snapshot.v1"

export type Carrier = {
  role: "PCC" | "SCC"
  band: string
  arfcn: string
  pci: string
  rsrp: string
  sinr: string
  bandwidth: string
}

export type DeviceSnapshot = {
  at: number
  operator: string
  workMode: string
  band: string
  pci: string
  arfcn: string
  rsrp: number | null
  sinr: number | null
  rsrq: number | null
  rssi: number | null
  dlAmbrKbps: number | null
  ulAmbrKbps: number | null
  qci: string
  carriers: Carrier[]
  dayRxMb: number | null
  dayTxMb: number | null
  monthRxMb: number | null
  monthTxMb: number | null
  /** 套餐限额（MB）与开关；限幅字段拼写是 limmit 双 m */
  monthLimitMb: number | null
  monthLimitOn: boolean
  dayLimitMb: number | null
  dayLimitOn: boolean
  /** 账单月起始日（1~31），用于算“多少天后重置” */
  monthStartDay: number | null
  fw: string
  cpu: string
  ram: string
  /** 拓扑里的实时速率（DownSpeed/UpSpeed，单位 KB/s，已换成 Kbps） */
  downKbpsLive: number | null
  upKbpsLive: number | null
  /** 拓扑里的 SignalLevel（0~5，拿不到为 null） */
  signalLevel: number | null
  /** 芯片/整机温度 ℃（拓扑里带 temp 的字段，取不到为 null） */
  tempC: number | null
  /** 拓扑原始 JSON（温度长按复制用，便于定位字段名） */
  topoRaw: string
  uptimeSec: number | null
  /** 拓扑里的在线设备数（MainBaseInfo 中 NetStatus=1 的条数） */
  onlineDevices: number
  netStatus: string
}

/** diff = 两次采样差分；ambr = 签约上限兜底；idle = 两次采样没变化；live = 拓扑里的实时读数 */
export type Rate = {
  downKbps: number | null
  upKbps: number | null
  source: "diff" | "ambr" | "idle" | "live"
}

export type SnapshotResult = {
  snapshot: DeviceSnapshot
  rate: Rate
  errors: string[]
  /** token 失效（需要重新登录） */
  authFailed: boolean
}

function num(v: any): number | null {
  const n = parseFloat(String(v ?? ""))
  return Number.isFinite(n) ? n : null
}

function str(v: any): string {
  const s = String(v ?? "").trim()
  return s && s !== "-" && s !== "--" ? s : ""
}

const OPERATOR_MAP: [RegExp, string][] = [
  [/CMCC|CHINA MOBILE|中国移动/i, "中国移动"],
  [/CUCC|UNICOM|中国联通/i, "中国联通"],
  [/CTCC|CHINA TELECOM|中国电信|^CT$/i, "中国电信"],
  [/CBN|CHINA BROADCAST|中国广电/i, "中国广电"],
]

function mapOperator(raw: string): string {
  for (const [re, name] of OPERATOR_MAP) {
    if (re.test(raw)) return name
  }
  return raw || "—"
}

/** 78 → n78；3 → B3 */
function normalizeBand(v: string): string {
  if (!v) return "—"
  if (/^[nNbB]/.test(v)) return v
  const n = parseInt(v, 10)
  if (!Number.isFinite(n)) return v
  return n >= 40 ? `n${n}` : `B${n}`
}

function parseTraffic(t: any) {
  return {
    dayRxMb: num(t?.day_rx_traffic),
    dayTxMb: num(t?.day_tx_traffic),
    monthRxMb: num(t?.month_rx_traffic),
    monthTxMb: num(t?.month_tx_traffic),
  }
}

/** 限额字段：设备拼写是 limmit（双 m），两种都兼容 */
function parseLimit(t: any) {
  const flag = (v: any) => String(v ?? "0") === "1"
  return {
    monthLimitMb: num(t?.month_max_traffic),
    monthLimitOn: flag(t?.month_limmit_enable ?? t?.month_limit_enable),
    dayLimitMb: num(t?.day_max_traffic),
    dayLimitOn: flag(t?.day_limmit_enable ?? t?.day_limit_enable),
    monthStartDay: num(t?.month_start_day),
  }
}

/** 温度字段名：宽松匹配（排除 attempt/template 这类假阳性） */
const TEMP_KEY = /temp|温度|celsius|摄氏/i
const TEMP_SKIP = /attempt|template|contemplate|tempo/i

function tempFromValue(v: any): number | null {
  if (v === null || v === undefined) return null
  if (typeof v === "number") return v > -40 && v < 150 ? v : null
  if (typeof v === "string") {
    const m = v.replace(/,/g, ".").match(/-?\d+(\.\d+)?/)
    if (!m) return null
    const n = parseFloat(m[0])
    return Number.isFinite(n) && n > -40 && n < 150 ? n : null
  }
  if (typeof v === "object") {
    for (const k of ["value", "val", "cur", "current", "Value", "temperature", "temp"]) {
      const r = tempFromValue((v as any)[k])
      if (r !== null) return r
    }
  }
  return null
}

/** 在任意嵌套结构里找温度：先看本层 key，再递归（cpu/chip/board 优先） */
function findTempEntry(src: any, depth = 0): { key: string; value: number } | null {
  if (!src || typeof src !== "object" || depth > 5) return null
  const keys = Object.keys(src)
  for (const k of keys) {
    const v = (src as any)[k]
    if (v && typeof v === "object") continue
    if (TEMP_SKIP.test(k) || !TEMP_KEY.test(k)) continue
    const r = tempFromValue(v)
    if (r !== null) return { key: k, value: r }
  }
  const pri = keys.filter(k => /cpu|chip|board|soc|main|core|device|modem/i.test(k))
  for (const k of [...pri, ...keys.filter(k => pri.indexOf(k) < 0)]) {
    const v = (src as any)[k]
    if (v && typeof v === "object") {
      const r = findTempEntry(v, depth + 1)
      if (r !== null) return r
    }
  }
  return null
}

function findTemp(src: any, depth = 0): number | null {
  return findTempEntry(src, depth)?.value ?? null
}

/** 兼底：任何字符串里带 ℃ / °C 的数字（如 "CPU 46.3℃"） */
function findCelsius(src: any, depth = 0): number | null {
  if (!src || typeof src !== "object" || depth > 5) return null
  for (const k of Object.keys(src)) {
    const v = (src as any)[k]
    if (typeof v === "string" && /℃|°C|摄氏/.test(v)) {
      const m = v.match(/(-?\d+(\.\d+)?)\s*(℃|°C|摄氏)/)
      if (m) {
        const n = parseFloat(m[1])
        if (Number.isFinite(n) && n > -40 && n < 150) return n
      }
    }
    if (v && typeof v === "object") {
      const r = findCelsius(v, depth + 1)
      if (r !== null) return r
    }
  }
  return null
}

// ---------------- 温度接口探测（只读 GET，结果写进 Storage 以后直接复用） ----------------

export type TempSource = { cmd: string; key: string }
const TEMP_SRC_KEY = "cpe.temp.source.v1"

export function loadTempSource(): TempSource | null {
  try {
    const raw = Storage.get<string>(TEMP_SRC_KEY)
    if (!raw) return null
    const v = JSON.parse(raw)
    return v && typeof v.cmd === "string" ? (v as TempSource) : null
  } catch {
    return null
  }
}

function saveTempSource(s: TempSource) {
  try {
    Storage.set(TEMP_SRC_KEY, JSON.stringify(s))
  } catch {
    /* ignore */
  }
}

/** 候选命令：全部是只读 GET，探测不会改动设备 */
export const TEMP_CANDIDATES = [
  "GET_DEVICE_INFO",
  "GET_DEVICE_STATUS",
  "GET_SYSTEM_INFO",
  "GET_SYSTEM_STATUS",
  "GET_BOARD_INFO",
  "GET_HARDWARE_INFO",
  "GET_MODEM_INFO",
  "GET_MODEM_STATUS",
  "GET_TEMPERATURE_INFO",
  "GET_DEVICE_TEMPERATURE",
  "GET_TEMP_INFO",
  "CPE_TEMPERATURE",
  "GET_CPU_INFO",
  "GET_ENV_INFO",
  "GET_DEVICE_BASE_INFO",
  "GET_DEVICE_STATUS_INFO",
  "GET_DEVICE_RUN_INFO",
  "GET_RUN_INFO",
  "GET_ROUTER_STATUS",
  "GET_BOARD_TEMPERATURE",
  "GET_SYSTEM_STATUS_INFO",
  "GET_DEVICE_TEMP",
  "CPE_DEVICE_STATUS",
]

/** 逐个试候选命令，找出哪个返回带温度的字段（命中就存起来以后直接用） */
export async function probeTemperature(
  mac: string,
  token: string
): Promise<{ report: string; found: TempSource | null }> {
  const lines: string[] = []
  let found: TempSource | null = null
  for (const cmd of TEMP_CANDIDATES) {
    const r = await invokeService<any>(mac, token, cmd, {}, 8)
    if (!r.ok) {
      lines.push(`${cmd}: ✗ ${String(r.error ?? "").slice(0, 36)}`)
      continue
    }
    const data = r.data ?? {}
    const keys = Object.keys(data)
    const entry = findTempEntry(data)
    lines.push(`${cmd}: ✓ keys=[${keys.slice(0, 12).join(",")}]${entry ? `  ★${entry.key}=${entry.value}` : ""}`)
    if (entry && !found) {
      found = { cmd, key: entry.key }
      lines.push(`  DATA ${JSON.stringify(data).slice(0, 600)}`)
    }
  }
  if (found) saveTempSource(found)
  return { report: lines.join("\n"), found }
}

function emptySnapshot(): DeviceSnapshot {
  return {
    at: Date.now(),
    operator: "—",
    workMode: "—",
    band: "—",
    pci: "—",
    arfcn: "—",
    rsrp: null,
    sinr: null,
    rsrq: null,
    rssi: null,
    dlAmbrKbps: null,
    ulAmbrKbps: null,
    qci: "—",
    carriers: [],
    dayRxMb: null,
    dayTxMb: null,
    monthRxMb: null,
    monthTxMb: null,
    monthLimitMb: null,
    monthLimitOn: false,
    dayLimitMb: null,
    dayLimitOn: false,
    monthStartDay: null,
    fw: "",
    cpu: "",
    ram: "",
    downKbpsLive: null,
    upKbpsLive: null,
    signalLevel: null,
    tempC: null,
    topoRaw: "",
    uptimeSec: null,
    onlineDevices: 0,
    netStatus: "",
  }
}

/** 拉齐 5 类数据，任何一路失败都不影响其它路 */
export async function fetchSnapshot(
  mac: string,
  token: string
): Promise<{ snapshot: DeviceSnapshot; errors: string[]; authFailed: boolean }> {
  const [sim, rf, ca, traffic, topo, mn] = await Promise.all([
    invokeService<any>(mac, token, "GET_SIM_INFO"),
    invokeService<any>(mac, token, "GET_RF_SIGNAL_INFO", {}, 6),
    invokeService<any>(mac, token, "GET_CARRIER_AGGREGATION_INFO", {}, 6),
    invokeService<any>(mac, token, "GET_CELLULAR_TRAFFIC_INFO"),
    invokeService<any>(mac, token, "GET_FILINK_TOPOLOGY_INFO"),
    // 温度（modemTemp）可能跟着移动网络信息一起下发，多拉一路没影响
    invokeService<any>(mac, token, "GET_MOBILE_NETWORK", {}),
  ])

  const errors: string[] = []
  let authFailed = false
  for (const r of [sim, rf, ca, traffic, topo]) {
    if (!r.ok) {
      errors.push(`${r.cmdType}: ${r.error}`)
      if (typeof r.code === "number" && AUTH_ERROR_CODES.indexOf(r.code) >= 0) authFailed = true
    }
  }
  // 移动网络那一路只为了拿温度，失败不报错

  const snap = emptySnapshot()
  const s = sim.data ?? {}
  const r = rf.data ?? {}
  const c = ca.data ?? {}
  const t = traffic.data ?? {}
  const top = topo.data?.MainRouter ?? topo.data?.Router ?? topo.data ?? {}

  snap.at = Date.now()
  snap.operator = mapOperator(str(s.Operator) || str(s.SPN))

  // 信号
  snap.rsrp = num(r.SSB_RSRP ?? r.RSRP ?? c.main_CA_info?.RSRP)
  snap.sinr = num(r.SSB_SINR ?? r.SINR ?? c.main_CA_info?.SINR)
  snap.rsrq = num(r.SSB_RSRQ ?? r.RSRQ ?? c.main_CA_info?.RSRQ)
  snap.rssi = num(r.SSB_RSSI ?? r.RSSI ?? c.main_CA_info?.RSSI)
  snap.pci = str(r.PCI) || str(c.main_CA_info?.PCI) || "—"
  snap.arfcn = str(r.EARFCN) || str(c.main_CA_info?.Arfcn) || "—"
  snap.band = normalizeBand(str(r.BAND) || str(r.NR_BAND) || str(r.LTE_BAND) || str(c.main_CA_info?.Band))
  snap.dlAmbrKbps = num(r.DL_AMBR)
  snap.ulAmbrKbps = num(r.UL_AMBR)
  snap.qci = str(r.QCI) || "—"

  // 工作模式：优先用接口值，否则按频段推断（原脚本这里优先级写错了，会崩）
  const rawMode = str(r.WorkMode).toUpperCase()
  if (rawMode) {
    snap.workMode = /SA/.test(rawMode) && !/NSA/.test(rawMode)
      ? "5G SA"
      : /NSA/.test(rawMode)
        ? "5G NSA"
        : /LTE|4G/.test(rawMode)
          ? "4G LTE"
          : rawMode
  } else {
    const bandNum = parseInt(String(c.main_CA_info?.Band ?? r.BAND ?? r.NR_BAND ?? ""), 10)
    snap.workMode = Number.isFinite(bandNum) ? (bandNum >= 40 ? "5G SA" : "4G LTE") : "—"
  }

  // 载波聚合
  const carriers: Carrier[] = []
  const main = c.main_CA_info
  if (main && str(main.Band)) {
    carriers.push({
      role: "PCC",
      band: normalizeBand(str(main.Band)),
      arfcn: str(main.Arfcn) || "—",
      pci: str(main.PCI) || "—",
      rsrp: str(main.RSRP) || (snap.rsrp !== null ? String(snap.rsrp) : "—"),
      sinr: str(main.SINR) || (snap.sinr !== null ? String(snap.sinr) : "—"),
      bandwidth: str(main.DIBandWidth) || "—",
    })
    const subs = Array.isArray(c.sub_CA_info) ? c.sub_CA_info : []
    subs.forEach((sub: any, i: number) => {
      if (!sub || !str(sub.Band)) return
      carriers.push({
        role: "SCC",
        band: normalizeBand(str(sub.Band)),
        arfcn: str(sub.Arfcn) || "—",
        pci: str(sub.PCI) || "—",
        rsrp: str(sub.RSRP) || "—",
        sinr: str(sub.SINR) || "—",
        bandwidth: str(sub.DIBandWidth) || "—",
      })
    })
  } else if (snap.band !== "—") {
    carriers.push({
      role: "PCC",
      band: snap.band,
      arfcn: snap.arfcn,
      pci: snap.pci,
      rsrp: snap.rsrp !== null ? String(snap.rsrp) : "—",
      sinr: snap.sinr !== null ? String(snap.sinr) : "—",
      bandwidth: "—",
    })
  }
  snap.carriers = carriers

  // 流量
  Object.assign(snap, parseTraffic(t))
  Object.assign(snap, parseLimit(t))

  // 设备信息
  snap.fw = str(top.FWVersion)
  snap.cpu = str(top.cpuusage)
  snap.ram = str(top.ramusage)
  // 拓扑里就有实时速率：DownSpeed/UpSpeed 单位是 KB/s（网页版 _spFmt 里 8*t/1000 转 Mbps 可证）
  const downKb = num(top.DownSpeed)
  const upKb = num(top.UpSpeed)
  snap.downKbpsLive = downKb !== null ? downKb * 8 : null
  snap.upKbpsLive = upKb !== null ? upKb * 8 : null
  const sl = num(top.SignalLevel)
  snap.signalLevel = sl !== null && sl >= 0 && sl <= 5 ? sl : null
  snap.tempC =
    findTemp(top) ??
    findTemp(topo.data) ??
    findTemp(mn.data) ??
    findTemp(r) ??
    findCelsius(topo.data) ??
    findCelsius(mn.data)
  snap.topoRaw = JSON.stringify({ topology: topo.data ?? {}, mobileNetwork: mn.data ?? {} })

  // 温度在拓扑/移动网络里都没有时，用之前探测到的命令再拉一次
  if (snap.tempC === null) {
    const src = loadTempSource()
    if (src) {
      const tr = await invokeService<any>(mac, token, src.cmd, {}, 8)
      if (tr.ok) snap.tempC = findTemp(tr.data) ?? findCelsius(tr.data)
    }
  }
  snap.uptimeSec = num(top.UpTime)
  snap.netStatus = str(top.NetStatus)

  // 在线设备数：优先用现成字段，否则数 MainBaseInfo 里 NetStatus=1 的条目
  if (typeof top.onlineDevices === "number") {
    snap.onlineDevices = top.onlineDevices
  } else if (Array.isArray(top.MainBaseInfo)) {
    snap.onlineDevices = top.MainBaseInfo.filter((x: any) => String(x?.NetStatus) === "1").length
  }

  return { snapshot: snap, errors, authFailed }
}

/** 只拉流量，用于速率差分的第二次采样 */
export async function fetchTraffic(
  mac: string,
  token: string
): Promise<{ at: number; rx: number; tx: number } | null> {
  const r = await invokeService<any>(mac, token, "GET_CELLULAR_TRAFFIC_INFO")
  if (!r.ok) return null
  const t = parseTraffic(r.data ?? {})
  if (t.dayRxMb === null || t.dayTxMb === null) return null
  return { at: Date.now(), rx: t.dayRxMb, tx: t.dayTxMb }
}

function sleep(ms: number): Promise<void> {
  return new Promise<void>(resolve => setTimeout(() => resolve(), ms))
}

/**
 * 快照 + 速率。
 * 速率优先用两次流量采样差分（方案 A），
 * 差分算不出来（采样失败 / 没变化）就用签约 AMBR 兜底（方案 B）。
 */
export async function fetchSnapshotWithRate(
  mac: string,
  token: string,
  opts: { sampleGapMs?: number } = {}
): Promise<SnapshotResult> {
  const { snapshot, errors, authFailed } = await fetchSnapshot(mac, token)

  // 拓扑里直接有实时速率（KB/s → Kbps）就不用再等 2.2 秒做差分了
  if (snapshot.downKbpsLive !== null && snapshot.upKbpsLive !== null) {
    return {
      snapshot,
      rate: { downKbps: snapshot.downKbpsLive, upKbps: snapshot.upKbpsLive, source: "live" },
      errors,
      authFailed,
    }
  }

  const ambr: Rate = {
    downKbps: snapshot.dlAmbrKbps,
    upKbps: snapshot.ulAmbrKbps,
    source: "ambr",
  }

  if (snapshot.dayRxMb === null || snapshot.dayTxMb === null) {
    return { snapshot, rate: ambr, errors, authFailed }
  }

  const baseRx = snapshot.dayRxMb
  const baseTx = snapshot.dayTxMb
  const baseAt = snapshot.at

  await sleep(opts.sampleGapMs ?? 2200)
  const second = await fetchTraffic(mac, token)
  if (!second) return { snapshot, rate: ambr, errors, authFailed }

  const dt = (second.at - baseAt) / 1000
  if (dt <= 0) return { snapshot, rate: ambr, errors, authFailed }

  const dRx = second.rx - baseRx
  const dTx = second.tx - baseTx

  // MB → kbit/s：MB * 1024 KB * 8 bit / 秒
  const downKbps = dRx > 0 ? (dRx * 8192) / dt : 0
  const upKbps = dTx > 0 ? (dTx * 8192) / dt : 0

  if (downKbps <= 0 && upKbps <= 0) {
    return { snapshot, rate: { downKbps: 0, upKbps: 0, source: "idle" }, errors, authFailed }
  }
  return { snapshot, rate: { downKbps, upKbps, source: "diff" }, errors, authFailed }
}

// ---------------- 本地缓存 ----------------

export function saveSnapshot(s: DeviceSnapshot) {
  try {
    Storage.set(CACHE_KEY, JSON.stringify(s))
  } catch {
    /* ignore */
  }
}

export function loadSnapshot(): DeviceSnapshot | null {
  try {
    const raw = Storage.get<string>(CACHE_KEY)
    if (!raw) return null
    const s = JSON.parse(raw) as DeviceSnapshot
    return s && typeof s.at === "number" ? s : null
  } catch {
    return null
  }
}

// ---------------- 展示格式化 ----------------

/** MB → "123.4 MB" / "1.23 GB" */
export function fmtMb(mb: number | null | undefined): string {
  if (mb === null || mb === undefined || !Number.isFinite(mb)) return "—"
  if (mb >= 1024) return `${(mb / 1024).toFixed(2)} GB`
  if (mb >= 100) return `${mb.toFixed(0)} MB`
  return `${mb.toFixed(1)} MB`
}

/** Kbps → { value, unit } */
export function fmtRate(kbps: number | null | undefined): { value: string; unit: string } {
  if (kbps === null || kbps === undefined || !Number.isFinite(kbps) || kbps < 0) {
    return { value: "—", unit: "Kbps" }
  }
  if (kbps >= 1024 * 1024) return { value: (kbps / 1024 / 1024).toFixed(2), unit: "Gbps" }
  if (kbps >= 1024) return { value: (kbps / 1024).toFixed(1), unit: "Mbps" }
  return { value: kbps.toFixed(0), unit: "Kbps" }
}

/** 信号强度 → 颜色（值越接近 0 越好） */
export function signalColor(rsrp: number | null): Color {
  if (rsrp === null) return "#8E8E93"
  if (rsrp > -90) return "#30D158"
  if (rsrp > -100) return "#FFD60A"
  return "#FF453A"
}

export function qualityText(rsrp: number | null): string {
  if (rsrp === null) return "—"
  if (rsrp > -90) return "优"
  if (rsrp > -100) return "良"
  if (rsrp > -110) return "中"
  return "弱"
}

/** 秒 → "3天 4小时 5分" */
export function fmtUptime(sec: number | null): string {
  if (sec === null || sec <= 0) return "—"
  const d = Math.floor(sec / 86400)
  const h = Math.floor((sec % 86400) / 3600)
  const m = Math.floor((sec % 3600) / 60)
  const parts: string[] = []
  if (d > 0) parts.push(`${d}天`)
  if (h > 0 || d > 0) parts.push(`${h}小时`)
  parts.push(`${m}分`)
  return parts.join(" ")
}

/** "4%" / "48" / 4 → 4（取不到返回 null） */
export function parsePct(v: any): number | null {
  const s = String(v ?? "").replace("%", "").trim()
  if (!s) return null
  const n = parseFloat(s)
  return Number.isFinite(n) ? Math.max(0, Math.min(100, n)) : null
}

/** 距下个账单日还有几天（month_start_day 为月起始日 1~31） */
export function daysToReset(startDay: number | null): number | null {
  if (startDay === null || !Number.isFinite(startDay) || startDay < 1 || startDay > 31) return null
  const now = new Date()
  const y = now.getFullYear()
  const m = now.getMonth()
  let target = new Date(y, m, Math.min(startDay, 28))
  if (now.getDate() >= startDay) target = new Date(y, m + 1, Math.min(startDay, 28))
  const ms = target.getTime() - now.getTime()
  if (ms <= 0) return 0
  return Math.max(0, Math.ceil(ms / 86400000))
}

/** RSRP → 信号格数 1~4 */
export function signalBars(rsrp: number | null): number {
  if (rsrp === null) return 0
  if (rsrp > -85) return 4
  if (rsrp > -95) return 3
  if (rsrp > -105) return 2
  return 1
}

/** 数值色阶（越大越好） */
export function levelColor(kind: "rsrp" | "sinr" | "rsrq", v: number | null): Color {
  if (v === null) return "#8E8E93"
  if (kind === "rsrp") return v > -90 ? "#30D158" : v > -105 ? "#FFD60A" : "#FF453A"
  if (kind === "sinr") return v > 10 ? "#30D158" : v > 0 ? "#FFD60A" : "#FF453A"
  return v > -10 ? "#30D158" : v > -15 ? "#FFD60A" : "#FF453A"
}

/** 数值评审：优 / 良 / 一般 / 较差 */
export function levelText(kind: "rsrp" | "sinr" | "rsrq", v: number | null): string {
  if (v === null) return "—"
  if (kind === "rsrp") return v > -85 ? "优" : v > -95 ? "良" : v > -105 ? "一般" : "较差"
  if (kind === "sinr") return v > 15 ? "优" : v > 5 ? "良" : v > 0 ? "一般" : "较差"
  return v > -8 ? "优" : v > -12 ? "良" : v > -16 ? "一般" : "较差"
}

/** 进度比 0~1（用于细条） */
export function ratio(kind: "rsrp" | "sinr" | "rsrq" | "pct", v: number | null): number {
  if (v === null) return 0
  if (kind === "pct") return Math.max(0, Math.min(1, v / 100))
  if (kind === "rsrp") return Math.max(0, Math.min(1, (v + 130) / 50)) // -130 ~ -80
  if (kind === "sinr") return Math.max(0, Math.min(1, (v + 5) / 35)) // -5 ~ 30
  return Math.max(0, Math.min(1, (v + 20) / 15)) // -20 ~ -5
}
