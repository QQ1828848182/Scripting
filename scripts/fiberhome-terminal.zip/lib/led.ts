// ---------- 指示灯 ----------
// 读：GET_LED_SWITCH  → { Switch: "1"/"0" }
// 写：SET_LED_SWITCH  → { Switch: "1"/"0" }
//
// 按用户实测：设备收到就立刻生效，**不需要回读校验**——
// 开关的「开/关」等价于手动发送 1 / 0，发出去即算成功。
// 真实状态只在进页面 / 下拉刷新时读一次。

import { invokeService } from "./invoke"
import { businessError } from "./invoke"
import { zhError } from "./ui"

/** 设备返回的开关值 → boolean（"1"/"0"、数字、布尔、嵌套对象都兼容） */
export function ledOnValue(data: any): boolean | null {
  if (data === null || data === undefined) return null
  if (typeof data === "boolean") return data
  if (typeof data === "number") return data !== 0
  if (typeof data === "string") {
    const s = data.trim()
    if (/^(1|true|on|open|enable|enabled)$/i.test(s)) return true
    if (/^(0|false|off|close|disable|disabled)$/i.test(s)) return false
    return null
  }
  if (typeof data === "object") {
    for (const k of Object.keys(data)) {
      if (/switch|led|status|enable|light|power/i.test(k)) {
        const v = ledOnValue((data as any)[k])
        if (v !== null) return v
      }
    }
  }
  return null
}

/** 读当前状态（只用于进页/刷新时对齐显示） */
export async function fetchLedSwitch(mac: string, token: string): Promise<{ ok: boolean; on: boolean | null; error: string }> {
  try {
    const r = await invokeService<any>(mac, token, "GET_LED_SWITCH", {}, 8)
    if (!r.ok) return { ok: false, on: null, error: zhError(r.error, "读取指示灯状态失败") }
    const on = ledOnValue(r.data)
    if (on === null) return { ok: false, on: null, error: "设备没返回开关状态" }
    return { ok: true, on, error: "" }
  } catch {
    return { ok: false, on: null, error: "读取指示灯状态失败（网络异常）" }
  }
}

/** 写状态：发一条 `{Switch:"1"|"0"}` 就完事，不回读 */
export async function setLedSwitch(
  mac: string,
  token: string,
  next: boolean
): Promise<{ ok: boolean; on: boolean | null; error: string }> {
  try {
    const r = await invokeService<any>(mac, token, "SET_LED_SWITCH", { Switch: next ? "1" : "0" }, 10)
    if (!r.ok) return { ok: false, on: null, error: zhError(r.error, "指示灯设置失败") }
    const be = businessError(r.data as any)
    if (be) return { ok: false, on: null, error: `设备拒绝：${zhError(be, "指示灯设置失败")}` }
    return { ok: true, on: next, error: "" }
  } catch {
    return { ok: false, on: null, error: "指示灯设置失败（网络异常）" }
  }
}
