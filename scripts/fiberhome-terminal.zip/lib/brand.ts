// ---------- 运营商品牌：名称 → 单字徽标 + 品牌色（纯代码绘制，不用图片资源） ----------

export type Brand = { key: string; name: string; char: string; color: string }

const BRANDS: { re: RegExp; brand: Brand }[] = [
  { re: /电信|telecom|ctcc|天翼|dianxin/i, brand: { key: "telecom", name: "中国电信", char: "电", color: "#0A84FF" } },
  { re: /联通|unicom|cucc|liantong/i, brand: { key: "unicom", name: "中国联通", char: "联", color: "#E60012" } },
  { re: /移动|mobile|cmcc|yidong/i, brand: { key: "cmcc", name: "中国移动", char: "移", color: "#00A650" } },
  { re: /广电|broadnet|cbnet|guangdian/i, brand: { key: "cbn", name: "中国广电", char: "广", color: "#1B6BB0" } },
]

/** 从运营商名称（"中国联通" 之类）认出品牌；认不出返回 null */
export function brandOf(operator: string | null | undefined): Brand | null {
  const s = String(operator ?? "").trim()
  if (!s || s === "—") return null
  for (const it of BRANDS) if (it.re.test(s)) return it.brand
  return null
}
