// ---------- 云端请求签名 ----------
// 由真实抓包反推并用样本验证：
//   signature = SHA256(timestamp + uuid + body)  →  64 位小写 hex
// 其中
//   timestamp = 13 位毫秒（与请求头 timestamp 必须完全一致）
//   uuid      = 32 位大写 HEX（与请求头 uuid 必须完全一致）
//   body      = 实际发送的 JSON 字符串原文（不要重新序列化后再签）

import { sha256 } from "./sha256"

export function makeSignature(timestamp: string, uuid: string, body: string): string {
  return sha256(timestamp + uuid + body).toLowerCase()
}

/** 32 位大写 HEX，首次生成后应固定复用（真实客户端是稳定设备标识） */
export function randomUuid32(): string {
  let s = ""
  for (let i = 0; i < 32; i++) s += Math.floor(Math.random() * 16).toString(16)
  return s.toUpperCase()
}
