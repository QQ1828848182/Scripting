// ---------- 型号能力表（对齐网页版 fhcpeweb.html 的 MODEL_CAPS） ----------
// LG6121HFD / LG6121F / LG6121D = 烽火 Air：没有风扇、没有 MLO
// LG6151M = 烽火 Pro2：风扇 + MLO
// LG6851F = 烽火 Pro：风扇 + MLO
// 未知型号一律按「全功能」处理，宁可多显示也不误藏。

export type ModelCaps = { name: string; fan: boolean; mlo: boolean }

const TABLE: { match: RegExp; caps: ModelCaps }[] = [
  { match: /^LG6121[HFD]/i, caps: { name: "烽火 Air", fan: false, mlo: false } },
  { match: /^LG6151M/i, caps: { name: "烽火 Pro2", fan: true, mlo: true } },
  { match: /^LG6851F/i, caps: { name: "烽火 Pro", fan: true, mlo: true } },
]

function norm(model?: string | null): string {
  const s = String(model ?? "").trim().toUpperCase()
  return s === "--" ? "" : s
}

/** 型号 → 能力；不认识的型号返回 null */
export function modelCaps(model?: string | null): ModelCaps | null {
  const m = norm(model)
  if (!m) return null
  return TABLE.find(t => t.match.test(m))?.caps ?? null
}

/** 是否显示风扇入口（未知型号一律显示） */
export function fanSupported(model?: string | null): boolean {
  return modelCaps(model)?.fan ?? true
}

/** 是否显示 MLO 入口（未知型号一律显示） */
export function mloSupported(model?: string | null): boolean {
  return modelCaps(model)?.mlo ?? true
}
