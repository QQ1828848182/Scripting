// ---------- 工具箱 / 路由设置右侧摘要（带本地缓存） ----------
// 规则（用户要求）：拿到新数据才更新；没拿到就继续显示上一次缓存的值，不要清空。
// 只用已确认可用的只读命令，逐项 try/catch，某项失败不影响其它项。

import { invokeService } from "./invoke"
import { fetchSmsIndex } from "./cmds"

export type Summary = Record<string, string>

const keyOf = (mac: string) => `cpe.summary.v1.${mac}`

/** 读上一次的缓存（页面首次渲染先显示它） */
export function loadCachedSummary(mac: string): Summary {
  try {
    const raw = Storage.get(keyOf(mac))
    if (!raw) return {}
    const obj = JSON.parse(String(raw))
    return obj && typeof obj === "object" ? (obj as Summary) : {}
  } catch {
    return {}
  }
}

function saveCached(mac: string, s: Summary) {
  try {
    Storage.set(keyOf(mac), JSON.stringify(s))
  } catch {}
}

/** SIM 注册状态：RegStatus "0" = 注册成功 */
function regText(v: any): string {
  const s = String(v ?? "").trim()
  if (s === "") return ""
  return s === "0" ? "已注册" : "未注册"
}

function onOff(v: any): boolean {
  return String(v ?? "").trim() === "1"
}

export async function fetchSummary(mac: string, token: string, onUpdate: (patch: Summary) => void) {
  const cache = loadCachedSummary(mac)

  const put = (key: string, v: string) => {
    if (!v) return
    if (cache[key] === v) return
    cache[key] = v
    saveCached(mac, cache)
    onUpdate({ [key]: v })
  }

  // 风扇档位：1=静音 / 0=标准 / 2=性能
  try {
    const r = await invokeService<any>(mac, token, "CPE_FAN_CONTROL", { action: "get", mode: "" }, 8)
    const m = String(r.data?.mode ?? r.data?.Mode ?? "").trim()
    if (m) put("fan", m === "1" ? "静音" : m === "0" ? "标准" : m === "2" ? "性能" : `模式 ${m}`)
  } catch {}

  // 接入设备数
  try {
    const r = await invokeService<any>(mac, token, "GET_FILINK_TOPOLOGY_INFO", {}, 10)
    const arr = r.data?.MainRouter?.MainBaseInfo
    if (r.ok && Array.isArray(arr)) {
      const n = arr.filter((x: any) => String(x?.NetStatus) === "1").length
      put("clients", `${n} 台`)
    }
  } catch {}

  // 本月已用流量（MB → GB）
  try {
    const r = await invokeService<any>(mac, token, "GET_CELLULAR_TRAFFIC_INFO", {}, 10)
    const rx = Number(r.data?.month_rx_traffic)
    const tx = Number(r.data?.month_tx_traffic)
    if (r.ok && (Number.isFinite(rx) || Number.isFinite(tx))) {
      const mb = (Number.isFinite(rx) ? rx : 0) + (Number.isFinite(tx) ? tx : 0)
      put("traffic", mb >= 1024 ? `${(mb / 1024).toFixed(2)} GB` : `${mb.toFixed(1)} MB`)
    }
  } catch {}

  // 短信未读
  try {
    const r = await fetchSmsIndex(mac, token)
    if (r.ok) {
      const n = r.recv.filter(s => !s.opened).length
      put("sms", n > 0 ? `${n} 条未读` : "已读")
    }
  } catch {}

  // 移动网络：SIM 注册状态
  try {
    const r = await invokeService<any>(mac, token, "GET_SIM_INFO", {}, 8)
    if (r.ok) put("mobile", regText(r.data?.RegStatus))
  } catch {}

  // 锁频设置：锁频段 或 锁小区 任一开启 → 已开启
  try {
    const band = await invokeService<any>(mac, token, "GET_LOCK_BAND_INFO", {}, 10)
    const cell = await invokeService<any>(mac, token, "GET_LOCK_CELL_LIST_INFO", {}, 10)
    const bandOn = band.ok && onOff(band.data?.LockFrequencyBand)
    const cellOn = cell.ok && onOff(cell.data?.LockCommunity)
    if (band.ok || cell.ok) put("lock", bandOn || cellOn ? "已开启" : "未开启")
  } catch {}

  // 定时重启：开 → 时间；关 → 已禁用
  try {
    const r = await invokeService<any>(mac, token, "GET_HG_REBOOT_INFO", {}, 8)
    if (r.ok) {
      if (onOff(r.data?.GatewayRebootEnable)) {
        const h = String(r.data?.Hour ?? "").trim().padStart(2, "0")
        const m = String(r.data?.Minute ?? "").trim().padStart(2, "0")
        put("reboot", `${h}:${m}`)
      } else {
        put("reboot", "已禁用")
      }
    }
  } catch {}
}
