// ---------- Liquid Glass 风格组件 ----------
// 修正要点（对照 Scripting 真实 API）：
// - 视图没有 cornerRadius 属性，圆角只能写在 background 的 shape 里，或用 clipShape
// - SF Symbol 用 Image 的 systemName；Text 不能挂符号
// - 颜色参数类型是 Color（模板字面量联合），不能声明成裸 string
// - 裸 { color } 不合法：要么直接传颜色字符串，要么传 { color, opacity }

import { DragGesture, HStack, Image, ProgressView, RoundedRectangle, Spacer, Text, VStack, ZStack } from "scripting"
import type { Color } from "scripting"

export const ACCENT: Color = "#0A84FF"
export const ACCENT_WARM: Color = "#FF9F0A"
export const DANGER: Color = "#FF453A"
export const OK: Color = "#30D158"

/** 是否支持液态玻璃（UIGlass 是全局类，仅在 iOS 26+ 才有实际效果） */
export const GLASS_SUPPORTED = typeof (globalThis as any).UIGlass !== "undefined"

/**
 * 背景填充：把「颜色 + 可选透明度 + 可选圆角」压成 background 需要的形状。
 *
 *   fill("#0A84FF")                 → 纯色
 *   fill("#0A84FF", 14)             → 带 14 圆角的纯色块
 *   fill(DANGER, 14, 0.12)          → 带透明度的圆角色块
 *   fill(someGradient, 20)          → 渐变圆角块
 */
export function fill(style: any, radius?: number, opacity?: number): any {
  const s = opacity === undefined ? style : { color: style, opacity }
  if (radius === undefined) return s
  return { style: s, shape: { type: "rect", cornerRadius: radius } }
}

/** 胶囊背景（Pill / 分段控件） */
export function capsuleFill(style: any, opacity?: number): any {
  const s = opacity === undefined ? style : { color: style, opacity }
  return { style: s, shape: "capsule" }
}

/** 顶部轻提示：液态玻璃胶囊 + 绿✓/红✗ + 文案 */
export function HintPill(props: { text: string; ok?: boolean }) {
  const tone: Color = props.ok === false ? DANGER : OK
  return (
    <HStack
      spacing={8}
      padding={{ horizontal: 14, vertical: 9 }}
      background={fill("#FFFFFF", 20, 0.97)}
    >
      <Image
        systemName={props.ok === false ? "xmark.circle.fill" : "checkmark.circle.fill"}
        font={17}
        foregroundStyle={tone}
      />
      <Text font="subheadline" fontWeight="semibold" foregroundStyle="label">
        {props.text}
      </Text>
    </HStack>
  )
}

/** 加载中的转圈指示：放在页面顶部（返回按钮的另一侧） */
export function TopRefresh(props: { busy?: boolean }) {
  if (!props.busy) return null
  return (
    <HStack spacing={0} padding={{ horizontal: 2, vertical: 2 }}>
      <ProgressView />
    </HStack>
  )
}

export type Hint = { text: string; ok?: boolean }

/** 把 hint 状态转成视图的 toast 属性：只用系统轻提示本身（一层底 + 文字） */
/** 把设备/系统返回的英文错误翻成人话（已经是中文就原样透传） */
export function zhError(raw: string | undefined | null, fallback = "操作失败"): string {
  const s = String(raw ?? "").trim()
  if (!s) return fallback
  if (/[\u4e00-\u9fa5]/.test(s)) return s
  const t = s.toLowerCase()
  if (/not support|unsupport|notimplement|not implemented/.test(t)) return "设备不支持这个操作"
  if (/timeout|timed out|time out/.test(t)) return "设备响应超时"
  if (/not exist|notfound|not found|unknown/.test(t)) return "设备不认识这条命令"
  if (/permission|forbidden|unauthor/.test(t)) return "没有权限或登录已失效"
  if (/empty|null|no data/.test(t)) return "设备没有返回数据"
  if (/get .*info failed|get .*failed/.test(t)) return "设备读不到这项数据（硬件或固件不支持）"
  if (/fail/.test(t)) return "设备执行失败"
  if (/^http \d+/.test(t)) return `设备网关异常（${s}）`
  return `${fallback}（设备返回异常）`
}

export function hintToast(hint: Hint | null, dismiss: () => void) {
  if (!hint) return undefined
  return {
    content: <HintPill text={hint.text} ok={hint.ok} />,
    position: "top" as const,
    duration: 1.6,
    backgroundColor: "rgba(0,0,0,0)" as Color,
    cornerRadius: 0,
    shadowRadius: 0,
    isPresented: true,
    onChanged: () => dismiss(),
  }
}

/** 左边缘右滑返回：贴左侧的一条透明热区，不挡正文滚动 */
export function SwipeBack(props: { onBack: () => void; children?: any }) {
  return (
    <ZStack alignment="topLeading" frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      {props.children}
      <HStack
        frame={{ width: 24, maxHeight: "infinity" }}
        contentShape="rect"
        gesture={DragGesture({ minDistance: 12 }).onEnded((v: any) => {
          if (v.translation.width > 60 && Math.abs(v.translation.height) < 200) props.onBack()
        })}
      />
    </ZStack>
  )
}

/** 液态玻璃样式：{ glass, shape } —— 形状与背景圆角保持一致 */export function glassStyle(opts?: {
  tint?: Color
  interactive?: boolean
  cornerRadius?: number
  clear?: boolean
}) {
  const { tint, interactive = false, cornerRadius = 22, clear = false } = opts ?? {}
  const G = (globalThis as any).UIGlass
  if (!G) return undefined
  let glass = clear ? G.clear() : G.regular()
  if (interactive) glass = glass.interactive(true)
  if (tint) glass = glass.tint(tint)
  const shape: any = cornerRadius > 0 ? { type: "rect", cornerRadius } : "capsule"
  return { glass, shape }
}

/** 卡片：标题 + 内容 */
export function GlassCard(props: {
  children?: any
  padding?: number
  spacing?: number
  aligned?: any
}) {
  const { children, padding = 16, spacing = 10, aligned } = props
  return (
    <VStack
      alignment={aligned ?? "leading"}
      spacing={spacing}
      padding={padding}
      frame={{ maxWidth: "infinity", alignment: "leading" }}
      glassEffect={glassStyle({ cornerRadius: 26 })}
      background={fill("rgba(120,120,128,0.08)", 26)}
    >
      {children}
    </VStack>
  )
}

/** 标签胶囊：用于「在线 / 离线」等状态 */
export function Pill(props: {
  text: string
  color?: Color
  systemImage?: string
}) {
  const { text, color = ACCENT, systemImage } = props
  return (
    <HStack
      spacing={4}
      padding={{ horizontal: 10, vertical: 4 }}
      background={capsuleFill(color, 0.16)}
    >
      {systemImage ? (
        <Image systemName={systemImage} font="caption2" foregroundStyle={color} />
      ) : null}
      <Text font="caption2" fontWeight="semibold" foregroundStyle={color}>
        {text}
      </Text>
    </HStack>
  )
}

/** 分隔线（便于在玻璃卡片内使用） */
export function HairLine({ inset = 0 }: { inset?: number }) {
  return (
    <RoundedRectangle
      cornerRadius={1}
      fill="rgba(120,120,128,0.24)"
      frame={{ height: 0.7, maxWidth: "infinity" }}
      padding={{ leading: inset, trailing: inset }}
    />
  )
}

/** 彩色圆形图标徒标（白图标 / 白字），用作首页快捷入口与工具箱图标 */
export function IconBadge(props: { systemName: string; color: Color; size?: number; font?: number }) {
  const { systemName, color, size = 42, font = 19 } = props
  return (
    <Image
      systemName={systemName}
      font={font}
      foregroundStyle="white"
      frame={{ width: size, height: size }}
      background={capsuleFill(color)}
    />
  )
}

/** 彩色圆形文字徒标（如 DHCP） */
export function TextBadge(props: { text: string; color: Color; size?: number; font?: number }) {
  const { text, color, size = 42, font = 13 } = props
  return (
    <Text
      font={font}
      fontWeight="bold"
      foregroundStyle="white"
      frame={{ width: size, height: size }}
      background={capsuleFill(color)}
    >
      {text}
    </Text>
  )
}

/** 列表行末尾的箭头 */
export function Chevron() {
  return <Image systemName="chevron.right" font="caption2" foregroundStyle="tertiaryLabel" />
}

/** 一行 键 / 值 */
export function InfoRow(props: {
  label: string
  value: string
  mono?: boolean
  valueColor?: Color
}) {
  const { label, value, mono, valueColor } = props
  return (
    <HStack spacing={12} frame={{ maxWidth: "infinity" }}>
      <Text font="subheadline" foregroundStyle="secondaryLabel">
        {label}
      </Text>
      <Spacer />
      <Text
        font="subheadline"
        monospaced={mono}
        foregroundStyle={valueColor ?? "label"}
        multilineTextAlignment="trailing"
      >
        {value}
      </Text>
    </HStack>
  )
}
