// ---------- 云端接口配置 ----------
// 只支持远程登录：所有请求都发往云端，不连接局域网网关。

export const BASE = "https://home.mifon.com"

// 用户给定的三个端点，原样使用
export const LOGIN_URL = "https://home.mifon.com/NetworkPlatform/rest/user/userLogin"
export const DEVICE_LIST_URL = "https://home.mifon.com/NetworkPlatform/rest/deviceBind/getAllDeviceByUser"
export const USER_INFO_URL = "https://home.mifon.com/NetworkPlatform/rest/userInfo/queryUserInfo"

/** 国际区号，登录/查询用户信息都要带 */
export const AREA_CODE = "86"

/** 请求超时（秒） */
export const REQUEST_TIMEOUT = 15

/** 是否发送签名头（万一某版本服务端不认，改成 false 即可回退） */
export const SEND_SIGNATURE = true

/** Keychain 中保存会话的键名 */
export const KEYCHAIN_SESSION = "fh.session.v2"
export const KEYCHAIN_LAST_ACCOUNT = "fh.lastAccount.v1"
export const KEYCHAIN_UUID = "fh.uuid.v1"

/** 设备级接口 */
export const DEVICE_RENAME_URL = "https://home.mifon.com/NetworkPlatform/rest/deviceInfo/editDeviceName"

/** 解绑设备（抓包确认）：body { username, appType, mac, appVersion } */
export const UNBIND_URL = "https://home.mifon.com/NetworkPlatform/rest/operDevice/unbindUserDevice"

// 绑定设备（抓包 8.har：body 152 字节，含 token + familyId）
export const BIND_URL = "https://home.mifon.com/NetworkPlatform/rest/deviceBind/bindUserDevice"

// 查设备绑定的手机号（20024=当前设备未绑定用户，phone 为 null）
export const PHONE_URL = "https://home.mifon.com/NetworkPlatform/rest/deviceBind/getPhoneByMac"

/** 用户公告（抓包确认）：body { username } */
export const NOTICE_URL = "https://home.mifon.com/NetworkPlatform/rest/userNotice/getNotice"

/** 固件版本查询（抓包确认）：body { model, appType, mac, token, appVersion } */
export const VERSION_URL = "https://home.mifon.com/NetworkPlatform/rest/operVersionManage/queryRouterVerInfo"
