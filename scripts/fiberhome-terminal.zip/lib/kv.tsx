// ---------- 通用「对象 → 设置行」渲染 ----------
// 逆向分析包里很多命令的返回结构只能看到预览（字段可能因固件而异），
// 所以这些页面统一用「有什么渲染什么」的方式，不硬编码字段，避免某型号少字段就空白。
// 字段名一律翻成中文（键表见 PRETTY），确实没收录的才显示原名。

import { Group, Row } from "./settings"

/** 字段名 → 中文（2026-10-29 用 LG6851F 实际返回逐条核对过） */
const PRETTY: Record<string, string> = {
  // ---- 设备 / 标识（GET_SN_INFO）----
  DeviceType: "型号",
  MAC: "MAC 地址",
  Mac: "MAC 地址",
  WlanMac: "无线 MAC 1",
  Wlan0Mac: "无线 MAC 2",
  Wlan1Mac: "无线 MAC 2",
  SN: "序列号",
  protocols: "协议",
  filinkstatus: "组网状态",
  name: "设备名",
  Name: "设备名",
  country_code: "国家/地区",
  AreaCode: "区域码",

  // ---- 固件 ----
  FWDATA: "固件发布时间",
  FWVersion: "固件版本",
  HWVersion: "硬件版本",
  up_status: "升级状态",
  MainRouter: "主路由",
  ChildRouter: "子路由",

  // ---- 运行状态（GET_HG_BASE_INFO）----
  Cpu: "CPU 占用",
  Memory: "内存占用",
  UpTime: "已运行",
  NetStatus: "网络状态",
  Dns: "DNS 服务器",
  OfflineDevSwitch: "显示离线设备",
  ip: "IP 地址",
  LanIp: "局域网 IP",
  WanGateWay: "WAN 网关",
  WanLinkMode: "WAN 拨号方式",
  DownSpeed: "当前下行速率",
  UpSpeed: "当前上行速率",
  WiFiStatus1: "2.4G Wi-Fi 状态",
  WiFiStatus2: "5G Wi-Fi 状态",
  SSID1: "2.4G SSID",
  SSID2: "5G SSID",
  IsSupportN79: "支持 N79",
  MeshInfo: "Mesh 节点",

  // ---- 上联 ----
  UpLinkStatus: "上联状态",
  LinkMode: "上联模式",
  Percent: "信号强度",

  // ---- DHCP 服务器 ----
  Enable: "DHCP 服务器",
  IPAddress: "IP 地址",
  SubNetMask: "子网掩码",
  GateWay: "网关",

  // ---- Mesh ----
  MeshMode: "Mesh 模式",
  MeshEnable: "Mesh 开关",

  // ---- 锁频 / 锁小区 ----
  LockFrequencyBand: "锁频段开关",
  LockCommunity: "锁小区开关",
  Frequency_4G: "4G 频段",
  Frequency_5G: "5G 频段",
  FrequencyPoint: "频点",
  PCI: "小区 ID",
  Stainfo: "设备列表",

  // ---- 防火墙 ----
  firewall_level: "防火墙等级",
  ipv6_firewall_enable: "IPv6 防火墙",
  dos_protection_enable: "DoS 防护",
  port_scan_enable: "端口扫描防护",

  // ---- Wi-Fi ----
  Standard: "协议标准",
  Bandwidth: "频宽",
  UseChannel: "使用信道",
  Channel: "信道",
  Type: "类型",
  ssid_name_2: "2.4G SSID",
  ssid_name_5: "5G SSID",
  radio_enable_2: "2.4G 射频",
  radio_enable_5: "5G 射频",
  ssid_index_2g: "2.4G SSID 索引",
  ssid_index_5g: "5G SSID 索引",
  SSID: "SSID",

  // ---- 端口统计 ----
  Port: "端口",
  rx_packets: "收包数",
  tx_packets: "发包数",
  rx_traffic: "接收流量",
  tx_traffic: "发送流量",
  port_stat_list: "端口列表",

  // ---- 通用忽略 ----
  CmdType: "命令",
  SequenceId: "序号",
  Status: "状态码",
}

/** 这些键不显示（每次返回都有的信封字段） */
const SKIP_DEFAULT = ["CmdType", "SequenceId", "Status"]

/** 值 → 中文（0/1 类字段） */
const VALUE_MAP: Record<string, Record<string, string>> = {
  UpLinkStatus: { "0": "未连接", "1": "已连接" },
  NetStatus: { "0": "未连接", "1": "已连接" },
  filinkstatus: { "0": "未组网", "1": "已组网" },
  OfflineDevSwitch: { "0": "关闭", "1": "开启" },
  Enable: { "0": "关闭", "1": "开启" },
  MeshEnable: { "0": "关闭", "1": "开启" },
  WiFiStatus1: { "0": "关闭", "1": "开启" },
  WiFiStatus2: { "0": "关闭", "1": "开启" },
  radio_enable_2: { "0": "关闭", "1": "开启" },
  radio_enable_5: { "0": "关闭", "1": "开启" },
  IsSupportN79: { "0": "不支持", "1": "支持" },
  up_status: { "0": "没有新版本", "1": "有新版本" },
  country_code: { CN: "中国" },
  // 官方「上网设置」下拉（从 1 开始），见记忆 LinkMode 枚举
  LinkMode: { "1": "蜂窝上行", "2": "以太上行", "3": "蜂窝上行优先", "4": "以太上行优先", "5": "双网聚合" },
  WanLinkMode: { "0": "自动获取 IP", "1": "PPPoE 拨号", "2": "静态 IP" },
  Port: { LAN1: "网口 LAN1", LAN2: "网口 LAN2", LAN3: "网口 LAN3", "2.4G": "2.4G Wi-Fi", "5G": "5G Wi-Fi" },
}

/** 秒 → 「x 天 y 小时」 */
function uptimeText(v: any): string | null {
  const n = Number(v)
  if (!isFinite(n) || n <= 0) return null
  const d = Math.floor(n / 86400)
  const h = Math.floor((n % 86400) / 3600)
  const m = Math.floor((n % 3600) / 60)
  if (d > 0) return `${d} 天 ${h} 小时`
  if (h > 0) return `${h} 小时 ${m} 分`
  return `${m} 分钟`
}

/** 某个 key 是不是「开关类」字段（值 0/1 时翻译成关/开） */
function isSwitchKey(k: string): boolean {
  return /enable/i.test(k) || /^(Switch|Enable)$/.test(k)
}

export function prettyKey(k: string): string {
  return PRETTY[k] ?? k
}

export function prettyValue(k: string, v: any): string {
  if (v === undefined || v === null || v === "") return "—"
  if (Array.isArray(v)) return v.length ? v.map(x => prettyValue(k, x)).join(" / ") : "—"
  if (typeof v === "object") return "—"
  const s = String(v)
  const mapped = VALUE_MAP[k]?.[s]
  if (mapped) return mapped
  if (k === "UpTime") {
    const t = uptimeText(s)
    if (t) return t
  }
  if (k === "Percent") return `${s}%`
  if (isSwitchKey(k) && (s === "0" || s === "1")) return s === "1" ? "开启" : "关闭"
  return s
}

/** 把对象拍平成 [{k, v}]，跳过信封字段和嵌套对象 */
export function kvPairs(data: any, skip: string[] = []): { k: string; v: string }[] {
  if (!data || typeof data !== "object") return []
  const ignores = SKIP_DEFAULT.concat(skip)
  const out: { k: string; v: string }[] = []
  for (const [k, v] of Object.entries(data)) {
    if (ignores.indexOf(k) >= 0) continue
    if (v === undefined || v === null || v === "") continue
    if (typeof v === "object" && !Array.isArray(v)) continue
    if (Array.isArray(v) && v.length === 0) continue
    out.push({ k, v: prettyValue(k, v) })
  }
  return out
}

/** 一个分组：能显示多少字段就显示多少 */
export function KVGroup(props: { header?: string; footer?: string; data: any; skip?: string[]; icon?: string }) {
  const rows = kvPairs(props.data, props.skip)
  if (!rows.length) return null
  return (
    <Group header={props.header} footer={props.footer}>
      {rows.map(r => (
        <Row key={r.k} label={prettyKey(r.k)} value={r.v} mono />
      ))}
    </Group>
  )
}

/** 字节数 → 可读 */
export function bytesText(v: any): string {
  const n = Number(v)
  if (!isFinite(n)) return "—"
  if (n >= 1024 * 1024 * 1024) return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`
  if (n >= 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`
  if (n >= 1024) return `${(n / 1024).toFixed(1)} KB`
  return `${n} B`
}
