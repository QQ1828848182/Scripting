// ---------- DHCP 服务（对齐官方「DHCP 服务」页：IPv4 / IPv6 两个开关） ----------
// 实测（LG6851F，2026-10-29）：
//   读：GET_DHCP_SERVICE_SWITCH {"Type":"0"} → { Ipv4Enable:"1", Ipv6Enable:"1" }
//       {"Type":"1"} 只回 Ipv4Enable，{"Type":"2"} 只回 Ipv6Enable
//   写：SET_DHCP_SERVICE_SWITCH {"Type":"1"|"2", "Enable":"1"|"0"} → Status:"0"
// 不带 Type 的调用会报「json node null」，所以必须带。

import { useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { businessError } from "./lib/invoke"
import { hintToast, zhError } from "./lib/ui"
import type { Hint } from "./lib/ui"
import { Group, SettingsPage, SwitchRow } from "./lib/settings"

const GET = "GET_DHCP_SERVICE_SWITCH"
const SET = "SET_DHCP_SERVICE_SWITCH"

type Which = "ipv4" | "ipv6"

function typeOf(w: Which): string {
  return w === "ipv4" ? "1" : "2"
}

/** 从返回体里取开关值：true / false / null（null = 没读到） */
function switchValue(data: any, w: Which): boolean | null {
  if (!data || typeof data !== "object") return null
  const keys = w === "ipv4" ? ["Ipv4Enable", "ipv4Enable", "IPv4Enable"] : ["Ipv6Enable", "ipv6Enable", "IPv6Enable"]
  for (const k of keys) {
    const v = (data as any)[k]
    if (v !== undefined && v !== null && v !== "") return String(v) === "1"
  }
  return null
}

export default function DhcpPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices?.[0]

  const [v4, setV4] = useState<boolean | null>(null)
  const [v6, setV6] = useState<boolean | null>(null)
  const [busy, setBusy] = useState<Which | "">("")
  const [hint, setHint] = useState<Hint | null>(null)

  async function load() {
    const mac = device?.mac
    const token = session.token
    if (!mac || !token) return
    const r = await invokeService<any>(mac, token, GET, { Type: "0" }, 8).catch(() => ({ ok: false, data: null } as any))
    if (r.ok) {
      const a = switchValue(r.data, "ipv4")
      const b = switchValue(r.data, "ipv6")
      if (a !== null) setV4(a)
      if (b !== null) setV6(b)
      if (a !== null || b !== null) return
    }
    // Type:"0" 没给全就分别读
    const one = async (w: Which) => {
      const rr = await invokeService<any>(mac, token, GET, { Type: typeOf(w) }, 8).catch(() => ({ ok: false, data: null } as any))
      const v = rr.ok ? switchValue(rr.data, w) : null
      if (w === "ipv4") setV4(v)
      else setV6(v)
    }
    await Promise.all([one("ipv4"), one("ipv6")])
  }

  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  async function toggle(w: Which, next: boolean) {
    const mac = device?.mac
    const token = session.token
    if (!mac || !token || busy) return
    const prev = w === "ipv4" ? v4 : v6
    setBusy(w)
    if (w === "ipv4") setV4(next)
    else setV6(next)
    const r = await invokeService<any>(mac, token, SET, { Type: typeOf(w), Enable: next ? "1" : "0" }, 10).catch(() => ({ ok: false, data: null, error: "" } as any))
    const be = r.ok ? businessError(r.data as any) : null
    if (!r.ok || be) {
      if (w === "ipv4") setV4(prev)
      else setV6(prev)
      setBusy("")
      setHint({ text: `设置失败：${zhError(be ?? r.error ?? "", "设备拒绝")}`, ok: false })
      return
    }
    // 回读确认
    const back = await invokeService<any>(mac, token, GET, { Type: typeOf(w) }, 8).catch(() => ({ ok: false, data: null } as any))
    const got = back.ok ? switchValue(back.data, w) : null
    setBusy("")
    if (got !== null) {
      if (w === "ipv4") setV4(got)
      else setV6(got)
      if (got !== next) {
        setHint({ text: "已下发，但设备回读还是原状态", ok: false })
        return
      }
    }
    setHint({ text: `${w === "ipv4" ? "IPv4" : "IPv6"} DHCP 服务已${next ? "开启" : "关闭"}` })
  }

  return (
    <SettingsPage
      title="DHCP 服务"
      refreshable={load}
      toast={hintToast(hint, () => setHint(null))}
    >
      <Group>
        <SwitchRow
          label="IPv4 DHCP 服务"
          icon="network"
          iconColor="#0A84FF"
          value={v4 === true}
          onChanged={v => toggle("ipv4", v)}
        />
        <SwitchRow
          label="IPv6 DHCP 服务"
          icon="network.badge.shield.half.filled"
          iconColor="#5E5CE6"
          value={v6 === true}
          onChanged={v => toggle("ipv6", v)}
        />
      </Group>
    </SettingsPage>
  )
}
