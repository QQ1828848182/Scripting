// ---------- 安全：防火墙（可改） ----------
// 读：GET_FIREWALL_INFO → firewall_level / ipv6_firewall_enable / dos_protection_enable / port_scan_enable
// 写：SET_FIREWALL_INFO，字段名来自逆向分析包（标「字段已验证」）：同名字段，值 "0"/"1"；
//     防护等级只有 1 低 / 2 中 / 3 高（官方页面也没有 0）。
// 写入策略：先带全部 4 个字段发一次；被拒就退回只发改动的那个字段；成功后回读比对，不一致自动回滚显示。
// 注：GET_DMZ_INFO / GET_UPNP_STATE / GET_SECURITY_FILTER_* 在本机（LG6851F）均回显不支持。

import { useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"
import { ACCENT, DANGER, Group, NoticeRow, OK, PickerRow, SettingsPage, SwitchRow } from "./lib/settings"

const LEVELS = [
  { value: "1", label: "低" },
  { value: "2", label: "中" },
  { value: "3", label: "高" },
]

/** 官方页面里每个等级的说明 */
const LEVEL_DESC: Record<string, string> = {
  "1": "低：基础安全防护等级，提供所有业务，适用于大多数普通用户。",
  "2": "中：中等安全防护等级，提供除 SAMBA 外的所有业务。",
  "3": "高：严格安全防护等级，提供除网页、邮件、FTP、DNS、TELNET、PING、SSH、NTP、TRACEROUTE、IPSEC 等业务外，不提供其它业务。",
}

function levelColor(v: any): any {
  const s = String(v ?? "")
  if (s === "1") return ACCENT
  if (s === "2") return OK
  if (s === "3") return DANGER
  return "secondaryLabel"
}

export default function SecurityPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices?.[0]

  const [fw, setFw] = useState<any>(null)
  const [error, setError] = useState("")
  const [busy, setBusy] = useState("")
  const [hint, setHint] = useState<Hint | null>(null)

  async function load() {
    const mac = device?.mac
    const token = session.token
    if (!mac || !token) return
    setError("")
    const a = await invokeService<any>(mac, token, "GET_FIREWALL_INFO", {}, 8)
    if (a.ok) setFw(a.data)
    else setError(`${a.error ?? "读取防火墙信息失败"}${a.code !== undefined ? ` (code ${a.code})` : ""}`)
  }

  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  const s = (v: any) => String(v ?? "0")
  const on = (v: any) => s(v) === "1"
  const level = s(fw?.firewall_level)

  /** 写一个字段：先发全量，被拒再发单字段；然后回读比对，不一致提示 */
  async function write(key: string, value: string, label: string) {
    const mac = device?.mac
    const token = session.token
    if (!mac || !token || busy) return
    setBusy(key)
    setHint(null)
    const prev = s(fw?.[key])
    setFw((old: any) => ({ ...(old ?? {}), [key]: value }))

    const all: any = {
      firewall_level: s(fw?.firewall_level),
      ipv6_firewall_enable: s(fw?.ipv6_firewall_enable),
      dos_protection_enable: s(fw?.dos_protection_enable),
      port_scan_enable: s(fw?.port_scan_enable),
      [key]: value,
    }
    let r = await invokeService<any>(mac, token, "SET_FIREWALL_INFO", all, 12)
    let solo = false
    if (!r.ok) {
      const r2 = await invokeService<any>(mac, token, "SET_FIREWALL_INFO", { [key]: value }, 12)
      if (r2.ok) {
        r = r2
        solo = true
      }
    }
    if (!r.ok) {
      setFw((old: any) => ({ ...(old ?? {}), [key]: prev }))
      setBusy("")
      setError(`修改${label}失败：${r.error ?? "未知"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
      setHint({ text: `${label}未生效`, ok: false })
      return
    }

    // 回读校对
    let back = ""
    for (let i = 0; i < 5; i++) {
      await new Promise<void>(res => setTimeout(res, 500))
      const c = await invokeService<any>(mac, token, "GET_FIREWALL_INFO", {}, 8)
      if (!c.ok) continue
      back = s(c.data?.[key])
      if (back === value) {
        setFw(c.data)
        break
      }
    }
    setBusy("")
    if (back === value) setHint({ text: `${label}已保存${solo ? "（单字段下发）" : ""}` })
    else {
      setFw((old: any) => ({ ...(old ?? {}), [key]: prev }))
      setHint({ text: back ? `${label}回读为 ${back}，未生效` : `${label}已下发，未回读到`, ok: false })
    }
  }

  return (
    <SettingsPage title="安全" refreshable={load} toast={hintToast(hint, () => setHint(null))}>
      {error ? (
        <Group>
          <NoticeRow kind="error" text={error} />
        </Group>
      ) : null}

      <Group header="防火墙" footer={LEVEL_DESC[level] ?? ""}>
        <PickerRow
          label="防护等级"
          icon="shield.lefthalf.filled"
          iconColor={levelColor(level)}
          value={LEVELS.find(l => l.value === level)?.label ?? "—"}
          valueColor={levelColor(level)}
          selected={level}
          options={LEVELS}
          onSelect={v => write("firewall_level", v, "防护等级")}
        />
        <SwitchRow
          label="IPv6 防火墙"
          note={busy === "ipv6_firewall_enable" ? "下发中…" : undefined}
          value={on(fw?.ipv6_firewall_enable)}
          onChanged={v => write("ipv6_firewall_enable", v ? "1" : "0", "IPv6 防火墙")}
        />
        <SwitchRow
          label="DoS 防护"
          note={busy === "dos_protection_enable" ? "下发中…" : undefined}
          value={on(fw?.dos_protection_enable)}
          onChanged={v => write("dos_protection_enable", v ? "1" : "0", "DoS 防护")}
        />
        <SwitchRow
          label="端口扫描防护"
          note={busy === "port_scan_enable" ? "下发中…" : undefined}
          value={on(fw?.port_scan_enable)}
          onChanged={v => write("port_scan_enable", v ? "1" : "0", "端口扫描防护")}
        />
      </Group>
    </SettingsPage>
  )
}
