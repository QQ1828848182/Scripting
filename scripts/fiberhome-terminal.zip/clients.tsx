// ---------- 接入设备（iOS 设置风格） ----------
// 数据：GET_FILINK_TOPOLOGY_INFO.MainBaseInfo（字段含义已用抓包 + 官方截图交叉验证）
//   AccessType  2 = 2.4G 接入，4 = 5G 接入
//   AccessTime  距离现在多少秒（官方那个「57分钟前」）
//   UpSpeed / DownSpeed  单位 Kbps
//   NetStatus   "1" = 在线

import { HStack, Image, Spacer, Text, TextField, VStack, ZStack, useColorScheme, useState, useEffect } from "scripting"
import type { Color } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { fmtMac } from "./lib/api"
import { invokeService, normalizeMac } from "./lib/invoke"
import { setOfflineDevSwitch } from "./lib/cmds"
import { fill, hintToast } from "./lib/ui"
import { ACCENT, DANGER, Group, NoticeRow, OK, Row, SettingsPage, SwitchRow } from "./lib/settings"
import { Overlay, GlassDialog, DialogButtons } from "./lib/pickers"

type Client = {
  name: string
  ip: string
  mac: string
  online: boolean
  accessType: string
  upSpeed: number | null
  downSpeed: number | null
  upLimit: number | null
  downLimit: number | null
  accessTime: number | null
  factory: string
  /** 下面三个来自拓扑（不一定有），没有就靠本地缓存 */
  accessEnable: string
  speedLimit: string
  raw: any
}

function num(v: any): number | null {
  const n = typeof v === "number" ? v : parseFloat(String(v ?? ""))
  return Number.isFinite(n) ? n : null
}

function accessLabel(t: string): string {
  if (t === "2") return "2.4G接入"
  if (t === "4") return "5G接入"
  return t ? `接入${t}` : "接入"
}

/** 秒 → 「57分钟前」 */
function ago(sec: number | null): string {
  if (sec === null) return "—"
  const s = Math.floor(sec)
  if (s < 60) return "刚刚"
  if (s < 3600) return `${Math.floor(s / 60)}分钟前`
  if (s < 86400) return `${Math.floor(s / 3600)}小时前`
  return `${Math.floor(s / 86400)}天前`
}

/** Kbps → 「0.0Kbps」/「1.2Mbps」 */
function speed(kbps: number | null): string {
  if (kbps === null) return "0.0Kbps"
  if (kbps >= 1024) return `${(kbps / 1024).toFixed(1)}Mbps`
  return `${kbps.toFixed(1)}Kbps`
}

function limitText(up: number | null, down: number | null): string {
  if ((up === null || up === 0) && (down === null || down === 0)) return "未限速"
  return `↑${speed(up)} ↓${speed(down)}`
}

function deviceIcon(name: string): string {
  if (/iphone|ipad|phone|手机/i.test(name)) return "iphone"
  if (/pad|ipad/i.test(name)) return "ipad"
  if (/tv|电视/i.test(name)) return "tv"
  if (/book|mac/i.test(name)) return "laptopcomputer"
  return "rectangle.connected.to.line.below"
}

/** 弹窗里的一行信息（左标题右值） */
function InfoLine(props: { label: string; value: string; valueColor?: Color }) {
  return (
    <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
      <Text font="caption" foregroundStyle="secondaryLabel">
        {props.label}
      </Text>
      <Spacer />
      <Text font="caption" foregroundStyle={props.valueColor ?? "secondaryLabel"}>
        {props.value}
      </Text>
    </HStack>
  )
}

/** 弹窗里的一个动作按钮 */
function ActionRow(props: { icon: string; title: string; tint?: Color; onTap: () => void }) {
  const scheme = useColorScheme()
  const bg = scheme === "dark" ? "rgba(255,255,255,0.14)" : "rgba(120,120,128,0.14)"
  const color = props.tint ?? ("label" as Color)
  return (
    <HStack
      spacing={10}
      padding={{ horizontal: 12, vertical: 10 }}
      frame={{ maxWidth: "infinity" }}
      background={fill(bg, 12)}
      contentShape="rect"
      onTapGesture={props.onTap}
    >
      <Image systemName={props.icon} font={15} foregroundStyle={color} frame={{ width: 22 }} />
      <Text foregroundStyle={color}>{props.title}</Text>
      <Spacer />
    </HStack>
  )
}

export default function ClientsPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices[0]

  const [list, setList] = useState<Client[]>([])
  const [error, setError] = useState("")
  const [acting, setActing] = useState<Client | null>(null)
  const closeBg = useColorScheme() === "dark" ? "rgba(255,255,255,0.16)" : "rgba(120,120,128,0.18)"
  const [showOnline, setShowOnline] = useState(true)
  const [showOffline, setShowOffline] = useState(false)
  const [offlineOn, setOfflineOn] = useState(true)
  const [busyOffline, setBusyOffline] = useState(false)
  const [hint, setHint] = useState("")

  /** 禁止上网的本地缓存：拓扑里不一定带 AccessEnable 字段 */
  const [blocked, setBlocked] = useState<Record<string, string>>(() => {
    try {
      const raws = Storage.get("cpe.blocked.v1")
      const o = raws ? JSON.parse(String(raws)) : {}
      return o && typeof o === "object" ? o : {}
    } catch {
      return {}
    }
  })
  const [renaming, setRenaming] = useState<Client | null>(null)
  const [limiting, setLimiting] = useState<Client | null>(null)
  const [nameInput, setNameInput] = useState("")
  const [upInput, setUpInput] = useState("0")
  const [downInput, setDownInput] = useState("0")
  const [savingClient, setSavingClient] = useState(false)

  function isBlocked(c: Client): boolean {
    // 设备侧 AccessEnable：「0」= 禁止上网，「1」= 允许
    if (c.accessEnable === "0" || c.accessEnable === "1") return c.accessEnable === "0"
    return blocked[normalizeMac(c.mac)] === "1"
  }

  function setBlockedCache(mac: string, on: boolean) {
    const key = normalizeMac(mac)
    const next = { ...blocked }
    if (on) next[key] = "1"
    else delete next[key]
    setBlocked(next)
    try {
      Storage.set("cpe.blocked.v1", JSON.stringify(next))
    } catch {}
  }

  /** SET_AD_BASE_INFO：改名 / 限速 / 禁止上网（13.har 抓包确认的字段） */
  async function saveClient(
    c: Client,
    patch: { name?: string; accessEnable?: string; speedLimit?: string; up?: string; down?: string }
  ): Promise<boolean> {
    if (!device?.mac || savingClient) return false
    setSavingClient(true)
    const rawc: any = c.raw ?? {}
    const body = {
      SequenceId: `ad_${Date.now().toString(36)}`,
      MAC: normalizeMac(c.mac),
      ByName: patch.name ?? c.name,
      name: patch.name ?? c.name,
      DevType: String(rawc.DevType ?? "1"),
      AccessEnable: patch.accessEnable ?? (isBlocked(c) ? "0" : "1"),
      SpeedLimit:
        patch.speedLimit ??
        (c.speedLimit !== ""
          ? c.speedLimit
          : (c.upLimit ?? 0) > 0 || (c.downLimit ?? 0) > 0
          ? "1"
          : "0"),
      UpLimit: patch.up ?? String(rawc.UpLimit ?? c.upLimit ?? "0"),
      DownLimit: patch.down ?? String(rawc.DownLimit ?? c.downLimit ?? "0"),
      NetMonopoly: String(rawc.NetMonopoly ?? "0"),
    }
    const r = await invokeService<any>(device.mac, session.token, "SET_AD_BASE_INFO", body, 15)
    setSavingClient(false)
    if (!r.ok) {
      flash(`写入失败：${r.error ?? ""}`)
      return false
    }
    const status = String(r.data?.Status ?? "")
    if (status !== "" && status !== "0") {
      flash(`设备拒绝：${String(r.data?.FailReason ?? `Status=${status}`)}`)
      return false
    }
    if (patch.accessEnable !== undefined) setBlockedCache(c.mac, patch.accessEnable === "0")
    return true
  }

  async function toggleBlock(c: Client) {
    const block = !isBlocked(c)
    const ok = await saveClient(c, { accessEnable: block ? "0" : "1" })
    if (!ok) return
    flash(block ? `已禁止「${c.name}」上网` : `已恢复「${c.name}」上网`)
    load()
  }

  async function doRename() {
    const c = renaming
    if (!c) return
    const name = nameInput.trim()
    if (name === "") {
      flash("名称不能为空")
      return
    }
    const ok = await saveClient(c, { name })
    if (!ok) return
    setRenaming(null)
    flash(`已重命名为「${name}」`)
    load()
  }

  async function doLimit() {
    const c = limiting
    if (!c) return
    const up = upInput.trim() || "0"
    const down = downInput.trim() || "0"
    if (!/^\d+$/.test(up) || !/^\d+$/.test(down)) {
      flash("限速请填非负整数（Kbps，0 = 不限速）")
      return
    }
    const any = Number(up) > 0 || Number(down) > 0
    const ok = await saveClient(c, { speedLimit: any ? "1" : "0", up, down })
    if (!ok) return
    setLimiting(null)
    flash(any ? `已限速：↓${down} / ↑${up} Kbps` : "已取消限速")
    load()
  }

  function flash(msg: string) {
    setHint(msg)
    setTimeout(() => setHint(""), 2600)
  }

  /** 设备侧「保留离线设备记录」开关：SET_HG_BASE_INFO.OfflineDevSwitch */
  async function toggleOffline(next: boolean) {
    if (!device?.mac || busyOffline) return
    const prev = offlineOn
    setOfflineOn(next)
    setBusyOffline(true)
    const r = await setOfflineDevSwitch(device.mac, session.token, next)
    setBusyOffline(false)
    if (!r.ok) {
      setOfflineOn(prev)
      flash(`写入失败：${r.error ?? ""}`)
      return
    }
    try {
      Storage.set("cpe.offlineDev.v1", next ? "1" : "0")
    } catch {}
    flash(next ? "已开启离线设备记录" : "已关闭，设备会清空离线记录")
    if (!next) setShowOffline(false)
    load()
  }

  async function load() {
    if (!device?.mac || !session.token) return
    setError("")
    const r = await invokeService<any>(device.mac, session.token, "GET_FILINK_TOPOLOGY_INFO", {}, 10)
    if (!r.ok) {
      setError(`${r.error ?? "读取失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
      return
    }
    const data = r.data ?? {}
    const main = data.MainRouter ?? data.Router ?? {}
    const ods = String(main.OfflineDevSwitch ?? "")
    if (ods === "0" || ods === "1") {
      setOfflineOn(ods === "1")
    } else {
      try {
        const cached = Storage.get("cpe.offlineDev.v1")
        if (cached === "0" || cached === "1") setOfflineOn(cached === "1")
      } catch {}
    }

    // 实测拓扑里设备列表是嵌在 MainRouter 里的，顺手兼容平铺/其它键名
    const arr: any[] = Array.isArray(data.MainBaseInfo)
      ? data.MainBaseInfo
      : Array.isArray(main.MainBaseInfo)
      ? main.MainBaseInfo
      : Array.isArray(data.DevList)
      ? data.DevList
      : Array.isArray(main.DevList)
      ? main.DevList
      : []
    const parsed: Client[] = arr.map(c => ({
      name: String(c.Name ?? c.By ?? "未知设备"),
      ip: String(c.ip ?? "—"),
      mac: String(c.Mac ?? ""),
      online: String(c.NetStatus) === "1",
      accessType: String(c.AccessType ?? ""),
      upSpeed: num(c.UpSpeed),
      downSpeed: num(c.DownSpeed),
      upLimit: num(c.UpLimit),
      downLimit: num(c.DownLimit),
      accessTime: num(c.AccessTime),
      factory: String(c.DevFactory ?? ""),
      accessEnable: String(c.AccessEnable ?? ""),
      speedLimit: String(c.SpeedLimit ?? ""),
      raw: c,
    }))
    parsed.sort((a, b) => (a.accessTime ?? 1e9) - (b.accessTime ?? 1e9))
    setList(parsed)
  }

  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  const online = list.filter(c => c.online)
  const offline = list.filter(c => !c.online)
  const blockedClients = list.filter(isBlocked)

  /** 一个终端一行，点一下弹出「改名 / 限速 / 拉黑」 */
  function clientRows(items: Client[], dim: boolean): any[] {
    return items.map(c => (
      <Row
        key={`c:${c.mac || c.ip}`}
        icon={deviceIcon(c.name)}
        iconColor={c.online ? OK : "tertiaryLabel"}
        label={c.name}
        note={`${accessLabel(c.accessType)} · ${ago(c.accessTime)}`}
        value={speed(c.downSpeed)}
        valueColor={dim ? "tertiaryLabel" : "secondaryLabel"}
        mono
        chevron
        onTap={() => setActing(c)}
      />
    ))
  }

  return (
    <ZStack alignment="topLeading" frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      <SettingsPage
        title="接入设备"
        refreshable={load}
        toast={hintToast(hint ? { text: hint } : null, () => setHint(""))}
      >
        {error ? (
          <Group>
            <NoticeRow kind="error" text={error} />
          </Group>
        ) : null}

        <Group
          header={`在线（${online.length}）`}
          footer={online.length ? "点设备可改名 / 限速 / 加入黑名单。" : "暂无常在线设备"}
        >
          {online.length === 0 ? <Row label="暂无设备" icon="minus.circle" /> : clientRows(online, false)}
        </Group>

        <Group header={`黑名单（${blockedClients.length}）`} footer={blockedClients.length ? "点设备解禁。" : undefined}>
          {blockedClients.length === 0 ? (
            <Row label="暂无" icon="hand.raised.slash" />
          ) : (
            blockedClients.map(c => (
              <Row
                key={`b:${c.mac || c.ip}`}
                label={c.name}
                value={fmtMac(c.mac)}
                valueColor={DANGER}
                mono
                onTap={() => toggleBlock(c)}
              />
            ))
          )}
        </Group>

        <Group header="离线设备" footer="关闭「显示离线设备」后，设备会清空离线记录。">
          <SwitchRow label="显示离线设备" value={offlineOn} onChanged={toggleOffline} />
          {offlineOn ? <SwitchRow label="展开离线列表" value={showOffline} onChanged={setShowOffline} /> : null}
          {offlineOn && showOffline ? clientRows(offline, true) : null}
        </Group>
      </SettingsPage>

      {renaming ? (
        <Overlay onDismiss={() => (savingClient ? null : setRenaming(null))}>
          <GlassDialog width={300}>
            <Text font="subheadline" fontWeight="semibold" frame={{ maxWidth: "infinity", alignment: "leading" }}>
              修改终端名称
            </Text>
            <Text font="caption" foregroundStyle="secondaryLabel" frame={{ maxWidth: "infinity", alignment: "leading" }}>
              {fmtMac(renaming.mac)}
            </Text>
            <TextField title="" value={nameInput} onChanged={setNameInput} prompt="例如 iPhone 15" />
            <DialogButtons
              accent={ACCENT}
              doneTitle={savingClient ? "保存中…" : "保存"}
              onCancel={() => (savingClient ? null : setRenaming(null))}
              onDone={doRename}
            />
          </GlassDialog>
        </Overlay>
      ) : null}

      {limiting ? (
        <Overlay onDismiss={() => (savingClient ? null : setLimiting(null))}>
          <GlassDialog width={300}>
            <Text font="subheadline" fontWeight="semibold" frame={{ maxWidth: "infinity", alignment: "leading" }}>
              限速
            </Text>
            <Text font="caption" foregroundStyle="secondaryLabel" frame={{ maxWidth: "infinity", alignment: "leading" }}>
              {`${limiting.name} · 单位 Kbps，0 表示不限速`}
            </Text>
            <VStack alignment="leading" spacing={6} frame={{ maxWidth: "infinity" }}>
              <Text font="caption" foregroundStyle="secondaryLabel">
                下行
              </Text>
              <TextField title="" value={downInput} onChanged={setDownInput} prompt="0 = 不限速" />
              <Text font="caption" foregroundStyle="secondaryLabel">
                上行
              </Text>
              <TextField title="" value={upInput} onChanged={setUpInput} prompt="0 = 不限速" />
              <HStack spacing={10} frame={{ maxWidth: "infinity" }}>
                <Text
                  font="body"
                  foregroundStyle={ACCENT}
                  contentShape="rect"
                  onTapGesture={() => {
                    setUpInput("0")
                    setDownInput("0")
                  }}
                >
                  不限速
                </Text>
              </HStack>
            </VStack>
            <DialogButtons
              accent={ACCENT}
              doneTitle={savingClient ? "下发中…" : "保存"}
              onCancel={() => (savingClient ? null : setLimiting(null))}
              onDone={doLimit}
            />
          </GlassDialog>
        </Overlay>
      ) : null}
      {acting ? (
        <Overlay onDismiss={() => (savingClient ? null : setActing(null))}>
          <GlassDialog width={300}>
            <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity" }}>
              <Text font="subheadline" fontWeight="semibold">
                {acting.name}
              </Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                {`${accessLabel(acting.accessType)} · ${acting.ip || "—"}`}
              </Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                {fmtMac(acting.mac)}
              </Text>
            </VStack>

            <VStack spacing={4} frame={{ maxWidth: "infinity" }}>
              <InfoLine label="实时速率" value={`↑${speed(acting.upSpeed)}  ↓${speed(acting.downSpeed)}`} />
              <InfoLine label="限速" value={limitText(acting.upLimit, acting.downLimit)} />
              <InfoLine
                label="上网权限"
                value={isBlocked(acting) ? "已加入黑名单" : "允许上网"}
                valueColor={isBlocked(acting) ? DANGER : "secondaryLabel"}
              />
              {acting.factory ? <InfoLine label="厂商" value={acting.factory} /> : null}
            </VStack>

            <VStack spacing={8} frame={{ maxWidth: "infinity" }}>
              <ActionRow
                icon="pencil"
                title="重命名"
                tint={ACCENT}
                onTap={() => {
                  const c = acting
                  setActing(null)
                  setNameInput(c.name)
                  setRenaming(c)
                }}
              />
              <ActionRow
                icon="speedometer"
                title="限速"
                tint={ACCENT}
                onTap={() => {
                  const c = acting
                  setActing(null)
                  setUpInput(String(c.upLimit ?? 0))
                  setDownInput(String(c.downLimit ?? 0))
                  setLimiting(c)
                }}
              />
              <ActionRow
                icon={isBlocked(acting) ? "hand.raised.slash" : "hand.raised.fill"}
                title={isBlocked(acting) ? "移出黑名单（恢复上网）" : "加入黑名单"}
                tint={isBlocked(acting) ? OK : DANGER}
                onTap={() => {
                  const c = acting
                  setActing(null)
                  toggleBlock(c)
                }}
              />
            </VStack>

            <HStack
              spacing={0}
              padding={{ vertical: 8 }}
              frame={{ maxWidth: "infinity" }}
              background={fill(closeBg, 12)}
              contentShape="rect"
              onTapGesture={() => setActing(null)}
            >
              <Spacer />
              <Text font="subheadline">关闭</Text>
              <Spacer />
            </HStack>
          </GlassDialog>
        </Overlay>
      ) : null}
    </ZStack>
  )
}
