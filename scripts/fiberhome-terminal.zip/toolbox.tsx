// ---------- 工具箱：官方 App 的功能入口（iOS 设置风格） ----------
// 这些功能都依赖设备级接口（云端目前只有账号 / 设备列表 / 用户信息），
// 所以先做成可点、可说明的入口，接口一旦补上只需替换 onTap。

import {
  NavigationDestination,
  NavigationStack,
  VStack,
  useObservable,
  useState,
  useEffect,
} from "scripting"
import type { Color } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { fetchSummary, loadCachedSummary } from "./lib/cachedSummary"
import type { Summary } from "./lib/cachedSummary"
import { fetchLedSwitch, setLedSwitch } from "./lib/led"
import TrafficPage from "./traffic"
import ClientsPage from "./clients"
import { modelCaps, fanSupported } from "./lib/model"
import { FAN_GEARS, fanModeLabel, readFanMode, setFanMode } from "./fan"
import MobilePage from "./mobile"
import WifiPage from "./wifi"
import LockPage from "./lock"
import ParentPage, { ParentDevicesPage, ParentEditPage, ParentUrlPage } from "./parent"
import SmsPage, { SmsChatPage, SmsComposePage } from "./sms"
import RebootPage from "./reboot"
import SimPage from "./sim"
import MnetPage from "./mnet"
import CaPage from "./ca"
import RfPage from "./rf"
import LockCellPage from "./lockcell"
import LockBandPage from "./lockband"
import LockBandSubPage from "./lockbandsub"
import DevInfoPage from "./devinfo"
import SecurityPage from "./security"
import DhcpPage from "./dhcp"
import MloPage from "./mlo"
import { Group, NoticeRow, PickerRow, Row, SettingsPage, SwitchRow } from "./lib/settings"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"

type Tool = {
  label: string
  systemName?: string
  color: Color
  desc: string
  open?:
    | "led"
    | "traffic"
    | "clients"
    | "fan"
    | "mobile"
    | "wifi"
    | "lock"
    | "parent"
    | "sms"
    | "reboot"
    | "devinfo"
    | "security"
    | "dhcp"
    | "mlo"
}

const TOOLS: Tool[] = [
  { label: "移动网络", systemName: "antenna.radiowaves.left.and.right", color: "#34C759", desc: "移动网络状态与开关", open: "mobile" },
  { label: "蜂窝流量管理", systemName: "chart.bar.fill", color: "#0A84FF", desc: "流量统计与限额", open: "traffic" },
  { label: "锁频设置", systemName: "lock.shield", color: "#5E5CE6", desc: "锁定 4G/5G 频段", open: "lock" },
  { label: "短信消息", systemName: "message.fill", color: "#30B0C7", desc: "收发设备短信", open: "sms" },
  { label: "接入设备", systemName: "laptopcomputer.and.iphone", color: "#0A84FF", desc: "查看当前接入的终端", open: "clients" },
  { label: "指示灯", systemName: "flashlight.on.fill", color: "#FF9F0A", desc: "开 / 关指示灯", open: "led" },
  { label: "风扇模式", systemName: "wind", color: "#8E8E93", desc: "散热策略", open: "fan" },
  { label: "定时重启", systemName: "calendar.badge.clock", color: "#5E5CE6", desc: "按计划自动重启", open: "reboot" },
  { label: "DHCP 服务", systemName: "network", color: "#0A84FF", desc: "IPv4 / IPv6 DHCP 开关", open: "dhcp" },
  { label: "MLO", systemName: "link.badge.plus", color: "#0A84FF", desc: "多链路绑定（Wi-Fi 7）", open: "mlo" },
  { label: "家长控制", systemName: "person.2.badge.gearshape", color: "#FF375F", desc: "定时上网 / 网址过滤", open: "parent" },
  { label: "安全", systemName: "checkmark.shield", color: "#FF3B30", desc: "防火墙等级 / DoS / 端口扫描", open: "security" },
  { label: "设备信息", systemName: "info.circle", color: "#8E8E93", desc: "型号 / 运行状态 / DHCP / 网口流量", open: "devinfo" },
]

export default function ToolboxPage(props: { session: Session; devices: DeviceInfo[] }) {
  const { session, devices } = props
  const [notice, setNotice] = useState("")
  const [fanMode, setFanModeState] = useState<string | null>(null)
  const [fanHint, setFanHint] = useState<Hint | null>(null)
  // 指示灯：行内开关（读回 0 = 关）
  const [ledOn, setLedOn] = useState<boolean | null>(null)
  const [ledBusy, setLedBusy] = useState(false)
  const [ledError, setLedError] = useState("")
  // 原生导航栈：push/pop 交给 iOS，自带边缘右滑返回
  const nav = useObservable<string[]>([])

  // 型号能力表（对齐网页版 MODEL_CAPS）：LG6121 = 烽火 Air，无风扇
  const model = devices[0]?.model
  const caps = modelCaps(model)
  const tools = TOOLS.filter(t => (t.open === "fan" ? fanSupported(model) : true))
  const capNote = !caps || caps.fan ? "" : "无风扇（已隐藏对应入口）"
  const ledNote = ledError ? ledError : ledOn === null ? "正在读取…" : "开 / 关指示灯"

  // 右侧摘要：带缓存（拿不到新数据就继续显示上一次的值）
  const [summary, setSummary] = useState<Summary>(() => {
    const mac = devices[0]?.mac
    return mac ? loadCachedSummary(mac) : {}
  })

  useEffect(() => {
    const mac = devices[0]?.mac
    const token = session.token
    if (!mac || !token) return
    let alive = true
    fetchSummary(mac, token, patch => {
      if (!alive) return
      setSummary(s => ({ ...s, ...patch }))
    })
    return () => {
      alive = false
    }
  }, [devices[0]?.mac, session.token])

  /** 这三个入口不显示右侧摘要（用户要求） */
  const NO_SUMMARY = ["mobile", "traffic", "lock"]

  function valueFor(t: Tool): string | undefined {
    const k = t.open
    if (!k || NO_SUMMARY.includes(k)) return undefined
    return summary[k]
  }

  function say(msg: string) {
    setNotice(msg)
    setTimeout(() => setNotice(""), 4000)
  }

  function flash(t: Tool) {
    setNotice(`${t.label}：${t.desc} —— 需要设备级接口，当前云端未提供`)
    setTimeout(() => setNotice(""), 3000)
  }

  // 风扇档位：直接读当前值，选完就地下发（带回读校验）
  const fanOn = fanSupported(model)
  useEffect(() => {
    const mac = devices[0]?.mac
    const token = session.token
    if (!mac || !token || !fanOn) return
    let alive = true
    readFanMode(mac, token).then(r => {
      if (alive && r.ok && r.mode !== null) setFanModeState(r.mode)
    })
    return () => {
      alive = false
    }
  }, [devices[0]?.mac, session.token, fanOn])

  // 指示灯：进页读一次真实状态（写不回读，点了直接发 0/1）
  useEffect(() => {
    loadLed()
  }, [devices[0]?.mac, session.token])

  async function loadLed() {
    const mac = devices[0]?.mac
    const token = session.token
    if (!mac || !token) return
    setLedError("")
    // 刚进页面时并发请求多、设备可能还没就绪，读 3 次，以最后一次成功读到的为准
    let got: boolean | null = null
    for (let i = 0; i < 3; i++) {
      const r = await fetchLedSwitch(mac, token).catch(() => ({ ok: false, on: null as boolean | null, error: "" }))
      if (r.on !== null) got = r.on
      if (i < 2) await new Promise<void>(res => setTimeout(res, 500))
    }
    if (got !== null) setLedOn(got)
    else setLedError("读取失败，下拉刷新")
  }

  async function toggleLed(next: boolean) {
    const mac = devices[0]?.mac
    const token = session.token
    if (!mac || !token || ledBusy) return
    const prev = ledOn
    setLedOn(next) // 先给反馈
    setLedBusy(true)
    // 不回读：发一条 0/1 就算数
    const r = await setLedSwitch(mac, token, next).catch(() => ({ ok: false, on: null as boolean | null, error: "指示灯设置失败（网络异常）" }))
    setLedBusy(false)
    if (!r.ok) {
      setLedOn(prev)
      setFanHint({ text: r.error || "指示灯设置失败", ok: false })
      return
    }
    setFanHint({ text: `指示灯已${next ? "开启" : "关闭"}` })
  }

  async function chooseFan(next: string) {
    const mac = devices[0]?.mac
    const token = session.token
    if (!mac || !token) return
    const prev = fanMode
    setFanModeState(next) // 先给反馈
    const r = await setFanMode(mac, token, next)
    if (!r.ok) {
      setFanModeState(prev)
      setFanHint({ text: r.error ?? "设置失败", ok: false })
      return
    }
    setFanModeState(r.mode ?? next)
    setFanHint(r.warning ? { text: r.warning, ok: false } : { text: `风扇档位已切换为「${fanModeLabel(r.mode ?? next)}」` })
  }

  function onTool(t: Tool) {
    if (t.open === "fan") return // 风扇档位在行内用弹窗选，不进二级页
    if (t.open) {
      nav.setValue([t.open])
      return
    }
    flash(t)
  }

  const back = () => nav.setValue(nav.value.slice(0, -1))
  const push = (key: string) => nav.setValue([...nav.value, key])

  function pageFor(key: string) {
    if (key.startsWith("smsChat:")) {
      return (
        <SmsChatPage
          session={session}
          devices={devices}
          peer={decodeURIComponent(key.slice("smsChat:".length))}
          onBack={back}
        />
      )
    }
    if (key === "lockband4g" || key === "lockband5g") {
      return (
        <LockBandSubPage
          session={session}
          devices={devices}
          which={key === "lockband4g" ? "4g" : "5g"}
        />
      )
    }
    if (key === "smsCompose") {
      return (
        <SmsComposePage
          session={session}
          devices={devices}
          onSent={peer => nav.setValue(["sms", `smsChat:${encodeURIComponent(peer)}`])}
        />
      )
    }
    // 家长控制的二级页（真正的路由页 → 原生返回 / 右滑返回只退一级）
    if (key === "parentEdit") {
      return <ParentEditPage session={session} devices={devices} onPush={push} onBack={back} />
    }
    if (key === "parentDevices") {
      return <ParentDevicesPage session={session} devices={devices} onBack={back} />
    }
    if (key === "parentUrl") {
      return <ParentUrlPage session={session} devices={devices} onBack={back} />
    }
    switch (key) {
      case "traffic":
        return <TrafficPage session={session} devices={devices} onBack={back} />
      case "clients":
        return <ClientsPage session={session} devices={devices} onBack={back} />
      case "fan":
        return <VStack />
      case "mobile":
        return <MobilePage session={session} devices={devices} onBack={back} onPush={push} />
      case "wifi":
        return <WifiPage session={session} devices={devices} onBack={back} />
      case "lock":
        return <LockPage session={session} devices={devices} onBack={back} onPush={push} />
      case "parent":
        return <ParentPage session={session} devices={devices} onBack={back} onPush={push} />
      case "sms":
        return <SmsPage session={session} devices={devices} onBack={back} onPush={push} />
      case "reboot":
        return <RebootPage session={session} devices={devices} onBack={back} />
      case "sim":
        return <SimPage session={session} devices={devices} onBack={back} />
      case "mnet":
        return <MnetPage session={session} devices={devices} onBack={back} />
      case "ca":
        return <CaPage session={session} devices={devices} onBack={back} />
      case "rf":
        return <RfPage session={session} devices={devices} onBack={back} />
      case "cell":
        return <LockCellPage session={session} devices={devices} onBack={back} />
      case "band":
        return <LockBandPage session={session} devices={devices} onBack={back} onPush={push} />
      case "devinfo":
        return <DevInfoPage session={session} devices={devices} onBack={back} />
      case "security":
        return <SecurityPage session={session} devices={devices} onBack={back} />
      case "dhcp":
        return <DhcpPage session={session} devices={devices} onBack={back} />
      case "mlo":
        return <MloPage session={session} devices={devices} onBack={back} />
      default:
        return <VStack />
    }
  }

  return (
    <NavigationStack path={nav}>
      <SettingsPage
        title="工具箱"
        refreshable={() => loadLed()}
        toast={hintToast(fanHint, () => setFanHint(null))}
        navigationDestination={
          <NavigationDestination>{(page: string) => pageFor(page)}</NavigationDestination>
        }
      >
        {notice ? (
          <Group>
            <NoticeRow kind="info" text={notice} />
          </Group>
        ) : null}

        <Group header="工具" footer={capNote ? `${String(model)} · ${caps?.name} · ${capNote}` : undefined}>
          {tools.map(t =>
            t.open === "fan" ? (
              <PickerRow
                key={t.label}
                label={t.label}
                note={t.desc}
                icon={t.systemName ?? "wind"}
                iconColor={t.color}
                value={fanModeLabel(fanMode)}
                selected={fanMode ?? ""}
                options={FAN_GEARS.map(g => ({ value: g.mode, label: g.label }))}
                onSelect={chooseFan}
              />
            ) : t.open === "led" ? (
              <SwitchRow
                key={t.label}
                label={t.label}
                note={ledNote}
                icon={t.systemName ?? "flashlight.on.fill"}
                iconColor={t.color}
                value={ledOn === true}
                onChanged={toggleLed}
              />
            ) : (
              <Row
                key={t.label}
                label={t.label}
                note={t.desc}
                icon={t.systemName ?? "circle"}
                iconColor={t.color}
                value={valueFor(t)}
                chevron
                onTap={() => onTool(t)}
              />
            )
          )}
        </Group>
      </SettingsPage>
    </NavigationStack>
  )
}
