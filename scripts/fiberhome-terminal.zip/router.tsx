// ---------- 路由设置：设备设置分组（iOS 设置风格） ----------

import {
  HStack,
  Image,
  NavigationDestination,
  NavigationStack,
  Spacer,
  Text,
  TextField,
  VStack,
  ZStack,
  useState,
  useEffect,
  useObservable,
} from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { fetchNotice, fmtMac, queryRouterVersion, renameDevice, unbindDevice } from "./lib/api"
import { fetchUpdateStatus } from "./lib/cmds"
import { invokeService } from "./lib/invoke"
import { fetchMainWifi } from "./lib/cmds"
import UpgradePage from "./upgrade"
import BindPage from "./bind"
import WanPage, { uplinkLabel } from "./wan"
import WifiPage from "./wifi"
import GuestWifiPage from "./guestwifi"
import WebLoginPage from "./weblogin"
import { Overlay, GlassDialog, DialogButtons } from "./lib/pickers"
import { ACCENT, DANGER, Group, NoticeRow, OK, Row, SettingsPage } from "./lib/settings"

/** 设备级指令候选：不支持时设备会原样回显，继续试下一个
 *  立即重启 = RP_HG_REBOOT（13.har 实测，SequenceId 固定 "reboot_now"，返回 Status=0 为成功）
 *  恢复出厂 = HG_LOCAL_RECOVERY（2026-10-30 官方 App 抓包实测，无参数，Status=0 已接受；
 *             设备随后自动重启 1–3 分钟，WiFi 名称/密码回默认，官方 App 还会顺手解绑设备）
 */
const REBOOT_PARAM = { SequenceId: "reboot_now" }
const REBOOT_CMDS = ["RP_HG_REBOOT"]
const RESET_CMDS = ["HG_LOCAL_RECOVERY"]

export default function RouterPage(props: {
  session: Session
  devices: DeviceInfo[]
  onDevices: (list: DeviceInfo[]) => void
  onLogout: () => void
  onSessionExpired: () => void
}) {
  const { session, devices, onDevices, onLogout } = props

  const [askLogout, setAskLogout] = useState(false)
  const [askUnbind, setAskUnbind] = useState(false)
  // 原生导航栈：升级页 push/pop 由 iOS 接管，自带边缘右滑返回
  const navUp = useObservable<string[]>([])
  const [unbinding, setUnbinding] = useState(false)
  const [announcement, setAnnouncement] = useState("")
  // 上网设置行右侧：设备当前上行方式（读不到就显示蜂窝上行）
  const [wanMode, setWanMode] = useState("")
  // 「设备升级」行右侧：最新版本状态
  const [verState, setVerState] = useState<"loading" | "latest" | "newer" | "unknown">("loading")
  const [wifiName, setWifiName] = useState<string>(() => {
    const m = devices[0]?.mac
    if (!m) return ""
    try {
      return String(Storage.get(`cpe.router.wifi.v1.${m}`) ?? "")
    } catch {
      return ""
    }
  })
  /** 访客 Wi-Fi 是否打开（2.4G / 5G 任一开启就算打开；null = 还没读到） */
  const [guestOpen, setGuestOpen] = useState<boolean | null>(() => {
    const m = devices[0]?.mac
    if (!m) return null
    try {
      const v = Storage.get(`cpe.router.guest.on.v1.${m}`)
      return v === undefined || v === null || v === "" ? null : String(v) === "1"
    } catch {
      return null
    }
  })

  // Wi-Fi 行右侧显示 2.4G 名称（只拉一次主 Wi-Fi 配置）
  useEffect(() => {
    const mac = devices[0]?.mac
    const token = session.token
    if (!mac || !token) return
    let alive = true
    fetchMainWifi(mac, token)
      .then(r => {
        if (!alive || !r.ok || !r.data) return
        const list = r.data.list
        const en = list.filter(e => e.type !== "1" && e.enable.trim() !== "0")
        const name = (en[0] ?? list.find(e => e.type !== "1"))?.ssid
        if (name) {
          setWifiName(name)
          try {
            Storage.set(`cpe.router.wifi.v1.${mac}`, name)
          } catch {}
        }
      })
      .catch(() => {})
    invokeService<any>(mac, token, "GET_GUEST_WIFI_LIST_INFO", {}, 10)
      .then(r => {
        if (!alive || !r.ok) return
        const arr = Array.isArray(r.data?.WIFIList) ? r.data.WIFIList : []
        // 两个频段都关 = 已关闭；开一个或两个都开 = 已打开
        const open = arr.some((x: any) => String(x?.Enable) === "1")
        setGuestOpen(open)
        try {
          Storage.set(`cpe.router.guest.on.v1.${mac}`, open ? "1" : "0")
        } catch {}
      })
      .catch(() => {})
    invokeService<any>(mac, token, "GET_UPLINK_NETWORK_MODE", {}, 8)
      .then(r => {
        if (!alive || !r.ok) return
        const lm = String(r.data?.LinkMode ?? "").trim()
        if (lm) setWanMode(lm)
      })
      .catch(() => {})
    return () => {
      alive = false
    }
  }, [devices[0]?.mac, session.token])

  // 从访客 Wi-Fi 页返回时重读一次开关状态（在那边可能刚改过）
  useEffect(() => {
    const mac = devices[0]?.mac
    if (!mac || !session.token) return
    if (navUp.value.length !== 0) return
    let alive = true
    invokeService<any>(mac, session.token, "GET_GUEST_WIFI_LIST_INFO", {}, 10)
      .then(r => {
        if (!alive || !r.ok) return
        const arr = Array.isArray(r.data?.WIFIList) ? r.data.WIFIList : []
        const open = arr.some((x: any) => String(x?.Enable) === "1")
        setGuestOpen(open)
        try {
          Storage.set(`cpe.router.guest.on.v1.${mac}`, open ? "1" : "0")
        } catch {}
      })
      .catch(() => {})
    return () => {
      alive = false
    }
  }, [navUp.value.length, devices[0]?.mac, session.token])

  // 「设备升级」行右侧状态：向云端查一次最新固件版本
  useEffect(() => {
    const d = devices[0]
    if (!d?.mac || !session.token) {
      setVerState("unknown")
      return
    }
    let alive = true
    setVerState("loading")
    // 当前版本优先用设备自己报的 FWVersion（HG_GET_UPDATE_STATUS），它比云端 bindDeviceInfoVOs.firmVersion 更实时
    ;(async () => {
      let cur = (d.firmVersion ?? "").trim()
      try {
        const st = await fetchUpdateStatus(d.mac, session.token)
        if (st.ok && st.data?.fwVersion) cur = st.data.fwVersion.trim()
      } catch {}
      if (!alive) return
      queryRouterVersion(session, d.mac, d.model || "LG6851F")
        .then(v => {
          if (!alive) return
          const latestVer = String(v?.[0]?.version ?? "").trim()
          if (!latestVer || !cur) {
            setVerState("unknown")
            return
          }
          setVerState(latestVer.toLowerCase() === cur.toLowerCase() ? "latest" : "newer")
        })
        .catch(() => {
          if (alive) setVerState("unknown")
        })
    })()
    return () => {
      alive = false
    }
  }, [devices[0]?.mac, devices[0]?.firmVersion, session.token])

  const [action, setAction] = useState<"reboot" | "reset" | null>(null)
  const [resetSure, setResetSure] = useState(false)
  const [acting, setActing] = useState(false)

  async function runAction(kind: "reboot" | "reset") {
    if (!device?.mac || acting) return
    setActing(true)
    const cmds = kind === "reboot" ? REBOOT_CMDS : RESET_CMDS
    let sent = ""
    let lastErr = ""
    for (const cmd of cmds) {
      const params = kind === "reboot" ? REBOOT_PARAM : {}
      const r = await invokeService<any>(device.mac, session.token, cmd, params, 15)
      if (r.ok) {
        // 设备返回 Status = "0" 表示已接受
        const st = String(r.data?.Status ?? "0")
        if (st === "0") {
          sent = cmd
          break
        }
        lastErr = `Status=${st}`
      } else {
        lastErr = r.error ?? ""
      }
    }
    setActing(false)
    setAction(null)
    setResetSure(false)
    if (sent) {
      flash(
        kind === "reboot"
          ? "重启指令已下发，约 1 分钟后恢复"
          : "恢复出厂指令已下发，设备重启约 2–3 分钟，WiFi 名称/密码会回默认"
      )
    }
    else flash(kind === "reboot" ? `重启失败：${lastErr || "设备未响应"}` : "设备不支持该指令（需抓包确认 CmdType）")
  }

  useEffect(() => {
    let alive = true
    fetchNotice(session)
      .then(n => {
        if (!alive) return
        const text = [n.title, n.content].filter(Boolean).join("\n").trim()
        if (text) setAnnouncement(text)
      })
      .catch(() => {})
    return () => {
      alive = false
    }
  }, [session.token])

  function onBindTap() {
    if (!device) {
      navUp.setValue(["bind"])
      return
    }
    setAskUnbind(true)
  }

  async function doUnbind() {
    if (!device) return
    setUnbinding(true)
    try {
      await unbindDevice(session, device.mac)
      onDevices(devices.filter(d => d.mac !== device.mac))
      setAskUnbind(false)
      flash("已解绑 " + fmtMac(device.mac))
    } catch (e: any) {
      flash("解绑失败：" + (e?.message ?? e))
    } finally {
      setUnbinding(false)
    }
  }
  const [notice, setNotice] = useState("")
  const [editingName, setEditingName] = useState(false)
  const [nameInput, setNameInput] = useState("")
  const [savingName, setSavingName] = useState(false)

  function flash(msg: string) {
    setNotice(msg)
    setTimeout(() => setNotice(""), 2800)
  }

  async function saveName() {
    if (!device) return
    const next = nameInput.trim()
    if (!next) {
      flash("名称不能为空")
      return
    }
    if (next === device.name) {
      setEditingName(false)
      return
    }
    setSavingName(true)
    try {
      await renameDevice(session, device.mac, next)
      onDevices(devices.map(d => (d.mac === device.mac ? { ...d, name: next } : d)))
      setEditingName(false)
      flash("设备名称已更新")
    } catch (e: any) {
      flash("修改失败：" + (e?.message ?? e))
    } finally {
      setSavingName(false)
    }
  }

  const device = devices[0]

  return (
    <NavigationStack path={navUp}>
      <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
        <SettingsPage
          title="路由设置"
          navigationDestination={
            <NavigationDestination>
              {(page: string) =>
                page === "upgrade" ? (
                  <UpgradePage session={session} devices={devices} onBack={() => navUp.setValue([])} />
                ) : page === "bind" ? (
                  <BindPage
                    session={session}
                    hideBackBar
                    onBack={() => navUp.setValue([])}
                    onBound={list => {
                      // 绑定成功：写回设备列表，并由这里负责退栈（BindPage 自己不再调 onBack）
                      onDevices(list)
                      navUp.setValue([])
                    }}
                  />
                ) : page === "wan" ? (
                  <WanPage session={session} devices={devices} onBack={() => navUp.setValue([])} onModeChanged={setWanMode} />
                ) : page === "wifi" ? (
                  <WifiPage session={session} devices={devices} onBack={() => navUp.setValue([])} />
                ) : page === "guestwifi" ? (
                  <GuestWifiPage session={session} devices={devices} onBack={() => navUp.setValue([])} />
                ) : page === "weblogin" ? (
                  <WebLoginPage session={session} devices={devices} onBack={() => navUp.setValue([])} />
                ) : (
                  <VStack />
                )
              }
            </NavigationDestination>
          }
        >
          {announcement ? (
            <Group header="公告">
              <Row label={announcement} icon="megaphone.fill" iconColor={ACCENT} />
            </Group>
          ) : null}

          {notice ? (
            <Group>
              <NoticeRow kind="info" text={notice} />
            </Group>
          ) : null}

          <Group header="网络与绑定">
            <Row
              label="设备绑定"
              note="云端账号与设备的绑定关系"
              icon="link"
              iconColor={devices.length > 0 ? OK : DANGER}
              value={unbinding ? "解绑中…" : devices.length > 0 ? "已绑定" : "未绑定"}
              valueColor={devices.length > 0 ? OK : DANGER}
              chevron
              onTap={onBindTap}
            />
            <Row
              label="上网设置"
              note="上行方式与带宽占比"
              icon="network"
              iconColor="#0A84FF"
              value={uplinkLabel(wanMode)}
              chevron
              onTap={() => navUp.setValue(["wan"])}
            />
            <Row
              label="Wi-Fi 设置"
              note="2.4G / 5G 名称、密码与隐身"
              icon="wifi"
              iconColor="#0A84FF"
              value={wifiName || "主 Wi-Fi"}
              chevron
              onTap={() => navUp.setValue(["wifi"])}
            />
            <Row
              label="访客 Wi-Fi"
              note="与主 Wi-Fi 隔离的客人网络"
              icon="person.2.wave.2.fill"
              iconColor="#30B0C7"
              value={guestOpen === null ? "—" : guestOpen ? "已打开" : "已关闭"}
              chevron
              onTap={() => navUp.setValue(["guestwifi"])}
            />
          </Group>

          <Group header="设备设置">
            <Row
              label="设备名称"
              note="修改云端显示的名称"
              icon="pencil"
              iconColor="#5E5CE6"
              value={device?.name || "—"}
              chevron
              onTap={() => {
                if (!device) {
                  flash("该账号下没有可用设备")
                  return
                }
                setNameInput(device.name || "")
                setEditingName(!editingName)
              }}
            />
            <Row
              label="路由器管理密码"
              note="登录路由器的管理密码"
              icon="key.fill"
              iconColor="#FF9F0A"
              chevron
              onTap={() => navUp.setValue(["weblogin"])}
            />
            <Row
              label="设备升级"
              note="检查并升级固件版本"
              icon="arrow.down.circle"
              iconColor="#30D158"
              value={
                verState === "loading"
                  ? "检查中…"
                  : verState === "latest"
                  ? "已是最新版本"
                  : verState === "newer"
                  ? "有新版本可以更新"
                  : device?.firmVersion
                  ? `固件 ${device.firmVersion}`
                  : "—"
              }
              valueColor={verState === "newer" ? ACCENT : undefined}
              chevron
              onTap={() => navUp.setValue(["upgrade"])}
            />
            <Row
              label="重启"
              note="重启后约 1 分钟恢复"
              icon="arrow.clockwise"
              iconColor="#0A84FF"
              onTap={() => setAction("reboot")}
            />
            <Row
              label="恢复出厂设置"
              note="清空全部配置并重启，不可撤销"
              icon="trash.fill"
              iconColor={DANGER}
              valueColor={DANGER}
              onTap={() => setAction("reset")}
            />
          </Group>

          <Group header="账号">
            <Row
              label={askLogout ? "确认退出登录？" : "退出登录"}
              note="清除本地会话，返回登录页"
              icon="rectangle.portrait.and.arrow.right"
              iconColor={DANGER}
              valueColor={DANGER}
              onTap={() => setAskLogout(true)}
            />
          </Group>

          <Group footer="烽火终端 · Scripting · 仅远程云端模式">
            {null}
          </Group>
        </SettingsPage>

        {editingName && device ? (
          <Overlay onDismiss={() => (savingName ? null : setEditingName(false))}>
            <GlassDialog width={300}>
              <Text font="subheadline" fontWeight="semibold" frame={{ maxWidth: "infinity", alignment: "leading" }}>
                修改设备名称
              </Text>
              <TextField
                title=""
                value={nameInput}
                onChanged={setNameInput}
                prompt="新的设备名称"
                autocorrectionDisabled
                textFieldStyle="plain"
                padding={{ horizontal: 12, vertical: 10 }}
                frame={{ maxWidth: "infinity" }}
                background={{ style: "rgba(120,120,128,0.16)", shape: { type: "rect", cornerRadius: 10 } }}
              />
              <DialogButtons
                accent={ACCENT}
                doneTitle={savingName ? "保存中…" : "保存"}
                onCancel={() => (savingName ? null : setEditingName(false))}
                onDone={saveName}
              />
            </GlassDialog>
          </Overlay>
        ) : null}

        {askUnbind && device ? (
          <Overlay onDismiss={() => (unbinding ? null : setAskUnbind(false))}>
            <GlassDialog width={282}>
              <Text font="subheadline" fontWeight="semibold" frame={{ maxWidth: "infinity", alignment: "leading" }}>
                解除设备绑定
              </Text>
              <Text font="footnote" foregroundStyle="secondaryLabel" frame={{ maxWidth: "infinity", alignment: "leading" }}>
                {`解绑后「${device.name || "当前设备"}」会从账号下移除，需要重新绑定才能继续远程管理。`}
              </Text>
              <DialogButtons
                accent={DANGER}
                doneTitle={unbinding ? "解绑中…" : "解绑"}
                onCancel={() => (unbinding ? null : setAskUnbind(false))}
                onDone={doUnbind}
              />
            </GlassDialog>
          </Overlay>
        ) : null}

        {askLogout ? (
          <Overlay onDismiss={() => setAskLogout(false)}>
            <GlassDialog width={282}>
              <Text font="subheadline" fontWeight="semibold" frame={{ maxWidth: "infinity", alignment: "leading" }}>
                退出登录
              </Text>
              <Text font="footnote" foregroundStyle="secondaryLabel" frame={{ maxWidth: "infinity", alignment: "leading" }}>
                将清除本机登录会话，下次需要重新输入账号密码。
              </Text>
              <DialogButtons
                accent={DANGER}
                doneTitle="退出"
                onCancel={() => setAskLogout(false)}
                onDone={() => {
                  setAskLogout(false)
                  onLogout()
                }}
              />
            </GlassDialog>
          </Overlay>
        ) : null}

        {action && !resetSure ? (
          <Overlay onDismiss={() => (acting ? null : setAction(null))}>
            <GlassDialog width={282}>
              <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
                <Image
                  systemName={action === "reboot" ? "arrow.clockwise.circle.fill" : "exclamationmark.triangle.fill"}
                  font="subheadline"
                  foregroundStyle={action === "reboot" ? ACCENT : DANGER}
                />
                <Text font="subheadline" fontWeight="semibold">
                  {action === "reboot" ? "重启设备" : "恢复出厂设置"}
                </Text>
                <Spacer />
              </HStack>
              <Text font="footnote" foregroundStyle="secondaryLabel" frame={{ maxWidth: "infinity", alignment: "leading" }}>
                {action === "reboot"
                  ? "约 1 分钟内完成，期间所有连接会中断。"
                  : "WiFi 名称/密码、家长控制规则、管理密码等全部恢复出厂值，设备自动重启约 2–3 分钟，不可撤销。"}
              </Text>
              <DialogButtons
                accent={action === "reboot" ? ACCENT : DANGER}
                doneTitle={acting ? "执行中…" : action === "reboot" ? "重启" : "继续"}
                onCancel={() => (acting ? null : setAction(null))}
                onDone={() => {
                  if (action === "reset") setResetSure(true)
                  else runAction(action)
                }}
              />
            </GlassDialog>
          </Overlay>
        ) : null}

        {action === "reset" && resetSure ? (
          <Overlay onDismiss={() => (acting ? null : (setResetSure(false), setAction(null)))}>
            <GlassDialog width={282}>
              <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
                <Image systemName="exclamationmark.triangle.fill" font="subheadline" foregroundStyle={DANGER} />
                <Text font="subheadline" fontWeight="semibold">
                  再次确认：恢复出厂？
                </Text>
                <Spacer />
              </HStack>
              <Text font="footnote" foregroundStyle="secondaryLabel" frame={{ maxWidth: "infinity", alignment: "leading" }}>
                执行后所有配置会被清空，无法恢复，需要重新设置网络并重新绑定设备。
              </Text>
              <DialogButtons
                accent={DANGER}
                doneTitle={acting ? "执行中…" : "确认清空"}
                onCancel={() => {
                  if (acting) return
                  setResetSure(false)
                  setAction(null)
                }}
                onDone={() => runAction("reset")}
              />
            </GlassDialog>
          </Overlay>
        ) : null}
      </ZStack>
    </NavigationStack>
  )
}
