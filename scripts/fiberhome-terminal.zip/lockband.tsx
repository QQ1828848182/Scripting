// ---------- 锁频段（iOS 设置风格） ----------
// 一级：锁频段开关 + 锁定 4G/5G 频段两行（点进去是二级列表页）
// 二级：频段列表逐行勾选，右上角「保存」
//
// 命令实测（2026-10-28）：
//   SET_LOCK_BAND_ENABLE {Enable:"0"|"1"}  ✅ 真写；但固件在「禁用→启用」时会把频段表重置成全部频段
//   SET_LOCK_BAND_INFO {Frequency:"40,41,77,78", Type:"1"|"2"}  ✅ 真写（13.har 抓包确认；Type 1=4G / 2=5G）

import { useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"
import { Group, NoticeRow, Row, SettingsPage, SwitchRow } from "./lib/settings"
import { KVGroup } from "./lib/kv"

export const GET_BAND = "GET_LOCK_BAND_INFO"
export const SET_ENABLE = "SET_LOCK_BAND_ENABLE"
export const SET_BANDS = "SET_LOCK_BAND_INFO"

export const BANDS_4G = ["B1", "B3", "B5", "B7", "B8", "B20", "B28", "B32", "B38", "B40", "B41", "B42", "B43"]
export const BANDS_5G = ["N1", "N3", "N5", "N7", "N8", "N20", "N28", "N38", "N40", "N41", "N77", "N78"]

/** "78" / "N78" / "78,41" → ["78","41"]（内部一律用不带前缀的数字） */
export function parseBands(raw: any): string[] {
  return String(raw ?? "")
    .split(",")
    .map(s => s.trim().toUpperCase().replace(/^[BN]/, ""))
    .filter(s => s !== "" && /^\d+$/.test(s))
}

const byNum = (a: string, b: string) => Number(a) - Number(b)
export const joinNums = (list: string[]) => [...list].sort(byNum).join(",")

/** 设备值 → 带前缀的展示串（B1,B3 / N1,N3） */
export function withPrefix(list: string[], prefix: "B" | "N"): string {
  return [...list]
    .sort(byNum)
    .map(n => prefix + n)
    .join(",")
}

export const isPending = (err?: string, code?: number) =>
  /超时|timeout|中断/i.test(String(err ?? "")) || code === 20029 || code === 20012

export default function LockBandPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void; onPush: (key: string) => void }) {
  const { session, devices } = props
  const device = devices[0]

  const [band, setBand] = useState<any>(null)
  const [freqBand, setFreqBand] = useState<any>(null)

  const [sel4, setSel4] = useState<string[]>([])
  const [sel5, setSel5] = useState<string[]>([])

  const [loading, setLoading] = useState(false)
  const [busy, setBusy] = useState<"" | "enable" | "bands">("")
  const [error, setError] = useState("")
  const [hint, setHint] = useState("")
  const [toastHint, setToastHint] = useState<Hint | null>(null)

  function applyBand(d: any) {
    setBand(d)
    setSel4(parseBands(d?.Frequency_4G))
    setSel5(parseBands(d?.Frequency_5G))
  }

  async function load(quiet = false) {
    if (!device?.mac || !session.token) return
    if (!quiet) setLoading(true)
    setError("")
    const a = await invokeService<any>(device.mac, session.token, GET_BAND, {}, 10)
    if (!quiet) setLoading(false)
    if (a.ok) {
      applyBand(a.data)
    } else if (!quiet) {
      setError(`${a.error ?? "读取失败"}${a.code !== undefined ? ` (code ${a.code})` : ""}`)
    }

    // 设备回报的锁频状态（GET_LOCK_FREQUENCY_BAND，2026-10-29 实测支持）
    const b = await invokeService<any>(device.mac, session.token, "GET_LOCK_FREQUENCY_BAND", {}, 8)
    if (b.ok) setFreqBand(b.data)
  }
  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  const enabled = String(band?.LockFrequencyBand ?? "0") === "1"
  const dev4 = parseBands(band?.Frequency_4G)
  const dev5 = parseBands(band?.Frequency_5G)
  const dirty4 = joinNums(sel4) !== joinNums(dev4)
  const dirty5 = joinNums(sel5) !== joinNums(dev5)

  /** 开关：切锁频会触发重新注册，超时 ≠ 失败，只认回读。 */
  async function writeEnable(next: boolean) {
    if (!device?.mac || busy) return
    // 首次加载完成前不写（避免进页面误写）
    if (next === enabled && loading) return
    setBusy("enable")
    setError("")
    setHint("")
    if (band) setBand({ ...band, LockFrequencyBand: next ? "1" : "0" })

    const r = await invokeService<any>(device.mac, session.token, SET_ENABLE, { Enable: next ? "1" : "0" }, 15)
    const pending = isPending(r.error, r.code)
    if (!r.ok && !pending) {
      setBusy("")
      if (band) setBand(band)
      setError(`${r.error ?? "写入失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
      return
    }

    let confirmed = false
    for (let i = 0; i < 40; i++) {
      await new Promise<void>(res => setTimeout(res, 1500))
      const c = await invokeService<any>(device.mac, session.token, GET_BAND, {}, 10)
      if (!c.ok) continue
      if (String(c.data?.LockFrequencyBand ?? "") === (next ? "1" : "0")) {
        applyBand(c.data)
        confirmed = true
        break
      }
    }
    setBusy("")
    if (confirmed) {
      setToastHint({ text: "设置成功" })
    } else {
      if (band) setBand(band)
      setHint(pending ? "下发后没等到回读（设备可能还在重注册），稍后下拉刷新确认" : "回读与目标不一致，已恢复显示设备当前值")
      setToastHint({ text: "设置失败", ok: false })
    }
  }

  return (
    <SettingsPage
      title="锁频段"
      refreshable={async () => {
        await load(true)
      }}
      toast={hintToast(toastHint, () => setToastHint(null))}
    >
      {error ? (
        <Group>
          <NoticeRow kind="error" text={error} />
        </Group>
      ) : null}

      {hint ? (
        <Group>
          <NoticeRow kind="info" text={hint} />
        </Group>
      ) : null}

      <Group>
        <SwitchRow label="锁频段" value={enabled} onChanged={v => writeEnable(v)} />
      </Group>

      <Group header="锁定频段">
        <Row
          label="锁定 4G 频段"
          note={(withPrefix(dev4, "B") || "未选择") + (dirty4 ? " · 待保存" : "")}
          chevron
          onTap={() => props.onPush("lockband4g")}
        />
        <Row
          label="锁定 5G 频段"
          note={(withPrefix(dev5, "N") || "未选择") + (dirty5 ? " · 待保存" : "")}
          chevron
          onTap={() => props.onPush("lockband5g")}
        />
      </Group>

      <KVGroup header="设备回报的锁频状态" data={freqBand} />

    </SettingsPage>
  )
}
