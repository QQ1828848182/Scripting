// ---------- 锁频段二级页：某一段的频段列表（真实路由页，原生返回 + 原生滑动返回） ----------
// 规则（对齐网页版）：4G 与 5G 必须分开保存，一次只写一段，另一段原样回写设备当前值。
// SET_LOCK_BAND_INFO 在本固件上一直被拒（json node null），保存失败时如实回报拒因。

import { Button, ZStack, useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"
import { Group, NoticeRow, Row, SettingsPage } from "./lib/settings"
import {
  BANDS_4G,
  BANDS_5G,
  GET_BAND,
  SET_BANDS,
  isPending,
  joinNums,
  parseBands,
} from "./lockband"

export default function LockBandSubPage(props: {
  session: Session
  devices: DeviceInfo[]
  which: "4g" | "5g"
}) {
  const { session, devices, which } = props
  const device = devices[0]
  const is4 = which === "4g"
  const list = is4 ? BANDS_4G : BANDS_5G

  const [band, setBand] = useState<any>(null)
  const [sel, setSel] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [busy, setBusy] = useState(false)
  const [hint, setHint] = useState("")
  const [confirming, setConfirming] = useState(false)
  const [toastHint, setToastHint] = useState<Hint | null>(null)

  async function load() {
    if (!device?.mac || !session.token) return
    setLoading(true)
    const r = await invokeService<any>(device.mac, session.token, GET_BAND, {}, 10)
    setLoading(false)
    if (!r.ok) {
      setToastHint({ text: `${r.error ?? "读取失败"}`, ok: false })
      return
    }
    setBand(r.data)
    setSel(parseBands(is4 ? r.data?.Frequency_4G : r.data?.Frequency_5G))
  }

  useEffect(() => {
    load()
  }, [device?.mac, session.token, which])

  const dev4 = parseBands(band?.Frequency_4G)
  const dev5 = parseBands(band?.Frequency_5G)
  const devList = is4 ? dev4 : dev5
  const dirty = joinNums(sel) !== joinNums(devList)

  async function save() {
    if (!device?.mac || busy) return
    if (!confirming) {
      setConfirming(true)
      setHint(`再点一次「保存」写入 ${is4 ? "4G" : "5G"} 频段`)
      setTimeout(() => setConfirming(false), 4000)
      return
    }
    setConfirming(false)
    setBusy(true)
    setHint("")
    const target = joinNums(sel)
    // 13.har 实测：SET_LOCK_BAND_INFO 只接 { Frequency: "40,41,77,78", Type: "1"|"2" }
    // Type 1 = 4G，Type 2 = 5G；一次只写一段，另一段设备自己保留。
    const param = {
      SequenceId: is4 ? "band_4g_save" : "band_5g_save",
      Frequency: target,
      Type: is4 ? "1" : "2",
    }
    const r = await invokeService<any>(device.mac, session.token, SET_BANDS, param, 15)
    const pending = isPending(r.error, r.code)

    if (r.ok) {
      let confirmed = false
      for (let i = 0; i < 25; i++) {
        await new Promise<void>(res => setTimeout(res, 1500))
        const c = await invokeService<any>(device.mac!, session.token, GET_BAND, {}, 10)
        if (!c.ok) continue
        const got = joinNums(parseBands(is4 ? c.data?.Frequency_4G : c.data?.Frequency_5G))
        if (got === target) {
          setBand(c.data)
          setSel(parseBands(is4 ? c.data?.Frequency_4G : c.data?.Frequency_5G))
          confirmed = true
          break
        }
      }
      setBusy(false)
      setToastHint(confirmed ? { text: `已保存 ${is4 ? "4G" : "5G"} 频段` } : { text: "已下发，回读未确认", ok: false })
      if (!confirmed) setHint("已下发，但回读未确认，稍后下拉刷新再看")
      return
    }

    setBusy(false)
    if (pending) {
      setHint("下发超时（设备可能在重注册），稍后下拉刷新确认")
      return
    }
    setHint(
      `写入被拒：${r.error ?? "未知原因"}。可选中保底操作：打开网页版 192.168.8.1 → 蜂窝上行 → 锁频段。`
    )
    setToastHint({ text: r.error ?? "写入失败", ok: false })
  }

  return (
    <ZStack
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      toolbar={{
        topBarTrailing: (
          <Button
            title={busy ? "保存中…" : confirming ? "确认保存" : "保存"}
            action={save}
            disabled={busy || loading || !dirty}
          />
        ),
      }}
    >
      <SettingsPage
        title={`锁定 ${is4 ? "4G" : "5G"} 频段`}
        refreshable={load}
        toast={hintToast(toastHint, () => setToastHint(null))}
      >
      {hint ? (
        <Group>
          <NoticeRow kind="info" text={hint} />
        </Group>
      ) : null}

      <Group
        header={`${is4 ? "4G" : "5G"} 频段`}
      >
        {list.map(item => {
          const num = item.replace(/^[A-Z]/, "")
          const on = sel.includes(num)
          return (
            <Row
              key={item}
              label={item}
              selected={on}
              onTap={() => setSel(on ? sel.filter(x => x !== num) : [...sel, num])}
            />
          )
        })}
      </Group>
      </SettingsPage>
    </ZStack>
  )
}
