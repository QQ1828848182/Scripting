#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
接口层行为验证：把 lib/md5.ts + lib/api.ts 的纯逻辑用 Python 等价实现，
用抓包里的真实响应对照解析结果（MD5、候选请求体、响应拆包、字段格式化）。
"""
import hashlib, json, math, os, re, sys

# ---------- 1. MD5（与 lib/md5.ts 同算法的 Python 版） ----------
S = [7, 12, 17, 22] * 4 + [5, 9, 14, 20] * 4 + [4, 11, 16, 23] * 4 + [6, 10, 15, 21] * 4
K = [int(abs(math.sin(i + 1)) * 4294967296) for i in range(64)]
M32 = 0xFFFFFFFF


def md5(s: str) -> str:
    b = bytearray(s.encode("utf-8"))
    bit = len(b) * 8
    b.append(0x80)
    while len(b) % 64 != 56:
        b.append(0)
    b += (bit & 0xFFFFFFFFFFFFFFFF).to_bytes(8, "little")
    a0, b0, c0, d0 = 0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476
    for off in range(0, len(b), 64):
        M = [int.from_bytes(b[off + j * 4: off + j * 4 + 4], "little") for j in range(16)]
        A, B, C, D = a0, b0, c0, d0
        for i in range(64):
            if i < 16:
                F, g = (B & C) | (~B & D), i
            elif i < 32:
                F, g = (D & B) | (~D & C), (5 * i + 1) % 16
            elif i < 48:
                F, g = B ^ C ^ D, (3 * i + 5) % 16
            else:
                F, g = C ^ (B | ~D), (7 * i) % 16
            F &= M32
            tmp = D
            D, C = C, B
            B = (B + (((A + F + K[i] + M[g]) & M32) << S[i] | ((A + F + K[i] + M[g]) & M32) >> (32 - S[i]))) & M32
            A = tmp
        a0, b0, c0, d0 = (a0 + A) & M32, (b0 + B) & M32, (c0 + C) & M32, (d0 + D) & M32
    return "".join(x.to_bytes(4, "little").hex() for x in (a0, b0, c0, d0))


def check(name, got, want):
    ok = got == want
    print(("  ✓ " if ok else "  ✗ ") + name + ("" if ok else f"\n      got={got!r}\n     want={want!r}"))
    return ok


ok = True
print("[1] MD5")
for s in ["", "abc", "example_user", "中文密码123", "😀emoji", "a" * 1000]:
    ok &= check(f"md5({s[:14]!r})", md5(s), hashlib.md5(s.encode()).hexdigest())

# ---------- 2. 密码候选（对应 buildPasswordCandidates） ----------
print("\n[2] 密码候选（auto 顺序）")
acc, pw = "example_user", "example_pass"
cands = {
    "md5": md5(pw),
    "plain": pw,
    "doubleMd5": md5(md5(pw)),
    "md5AppendToken": md5(pw + "2.2.51"),
}
ok &= check("md5 密码长度 32", len(cands["md5"]), 32)
ok &= check("doubleMd5 != md5", cands["doubleMd5"] != cands["md5"], True)
for k, v in cands.items():
    print(f"      {k:16s} {v[:24]}{'…' if len(v) > 24 else ''}")

# ---------- 3. 真实响应解析（抓包 16140 / 16141 / 16170） ----------
print("\n[3] 响应解析")
CAP = os.environ.get("FH_CAPTURES") or "./captures"
if not os.path.isdir(CAP):
    print(f"      跳过：未找到抓包目录 {CAP}")
    print(f"      （仓库不包含抓包，设置 FH_CAPTURES 指向你的抓包目录可启用本段）")
    print("\n结果：部分跳过（无抓包）")
    sys.exit(0)
dev_raw = open(CAP + "/16140_19411_1793081787474/response_body_raw", encoding="utf-8").read()
dev = json.loads(dev_raw)
ok &= check("resultCode == 0", dev["resultCode"], 0)
list_ = dev.get("bindDeviceInfoVOs", [])
ok &= check("设备数量", len(list_), 1)
d = list_[0]
ok &= check("型号", d["model"], "LG6851F")
ok &= check("在线(布尔)", d["online"], True)
ok &= check("filinkStatus 是字符串", isinstance(d["filinkStatus"], str), True)


def fmt_mac(mac):
    s = re.sub(r"[^0-9a-fA-F]", "", str(mac)).upper()
    return ":".join(s[i:i + 2] for i in range(0, 12, 2)) if len(s) == 12 else str(mac)


def is_online(x):
    if isinstance(x.get("online"), bool):
        return x["online"]
    return str(x.get("filinkStatus", "")) == "1"


ok &= check("MAC 格式化", fmt_mac(d["mac"]), "AA:BB:CC:DD:EE:FF")
ok &= check("在线判定", is_online(d), True)
ok &= check("离线设备判定", is_online({**d, "online": False}), False)
ok &= check("子设备数为 0", len(d.get("slaveDeviceInfos") or []), 0)

notice = json.loads(open(CAP + "/16141_19423_1793081787939/response_body_raw", encoding="utf-8").read())
ok &= check("getNotice 无资料字段", notice.get("title"), None)
ok &= check("getNotice resultCode", notice["resultCode"], 0)

img = json.loads(open(CAP + "/16170_19456_1793081830186/response_body_raw", encoding="utf-8").read())
fw = img["routerVerInfos"][0]
ok &= check("固件版本号", fw["version"], "RP0112")
ok &= check("固件包体积", fw["size"], 140110)
ok &= check("升级说明含换行", "\n" in fw["descriptions"], True)

# ---------- 4. 错误分支 ----------
print("\n[4] 错误分支")
unbind = json.loads(open(CAP + "/16139_19410_1793081787474/response_body_raw", encoding="utf-8").read())
ok &= check("业务错误码 20007 不算成功", unbind["resultCode"] != 0, True)
ok &= check("错误描述透传", unbind["resultDesc"], "绑定关系不存在")


# 登录响应三种可能的承载位置
def extract_token(payload):
    data = payload.get("data") or payload.get("rspParam") or payload.get("userInfo") or payload
    return data.get("token") or payload.get("token") or data.get("access_token") or payload.get("access_token") or ""


for label, payload in [
    ("顶层 token", {"resultCode": 0, "token": "abc"}),
    ("data.token", {"resultCode": 0, "data": {"token": "abc", "username": "u"}}),
    ("rspParam.token", {"resultCode": 0, "rspParam": {"token": "abc"}}),
    ("access_token", {"resultCode": 0, "userInfo": {"access_token": "abc"}}),
]:
    ok &= check(f"token 提取 · {label}", extract_token(payload), "abc")
ok &= check("无 token 判定", extract_token({"resultCode": 0, "rspParam": None}), "")

# ---------- 5. 抓包中的真实 token 形态 ----------
print("\n[5] 抓包对照")
token = "0123456789abcdef0123456789abcdef0"  # 示例占位
ok &= check("线上 token 长度 33", len(token), 33)
ok &= check("maskToken", f"{token[:4]}••••{token[-4:]}", "00db••••79db6"[:4] + "••••" + token[-4:])

print("\n结果：" + ("全部通过 ✅" if ok else "存在失败 ❌"))
sys.exit(0 if ok else 1)
