#!/usr/bin/env python3
"""对 Scripting 项目做语法自检：esbuild 解析 TS/TSX（含 JSX 自动运行时）。"""
import esbuild, glob, sys, os

root = os.environ.get("FH_ROOT") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
launcher = esbuild.EsBuildLauncher(auto_install=True)
if not launcher.bin_path.exists():
    launcher.install()

files = sorted(
    f for f in glob.glob(os.path.join(root, "**", "*.ts*"), recursive=True)
)
fail = 0
for f in files:
    try:
        launcher.run([f, "--loader:.tsx=tsx", "--loader:.ts=ts", "--jsx=transform", "--format=esm"])
        print("OK   ", os.path.relpath(f, root))
    except Exception as e:
        fail += 1
        msg = getattr(e, "stderr", b"")
        print("FAIL ", os.path.relpath(f, root), msg.decode()[:900] if msg else str(e)[:900])

print("\n%d files, %d failed" % (len(files), fail))
sys.exit(1 if fail else 0)
