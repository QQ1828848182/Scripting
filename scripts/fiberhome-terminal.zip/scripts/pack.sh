#!/bin/sh
# 把仓库打成一个可直接导入 Scripting 的 .scripting 包（本质是 zip）
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
cd "$ROOT"
OUT=${1:-fiberhome-terminal.scripting}
rm -f "$OUT"
command -v zip >/dev/null 2>&1 || { echo "需要 zip：apk add zip / brew install zip"; exit 1; }
zip -rq "$OUT" . -x \
  "./.git/*" "./.github/*" "./docs/*" "./scripts/*" "./node_modules/*" \
  "./$OUT" "./*.zip" "./*.scripting" "./LICENSE" "./.gitignore" "./README.md"
echo "已生成：$ROOT/$OUT"
unzip -l "$OUT" | tail -3
