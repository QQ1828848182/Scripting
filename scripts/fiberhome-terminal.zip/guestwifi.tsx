// ---------- 访客 Wi-Fi（GET_GUEST_WIFI_LIST_INFO，13.har 抓包确认结构与主 Wi-Fi 一致） ----------
// 写入命令未抓包，按命名惯例试 SET_GUEST_WIFI_LIST_INFO；设备若原样回显会如实提示。

import { Button, HStack, Image, SecureField, Text, TextField, ZStack, useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"
import { Group, InputRow, NoticeRow, Row, SettingsPage, SwitchRow } from "./lib/settings"

type Slot = { index: string; type: string; ssid: string; pwd: string; enable: boolean }

export default function GuestWifiPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices[0]

  const [raw, setRaw] = useState<any>(null)
  const [slots, setSlots] = useState<Slot[]>([])
  const [orig, setOrig] = useState("")
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [hint, setHint] = useState("")
  const [toastHint, setToastHint] = useState<Hint | null>(null)
  const [shown, setShown] = useState<Record<string, boolean>>({})

  async function load() {
    if (!device?.mac || !session.token) return
    setLoading(true)
    const r = await invokeService<any>(device.mac, session.token, "GET_GUEST_WIFI_LIST_INFO", {}, 10)
    setLoading(false)
    if (!r.ok) {
      setToastHint({ text: r.error ?? "读取失败", ok: false })
      return
    }
    publicApply(r.data)
  }

  function publicApply(d: any) {
    setRaw(d ?? {})
    const arr: any[] = Array.isArray(d?.WIFIList) ? d.WIFIList : []
    const parsed: Slot[] = arr.map((it: any) => ({
      index: String(it.SSIDIndex ?? ""),
      type: String(it.Type ?? "0"),
      ssid: String(it.SSID ?? ""),
      pwd: String(it.PWD ?? ""),
      enable: String(it.Enable ?? "0") === "1",
    }))
    parsed.sort((a, b) => Number(a.type) - Number(b.type))
    setSlots(parsed)
    setOrig(JSON.stringify(parsed))
  }

  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  const dirty = JSON.stringify(slots) !== orig

  function patchSlot(index: string, patch: Partial<Slot>) {
    setSlots(prev => prev.map(s => (s.index === index ? { ...s, ...patch } : s)))
  }

  async function save() {
    if (!device?.mac || saving) return
    setSaving(true)
    setHint("")
    const list = (Array.isArray(raw?.WIFIList) ? raw.WIFIList : []).map((it: any) => {
      const s = slots.find(x => x.index === String(it.SSIDIndex))
      const base = { ...it, isLoading: false }
      if (!s) return base
      return { ...base, SSID: s.ssid, PWD: s.pwd, Enable: s.enable ? "1" : "0" }
    })
    const r = await invokeService<any>(
      device.mac,
      session.token,
      "SET_GUEST_WIFI_LIST_INFO",
      {
        SequenceId: "guest_wifi_set",
        WIFILIST: list,
        radio_enable_2: String(raw?.radio_enable_2 ?? "1"),
        radio_enable_5: String(raw?.radio_enable_5 ?? "1"),
      },
      25
    )
    setSaving(false)
    if (!r.ok) {
      setHint(`${r.error ?? "写入失败"}（访客 Wi-Fi 的写入命令没有抓到包，若设备回显请求说明不支持，请用 192.168.8.1 网页版）`)
      setToastHint({ text: "保存失败", ok: false })
      return
    }
    const status = String(r.data?.Status ?? "")
    if (status !== "" && status !== "0") {
      setHint(`设备拒绝：${String(r.data?.FailReason ?? `Status=${status}`)}`)
      setToastHint({ text: "保存失败", ok: false })
      return
    }
    setToastHint({ text: "设置成功" })
    load()
  }

  return (
    <ZStack
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      toolbar={{
        topBarTrailing: (
          <Button
            title={saving ? "保存中…" : "保存"}
            action={save}
            disabled={saving || loading || !dirty}
          />
        ),
      }}
    >
      <SettingsPage
        title="访客 Wi-Fi"
        refreshable={load}
        toast={hintToast(toastHint, () => setToastHint(null))}
      >
      {hint ? (
        <Group>
          <NoticeRow kind="error" text={hint} />
        </Group>
      ) : null}

      {slots.length === 0 ? (
        <Group footer="与主 Wi-Fi 隔离，客人用这个。">
          <NoticeRow kind="info" text={loading ? "读取中…" : "设备没有返回访客 Wi-Fi 配置（可能固件不支持）。"} />
        </Group>
      ) : null}

      {slots.map(s => (
        <Group key={s.index} header={`${s.type === "1" ? "5G" : "2.4G"} 访客`}>
          <SwitchRow label="启用" value={s.enable} onChanged={v => patchSlot(s.index, { enable: v })} />
          <InputRow
            label="名称"
            value={s.ssid}
            onChanged={v => patchSlot(s.index, { ssid: v })}
            prompt="访客网络名称"
          />
          <Row
            content={
              <HStack spacing={10} frame={{ maxWidth: "infinity" }}>
                <Text>密码</Text>
                {shown[s.index] ? (
                  <TextField
                    title=""
                    value={s.pwd}
                    onChanged={v => patchSlot(s.index, { pwd: v })}
                    autocorrectionDisabled
                    multilineTextAlignment="trailing"
                    frame={{ maxWidth: "infinity" }}
                  />
                ) : (
                  <SecureField
                    title=""
                    value={s.pwd}
                    onChanged={v => patchSlot(s.index, { pwd: v })}
                    multilineTextAlignment="trailing"
                    frame={{ maxWidth: "infinity" }}
                  />
                )}
                <Image
                  systemName={shown[s.index] ? "eye.slash" : "eye"}
                  font={14}
                  foregroundStyle="secondaryLabel"
                  contentShape="rect"
                  onTapGesture={() => setShown(m => ({ ...m, [s.index]: !m[s.index] }))}
                />
              </HStack>
            }
          />
        </Group>
      ))}
      </SettingsPage>
    </ZStack>
  )
}
