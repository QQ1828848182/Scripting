// ---------- MLO（Multi-Link Operation，Wi-Fi 7 多链路） ----------
// 读：GET_WIFI_MLO_LIST → mlo_list: [{ index, mlo_name, pass_wd, encryption_mode, mode_enable, enable }]
//     实测真实字段（2026-10-29）：{"mode_enable":"5","pass_wd":"********","mlo_name":"NULL","enable":"1","index":"1","encryption_mode":"TKIPandAES"}
// 写：SET_WIFI_MLO_LIST { mlo_list:[{...同字段}], Operate:"1" }
//     ⚠️ 早期用 ssid_index_2g/ssid_name 那种键会被设备忽略（落库成 NULL），必须用上面这套字段名。
// 删：DEL_WIFI_MLO { index }
// 注意：外层 Result=0 不代表成功（设备会把请求原样回显），一切以回读列表为准。

import { HStack, Image, Spacer, Text, VStack, ZStack, useEffect, useState } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { fetchMainWifi } from "./lib/cmds"
import type { WifiEntry } from "./lib/cmds"
import { invokeService } from "./lib/invoke"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"
import { Overlay, GlassDialog } from "./lib/pickers"
import { ButtonPairRow, ButtonRow, Group, InputRow, NoticeRow, OK, PasswordRow, PickerRow, Row, SecretRow, SettingsPage, SwitchRow } from "./lib/settings"

/** 加密模式（认证方式）→ 设备 mode_enable。5 / 8 已由 web 后台实测对照，其余为推测 */
const AUTH_MODES: { value: string; label: string; known?: boolean }[] = [
  { value: "1", label: "不加密" },
  { value: "2", label: "WPA-PSK" },
  { value: "3", label: "WPA2-PSK" },
  { value: "4", label: "WPA3-SAE" },
  { value: "5", label: "WPA/WPA2-PSK", known: true },
  { value: "8", label: "WPA2/WPA3-SAE", known: true },
]

/** 加密算法由加密模式推导，界面上不单独暴露 */
function cipherForMode(mode: string): string {
  if (mode === "1") return "NONE"
  if (mode === "3" || mode === "4") return "AES"
  return "TKIPandAES"
}

function authLabel(v: string): string {
  const s = String(v ?? "").trim()
  if (!s) return "—"
  return AUTH_MODES.find(a => a.value === s)?.label ?? `模式 ${s}`
}

/** 从对象里按候选键取第一个非空字符串 */
function str(o: any, keys: string[]): string {
  for (const k of keys) {
    const v = o?.[k]
    if (v !== undefined && v !== null && String(v).trim() !== "") return String(v).trim()
  }
  return ""
}

/** 5G 的 SSID 索引是接着 2.4G 排的（1–4 / 5–8），显示时换算成频段内序号 */
function showIdx(v: string): string {
  const n = Number(v)
  return isFinite(n) && n > 4 ? String(n - 4) : v
}

function isNullText(v: string): boolean {
  return v === "" || v.toUpperCase() === "NULL"
}

/** 绑定 Wi-Fi 的两列选择弹窗（2.4G / 5G） */
export function BindDialog(props: {
  list: WifiEntry[]
  sel2: string
  sel5: string
  onPick: (type: "0" | "1", index: string) => void
  onClose: () => void
  onDone: () => void
}) {
  const col = (type: "0" | "1", title: string, sel: string) => {
    const items = props.list.filter(e => e.type === type)
    return (
      <VStack spacing={0} frame={{ maxWidth: "infinity" }}>
        <Text font="caption" foregroundStyle="secondaryLabel" padding={{ vertical: 6 }}>
          {title}
        </Text>
        {items.length === 0 ? (
          <Text font="caption" foregroundStyle="tertiaryLabel" padding={{ vertical: 8 }}>
            无
          </Text>
        ) : null}
        {items.map(e => {
          const usable = e.enable !== "0"
          const picked = sel === e.index
          const n = Number(e.index)
          const shown = type === "1" && n > 4 ? n - 4 : n
          return (
            <HStack
              key={e.index}
              spacing={6}
              padding={{ vertical: 10 }}
              frame={{ maxWidth: "infinity" }}
              contentShape="rect"
              onTapGesture={() => {
                if (usable) props.onPick(type, e.index)
              }}
            >
              <VStack alignment="leading" spacing={1}>
                <Text font="subheadline" foregroundStyle={usable ? "label" : "tertiaryLabel"}>
                  {`SSID ${shown}`}
                </Text>
                {e.ssid ? (
                  <Text font="caption2" foregroundStyle="tertiaryLabel" lineLimit={1}>
                    {e.ssid}
                  </Text>
                ) : null}
              </VStack>
              <Spacer />
              <Image
                systemName={picked ? "checkmark.circle.fill" : "circle"}
                font={15}
                foregroundStyle={picked ? OK : usable ? "tertiaryLabel" : "quaternaryLabel"}
              />
            </HStack>
          )
        })}
      </VStack>
    )
  }

  return (
    <Overlay onDismiss={props.onClose}>
      <GlassDialog width={340}>
        <Text font="subheadline" fontWeight="semibold" frame={{ maxWidth: "infinity" }}>
          绑定 Wi-Fi
        </Text>
        <Text font="caption" foregroundStyle="secondaryLabel" frame={{ maxWidth: "infinity", alignment: "leading" }}>
          请选择一个 2.4G 和 5G 频段的 SSID 进行绑定；已绑定或关闭状态的 SSID 无法绑定。
        </Text>
        <HStack spacing={10} frame={{ maxWidth: "infinity" }}>
          {col("0", "2.4G", props.sel2)}
          {col("1", "5G", props.sel5)}
        </HStack>
        <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
          <ButtonRow title="取消" onTap={props.onClose} />
          <ButtonRow
            title="完成"
            disabled={!props.sel2 || !props.sel5}
            onTap={() => {
              if (props.sel2 && props.sel5) props.onDone()
            }}
          />
        </HStack>
      </GlassDialog>
    </Overlay>
  )
}

export default function MloPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices?.[0]

  const [mlo, setMlo] = useState<any[]>([])
  const [wifi, setWifi] = useState<WifiEntry[]>([])
  const [error, setError] = useState("")
  const [hint, setHint] = useState<Hint | null>(null)

  const [sel2, setSel2] = useState("")
  const [sel5, setSel5] = useState("")
  const [mName, setMName] = useState("")
  const [mPwd, setMPwd] = useState("")
  const [mMode, setMMode] = useState("5")
  const [mEnable, setMEnable] = useState(true)
  // 编辑已有 MLO
  const [editIdx, setEditIdx] = useState("")
  const [eName, setEName] = useState("")
  const [ePwd, setEPwd] = useState("")
  const [eMode, setEMode] = useState("5")
  const [eEnable, setEEnable] = useState(true)
  const [eI2, setEI2] = useState("")
  const [eI5, setEI5] = useState("")
  const [eLinks, setELinks] = useState("")
  const [bindOpen, setBindOpen] = useState(false)
  const [busy, setBusy] = useState("")
  const [progress, setProgress] = useState("")
  const [confirmDel, setConfirmDel] = useState("")

  async function load() {
    const mac = device?.mac
    const token = session.token
    if (!mac || !token) return
    setError("")
    const [a, w] = await Promise.all([
      invokeService<any>(mac, token, "GET_WIFI_MLO_LIST", {}, 10),
      fetchMainWifi(mac, token),
    ])
    if (a.ok) {
      const arr = Array.isArray(a.data?.mlo_list) ? a.data.mlo_list : []
      setMlo(arr)
    } else {
      setError(`${a.error ?? "读取 MLO 列表失败"}${a.code !== undefined ? ` (code ${a.code})` : ""}`)
    }
    if (w.ok && w.data) setWifi(w.data.list)
  }

  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  async function createMlo() {
    const mac = device?.mac
    const token = session.token
    if (!mac || !token || busy) return
    if (!sel2 || !sel5) {
      setHint({ text: "先选 2.4G 和 5G 的 SSID", ok: false })
      return
    }
    if (mEnable && !mName.trim()) {
      setHint({ text: "请填写 MLO Wi-Fi 名称", ok: false })
      return
    }
    setBusy("create")
    setHint(null)
    setProgress("")

    const cipher = cipherForMode(mMode)
    const name = mName.trim()
    // 空槽位序号：MLO 最多 4 条，index 1..4
    const used = mlo.map(m => String(m?.index ?? "")).filter(Boolean)
    const slot = ["1", "2", "3", "4"].find(i => !used.includes(i)) ?? "1"

    const item = {
      mlo_name: name,
      pass_wd: mPwd,
      encryption_mode: cipher,
      mode_enable: mMode,
      enable: mEnable ? "1" : "0",
      ssid_2g_index: sel2,
      ssid_5g_index: sel5,
    }

    // 只以「回读里出现这个名称」为准（Result=0 会被设备原样回显）
    const attempts: { label: string; params: any }[] = [
      { label: "全字段（含 ssid_2g/5g_index）", params: { mlo_list: [item], Operate: "1" } },
      {
        label: "同上 + 显式 index",
        params: { mlo_list: [{ ...item, index: slot }], Operate: "1" },
      },
      {
        label: "无 mode_enable",
        params: {
          mlo_list: [{ mlo_name: name, pass_wd: mPwd, encryption_mode: cipher, enable: mEnable ? "1" : "0", ssid_2g_index: sel2, ssid_5g_index: sel5 }],
          Operate: "1",
        },
      },
    ]

    let winner = ""
    let workerDone = false
    let lastErr = ""
    for (let i = 0; i < attempts.length; i++) {
      const a = attempts[i]
      const r = await invokeService<any>(mac, token, "SET_WIFI_MLO_LIST", a.params, 20)
      if (!r.ok) {
        lastErr = r.error ?? "被拒"
        continue
      }
      const after = await invokeService<any>(mac, token, "GET_WIFI_MLO_LIST", {}, 10)
      const arr = after.ok && Array.isArray(after.data?.mlo_list) ? after.data.mlo_list : []
      const hit = arr.some((x: any) => String(x?.mlo_name ?? "") === name)
      const linked = arr.some((x: any) => String(x?.mlo_name ?? "") === name && str(x, ["ssid_2g_index"]) && str(x, ["ssid_5g_index"]))
      if (arr.length) setMlo(arr)
      if (hit && linked) {
        winner = a.label
        break
      }
      if (hit && !workerDone) {
        // 名称写进去了但绑定没写：记下来继续试下一种
        workerDone = true
      }
    }

    setBusy("")
    setProgress("")
    if (winner) {
      setHint({ text: "新建成功" })
      await load()
    } else if (workerDone) {
      setHint({ text: "名称写入了，但频段绑定失败，请重试", ok: false })
    } else {
      setHint({ text: `新建失败${lastErr ? `：${lastErr}` : ""}`, ok: false })
    }
  }

  async function removeMlo(index: string) {
    const mac = device?.mac
    const token = session.token
    if (!mac || !token || busy) return
    if (confirmDel !== index) {
      setConfirmDel(index)
      setTimeout(() => setConfirmDel(""), 5000)
      return
    }
    setConfirmDel("")
    setBusy(`del-${index}`)
    const r = await invokeService<any>(mac, token, "DEL_WIFI_MLO", { index }, 15)
    setBusy("")
    if (r.ok) {
      setHint({ text: `已删除 MLO ${index}` })
      await load()
    } else setHint({ text: `删除失败：${r.error ?? "未知"}`, ok: false })
  }

  function openEdit(m: any, idx: string) {
    const a = str(m, ["mode_enable", "mode"]) || "5"
    const nm = str(m, ["mlo_name", "ssid_name"])
    const i2 = str(m, ["ssid_2g_index", "ssid_index_2g"])
    const i5 = str(m, ["ssid_5g_index", "ssid_index_5g"])
    setEditIdx(idx)
    setEName(isNullText(nm) ? "" : nm)
    setEPwd(str(m, ["pass_wd", "ssid_pwd", "pwd"]))
    setEMode(AUTH_MODES.some(x => x.value === a) ? a : "5")
    setEEnable(str(m, ["enable"]) !== "0")
    setEI2(i2)
    setEI5(i5)
    setELinks(
      [i2 ? `2.4G SSID ${showIdx(i2)}` : "", i5 ? `5G SSID ${showIdx(i5)}` : ""].filter(Boolean).join(" · ")
    )
    setHint(null)
  }

  async function saveEdit() {
    const mac = device?.mac
    const token = session.token
    if (!mac || !token || busy || !editIdx) return
    const name = eName.trim()
    if (eEnable && !name) {
      setHint({ text: "请填写 MLO Wi-Fi 名称", ok: false })
      return
    }
    setBusy(`edit-${editIdx}`)
    setHint(null)
    setProgress("")

    const item: any = {
      index: editIdx,
      mlo_name: name,
      pass_wd: ePwd,
      encryption_mode: cipherForMode(eMode),
      mode_enable: eMode,
      enable: eEnable ? "1" : "0",
    }
    if (eI2) item.ssid_2g_index = eI2
    if (eI5) item.ssid_5g_index = eI5

    const attempts: { label: string; params: any }[] = [
      { label: "带 index 覆盖（Operate 1）", params: { mlo_list: [item], Operate: "1" } },
      { label: "带 index 覆盖（Operate 2）", params: { mlo_list: [item], Operate: "2" } },
      { label: "只发改动字段", params: { mlo_list: [{ index: editIdx, mlo_name: name, pass_wd: ePwd }], Operate: "1" } },
    ]

    let ok = false
    let lastErr = ""
    for (let i = 0; i < attempts.length; i++) {
      const a = attempts[i]
      const r = await invokeService<any>(mac, token, "SET_WIFI_MLO_LIST", a.params, 20)
      if (!r.ok) {
        lastErr = r.error ?? "被拒"
        continue
      }
      const g = await invokeService<any>(mac, token, "GET_WIFI_MLO_LIST", {}, 10)
      const arr = Array.isArray(g.data?.mlo_list) ? g.data.mlo_list : []
      const hit = arr.find((x: any) => String(x?.index ?? "") === editIdx)
      const nameOk = !!hit && String(hit?.mlo_name ?? "") === name
      const pwdOk = !ePwd || (!!hit && String(hit?.pass_wd ?? "") === ePwd)
      const authOk = !!hit && str(hit, ["mode_enable", "mode"]) === eMode
      const enableOk = !!hit && (str(hit, ["enable"]) !== "0") === eEnable
      if (arr.length) setMlo(arr)
      if (nameOk && pwdOk && authOk && enableOk) {
        ok = true
        break
      }
    }
    setBusy("")
    setProgress("")
    if (ok) {
      setEditIdx("")
      setHint({ text: `已保存 MLO #${editIdx}` })
      await load()
    } else {
      setHint({ text: `保存失败${lastErr ? `：${lastErr}` : "，请重试"}`, ok: false })
    }
  }

  const boundLabel = () => {
    if (!sel2 && !sel5) return "请选择"
    return [sel2 ? `2.4G SSID ${showIdx(sel2)}` : "2.4G 未选", sel5 ? `5G SSID ${showIdx(sel5)}` : "5G 未选"].join("、")
  }

  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      <SettingsPage title="MLO" refreshable={load} toast={hintToast(hint, () => setHint(null))}>
        <Group footer="建立不同频段 Wi-Fi 的绑定关系，使设备可同时连接到多个 Wi-Fi 频段，提高 Wi-Fi 网络性能和稳定性。">
          <Row label="Multi-Link Operation" icon="link.badge.plus" iconColor="#0A84FF" value="" />
        </Group>

        {error ? (
          <Group>
            <NoticeRow kind="error" text={error} />
          </Group>
        ) : null}

        {mlo.length === 0 ? (
          <Group header="MLO Wi-Fi（0/4）">
            <Row label="暂无 MLO Wi-Fi" icon="tray" value="空" valueColor="tertiaryLabel" />
          </Group>
        ) : (
          mlo.map((m: any, i: number) => {
            const idx = String(m?.index ?? i + 1)
            const rawName = str(m, ["mlo_name", "ssid_name"])
            const name = isNullText(rawName) ? "（未命名）" : rawName
            const pwd = str(m, ["pass_wd", "ssid_pwd", "pwd"])
            const auth = str(m, ["mode_enable", "mode"])
            const enabled = str(m, ["enable"]) !== "0"
            const i2 = str(m, ["ssid_2g_index", "ssid_index_2g"])
            const i5 = str(m, ["ssid_5g_index", "ssid_index_5g"])
            const links = [i2 ? `2.4G SSID ${showIdx(i2)}` : "", i5 ? `5G SSID ${showIdx(i5)}` : ""]
              .filter(Boolean)
              .join(" · ")
            return (
              <Group key={`${idx}-${i}`} header={i === 0 ? `MLO Wi-Fi（${mlo.length}/4）` : undefined}>
                <Row
                  label={name}
                  note={links ? `Links ${links}` : "Links 未绑定"}
                  icon="wifi"
                  iconColor={enabled ? OK : "secondaryLabel"}
                  value={`#${idx}`}
                  valueColor="tertiaryLabel"
                  chevron="right"
                  onTap={() => {
                    if (!busy) openEdit(m, idx)
                  }}
                />
                <Row label="加密模式" value={authLabel(auth)} />
                <SecretRow label="密码" value={pwd} />
                <Row label="状态" value={enabled ? "已启用" : "已关闭"} valueColor={enabled ? OK : "secondaryLabel"} />
                <Row
                  label="删除这条 MLO"
                  value={busy === `del-${idx}` ? "删除中…" : confirmDel === idx ? "再点一次确认" : "删除"}
                  valueColor={confirmDel === idx ? "#FF3B30" : "secondaryLabel"}
                  onTap={() => removeMlo(idx)}
                />
              </Group>
            )
          })
        )}

        {editIdx ? (
          <Group header={`编辑 MLO #${editIdx}`}>
            <Row label="绑定频段" value={eLinks || "未绑定"} valueColor={eLinks ? undefined : "tertiaryLabel"} />
            <SwitchRow label="MLO Wi-Fi" note="关闭则不启用该 MLO 无线" value={eEnable} onChanged={setEEnable} />
            <InputRow label="Wi-Fi 名称" value={eName} prompt="请输入 Wi-Fi 名称" autocorrectionDisabled onChanged={setEName} />
            <PasswordRow label="Wi-Fi 密码" value={ePwd} prompt="请输入 Wi-Fi 密码" autocorrectionDisabled onChanged={setEPwd} />
            <PickerRow
              label="加密模式"
              value={authLabel(eMode)}
              selected={eMode}
              options={AUTH_MODES.map(a => ({ value: a.value, label: a.label }))}
              onSelect={setEMode}
            />
            <ButtonPairRow
              confirmTitle={busy === `edit-${editIdx}` ? "保存中…" : "保存"}
              busy={busy === `edit-${editIdx}`}
              onCancel={() => setEditIdx("")}
              onConfirm={() => saveEdit()}
            />
          </Group>
        ) : (
        <Group header="新建 MLO">
          <Row
            label="绑定 Wi-Fi"
            value={boundLabel()}
            chevron="right"
            onTap={() => {
              if (!busy) setBindOpen(true)
            }}
          />
          <SwitchRow label="MLO Wi-Fi" note="关闭则不启用该 MLO 无线" value={mEnable} onChanged={setMEnable} />
          {mEnable ? (
            <>
              <InputRow label="Wi-Fi 名称" value={mName} prompt="请输入 Wi-Fi 名称" autocorrectionDisabled onChanged={setMName} />
              <PasswordRow label="Wi-Fi 密码" value={mPwd} prompt="请输入 Wi-Fi 密码" autocorrectionDisabled onChanged={setMPwd} />
            </>
          ) : null}
          <PickerRow
            label="加密模式"
            value={authLabel(mMode)}
            selected={mMode}
            options={AUTH_MODES.map(a => ({ value: a.value, label: a.label }))}
            disabled={!mEnable}
            onSelect={setMMode}
          />
          <ButtonRow title={busy === "create" ? "下发中…" : "保存"} busy={busy === "create"} onTap={() => createMlo()} />
        </Group>
        )}
      </SettingsPage>

      {bindOpen ? (
        <BindDialog
          list={wifi}
          sel2={sel2}
          sel5={sel5}
          onPick={(type, index) => {
            if (type === "0") setSel2(index)
            else setSel5(index)
          }}
          onClose={() => setBindOpen(false)}
          onDone={() => setBindOpen(false)}
        />
      ) : null}
    </ZStack>
  )
}
