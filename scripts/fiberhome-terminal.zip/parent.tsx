// ---------- 家长控制（总开关 + 规则列表 + 添加/编辑规则） ----------
// 读：GET_PARENT_CONTROL_INFO      → { Enable, RuleTemplate[{Id,RuleName,UrlFilterPolicy,Stainfo,Duration,UrlFilter}] }
//     GET_PARENT_CONTROL_STA_LIST  → Stainfo[{Active,Devname,Id,Mac,RuleName}]（Active=1 在线）
// 写：SET_PARENT_CONTROL_ENABLE    { Enable:"0"|"1" }   ✅ 实测
//     SET_PARENT_CONTROL_RULE_INFO ✅ 实测（2026-10-30 对照官方 App 抓包后打通）：子项必带 Action:"1" + TraceId:""，
//                                                        新建时规则 Id 传 "0"；丢了 Action/TraceId 就会被静默清成 []
//     DEL_PARENT_CONTROL_RULE      { Id:"1", RuleName }    ✅ Id 必须是字符串，传数字报 "Json is invalid"
// 修改规则：同 Id 重写时设备是「追加」子项而不是覆盖 → 这里先删旧再按 Id:"0" 新建
//
// ⚠️ 导航：规则编辑 / 选择设备 / 网址过滤 都是**独立的路由页**（toolbox 的 NavigationStack 里 push），
//    这样右滑返回 = 退回上一级，而不是一路退回工具箱。三页共用下面的模块级 store（数据 + 草稿）。

import { HStack, Text, useState, useEffect, ZStack } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"
import { Overlay, WeekdayDialog } from "./lib/pickers"
import {
  ACCENT,
  ACCENT_WARM,
  ButtonRow,
  Group,
  InputRow,
  NoticeRow,
  PickerRow,
  Row,
  SettingsPage,
  SwitchRow,
} from "./lib/settings"

const GET_INFO = "GET_PARENT_CONTROL_INFO"
const GET_STA = "GET_PARENT_CONTROL_STA_LIST"
const SET_ENABLE = "SET_PARENT_CONTROL_ENABLE"
const SET_RULE = "SET_PARENT_CONTROL_RULE_INFO"
const DEL_RULE = "DEL_PARENT_CONTROL_RULE"
const MAX_RULES = 8

// 官方真实结构（2026-10-30 用户用官方 App 建了一条「睡觉」规则后抓到的原样返回）：
// RuleTemplate[{ Id:"1", RuleName:"睡觉", DurationRight:"1", UrlFilterRight:"1", UrlFilterPolicy:"0",
//   Stainfo:[{Devname,Id,Mac}], Duration:[{DaysOfWeek:"Mon",StartTime:"00:57",EndTime:"01:57",Id}],
//   UrlFilter:[{Id,Url}] }] —— DaysOfWeek 用 Mon/Tue… 英文缩写；每条子项都带 Id。

const WEEK: { d: string; label: string }[] = [
  { d: "Mon", label: "周一" },
  { d: "Tue", label: "周二" },
  { d: "Wed", label: "周三" },
  { d: "Thu", label: "周四" },
  { d: "Fri", label: "周五" },
  { d: "Sat", label: "周六" },
  { d: "Sun", label: "周日" },
]

/** 半点步进的时间选项 00:00 – 23:30 */
const TIMES: { value: string; label: string }[] = (() => {
  const out: { value: string; label: string }[] = []
  for (let h = 0; h < 24; h++) {
    for (const m of ["00", "30"]) {
      const v = `${String(h).padStart(2, "0")}:${m}`
      out.push({ value: v, label: v })
    }
  }
  return out
})()

const URL_MODES = [
  { value: "0", label: "无设置" },
  { value: "1", label: "黑名单" },
  { value: "2", label: "白名单" },
]

/* ---------------- 跨页共享的模块级 store ---------------- */

type Draft = {
  editId: string
  name: string
  selMacs: string[]
  timeOn: boolean
  days: string[]
  start: string
  end: string
  urlMode: string
  urls: string[]
  urlInput: string
}

const emptyDraft = (): Draft => ({
  editId: "",
  name: "",
  selMacs: [],
  timeOn: false,
  days: [],
  start: "08:00",
  end: "22:00",
  urlMode: "0",
  urls: [],
  urlInput: "",
})

type Store = {
  enable: string | null
  rules: any[]
  stas: any[]
  error: string
  toast: Hint | null
  draft: Draft
}

let store: Store = { enable: null, rules: [], stas: [], error: "", toast: null, draft: emptyDraft() }
const subs = new Set<() => void>()

function update(patch: Partial<Store>) {
  store = { ...store, ...patch }
  subs.forEach(f => f())
}

function updateDraft(patch: Partial<Draft>) {
  update({ draft: { ...store.draft, ...patch } })
}

/** 订阅 store：任何一页改了数据，所有挂着的页都会重渲染 */
function useStore(): Store {
  const [, force] = useState(0)
  useEffect(() => {
    const f = () => force(v => v + 1)
    subs.add(f)
    return () => {
      subs.delete(f)
    }
  }, [])
  return store
}

function devName(m: string): string {
  const s = store.stas.find(x => String(x?.Mac ?? "") === m)
  return String(s?.Devname ?? "")
}

function draftFromRule(r: any): Draft {
  const d = Array.isArray(r?.Stainfo) ? r.Stainfo : []
  const du = Array.isArray(r?.Duration) ? r.Duration : []
  const uf = Array.isArray(r?.UrlFilter) ? r.UrlFilter : []
  return {
    editId: String(r?.Id ?? ""),
    name: String(r?.RuleName ?? ""),
    selMacs: d.map((x: any) => String(x?.Mac ?? "")).filter(Boolean),
    timeOn: du.length > 0,
    days: du.length > 0 ? String(du[0]?.DaysOfWeek ?? "").split(/[,\s]+/).filter(Boolean) : [],
    start: String(du[0]?.StartTime ?? "08:00") || "08:00",
    end: String(du[0]?.EndTime ?? "22:00") || "22:00",
    urlMode: String(r?.UrlFilterPolicy ?? "0") || "0",
    urls: uf.map((x: any) => String(x?.Url ?? "")).filter(Boolean),
    urlInput: "",
  }
}

async function fetchAll(mac: string, token: string) {
  if (!mac || !token) return
  const [i, s] = await Promise.all([
    invokeService<any>(mac, token, GET_INFO, {}, 10).catch(e => ({ ok: false, error: String(e) } as any)),
    invokeService<any>(mac, token, GET_STA, {}, 10).catch(e => ({ ok: false, error: String(e) } as any)),
  ])
  if (i.ok) {
    update({
      error: "",
      enable: String(i.data?.Enable ?? "0"),
      rules: Array.isArray(i.data?.RuleTemplate) ? i.data.RuleTemplate : [],
    })
  } else {
    update({ error: i.error ?? "读取家长控制失败" })
  }
  if (s.ok) {
    const list = s.data?.Stainfo ?? s.data?.StaInfo
    update({ stas: Array.isArray(list) ? list : [] })
  }
}

async function setEnableRemote(mac: string, token: string, next: boolean): Promise<void> {
  const prev = store.enable
  update({ enable: next ? "1" : "0", error: "" })
  const r = await invokeService<any>(mac, token, SET_ENABLE, { Enable: next ? "1" : "0" }, 10).catch(() => null)
  if (!r || !r.ok) {
    update({ enable: prev, toast: { text: r?.error ?? "设置失败", ok: false } })
    return
  }
  await new Promise<void>(res => setTimeout(res, 400))
  const c = await invokeService<any>(mac, token, GET_INFO, {}, 10).catch(() => null)
  if (c?.ok) {
    const v = String(c.data?.Enable ?? "")
    update({
      enable: v || (next ? "1" : "0"),
      rules: Array.isArray(c.data?.RuleTemplate) ? c.data.RuleTemplate : [],
    })
    if (v && v !== (next ? "1" : "0")) {
      update({ enable: prev, toast: { text: `设备回读仍为${v === "1" ? "开" : "关"}`, ok: false } })
      return
    }
  }
  update({ toast: { text: `家长控制已${next ? "开启" : "关闭"}` } })
}

/** 保存草稿规则；返回 true 表示可以退回列表 */
async function saveRule(mac: string, token: string): Promise<boolean> {
  const d = store.draft
  const nm = d.name.trim()
  if (!mac) return false
  if (!nm) {
    update({ toast: { text: "先给规则起个名字", ok: false } })
    return false
  }
  if (!d.editId && store.rules.length >= MAX_RULES) {
    update({ toast: { text: `最多 ${MAX_RULES} 条规则`, ok: false } })
    return false
  }

  // 修改已有规则：设备对同 Id 的子项是「追加」不是覆盖，所以先删再建
  if (d.editId) {
    const old = store.rules.find(r => String(r?.Id ?? "") === d.editId)
    const dr = await invokeService<any>(mac, token, DEL_RULE, { Id: d.editId, RuleName: String(old?.RuleName ?? "") }, 15).catch(
      () => null
    )
    if (!dr || !dr.ok) {
      update({ toast: { text: dr?.error ?? "先删旧规则失败", ok: false } })
      return false
    }
  }

  // 官方报文（2026-10-30 实抓）：子项必须带 Action/TraceId，新建时规则 Id 传 "0"
  const body: Record<string, any> = {
    Id: "0",
    RuleName: nm,
    Stainfo: d.selMacs.map(m => ({ Mac: m, Devname: devName(m), Action: "1", TraceId: "", Id: "" })),
    Duration: d.timeOn
      ? [{ DaysOfWeek: d.days.join(","), StartTime: d.start, EndTime: d.end, Action: "1", TraceId: "", Id: "" }]
      : [],
    UrlFilter: d.urls.map(u => ({ Url: u, Action: "1", TraceId: "", Id: "" })),
    UrlFilterPolicy: d.urlMode,
    DurationRight: d.timeOn ? "1" : "0",
    UrlFilterRight: d.urls.length ? "1" : "0",
  }
  const r = await invokeService<any>(mac, token, SET_RULE, body, 15).catch(() => null)
  if (!r || !r.ok) {
    update({ toast: { text: r?.error ?? "保存失败", ok: false } })
    return false
  }
  const st = String((r.data as any)?.Status ?? "0")
  if (st !== "0") {
    const fail = String((r.data as any)?.FailReason ?? "")
    update({ toast: { text: fail ? `设备拒绝：${fail}` : "设备拒绝了这次保存", ok: false } })
    return false
  }

  // 回读：看设备到底留下了哪些字段
  await new Promise<void>(res => setTimeout(res, 500))
  const g = await invokeService<any>(mac, token, GET_INFO, {}, 10).catch(() => null)
  if (g?.ok) update({ rules: Array.isArray(g.data?.RuleTemplate) ? g.data.RuleTemplate : [] })
  const saved: any[] = g?.ok ? (g.data?.RuleTemplate ?? []) : []
  const found = saved.find((x: any) => String(x?.RuleName ?? "") === nm)
  const lost: string[] = []
  if (found) {
    if (body.Stainfo.length && !(Array.isArray(found.Stainfo) && found.Stainfo.length)) lost.push("应用设备")
    if (body.Duration.length && !(Array.isArray(found.Duration) && found.Duration.length)) lost.push("定时上网")
    if (body.UrlFilter.length && !(Array.isArray(found.UrlFilter) && found.UrlFilter.length)) lost.push("网址过滤")
  }
  if (lost.length) {
    update({ toast: { text: `已保存，但设备没接受：${lost.join(" / ")}` } })
  } else {
    update({ toast: { text: d.editId ? "规则已更新" : "规则已添加" } })
  }
  return true
}

async function deleteRule(mac: string, token: string, id: string, name: string): Promise<boolean> {
  if (!mac) return false
  const res = await invokeService<any>(mac, token, DEL_RULE, { Id: id, RuleName: name }, 15).catch(() => null)
  if (!res || !res.ok) {
    update({ toast: { text: res?.error ?? "删除失败", ok: false } })
    return false
  }
  update({ toast: { text: "规则已删除" } })
  await fetchAll(mac, token)
  return true
}

function timeText(r: any): string {
  const du = Array.isArray(r?.Duration) ? r.Duration : []
  if (!du.length) return ""
  const d = du[0] ?? {}
  const wd = String(d?.DaysOfWeek ?? "")
    .split(/[,\s]+/)
    .filter(Boolean)
    .map(x => WEEK.find(w => w.d === x)?.label ?? x)
    .join(" ")
  const span = `${String(d?.StartTime ?? "")}–${String(d?.EndTime ?? "")}`
  return [wd || "每天", span].filter(Boolean).join(" ")
}

function daysText(days: string[]): string {
  if (days.length === 0 || days.length === 7) return "每天"
  return WEEK.filter(w => days.includes(w.d))
    .map(w => w.label)
    .join(" ")
}

/* ---------------- 一级页：家长控制（总开关 + 规则列表） ---------------- */

export default function ParentPage(props: {
  session: Session
  devices: DeviceInfo[]
  onBack: () => void
  onPush: (key: string) => void
}) {
  const { session, devices, onPush } = props
  const mac = devices[0]?.mac ?? ""
  const token = session.token
  const s = useStore()
  const rules = s.rules
  const on = s.enable === "1"
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    fetchAll(mac, token)
  }, [mac, token])

  async function toggleEnable(next: boolean) {
    if (!mac || busy || s.enable === null) return
    setBusy(true)
    await setEnableRemote(mac, token, next)
    setBusy(false)
  }

  const rows: any[] = rules.map((r, i) => {
    const d = Array.isArray(r?.Stainfo) ? r.Stainfo.length : 0
    const uf = Array.isArray(r?.UrlFilter) ? r.UrlFilter.length : 0
    const tt = timeText(r)
    const tags = [d ? `${d} 台设备` : "", tt, uf ? `${uf} 条网址` : ""].filter(Boolean)
    return (
      <Row
        key={`r${i}`}
        icon="person.2.badge.gearshape"
        iconColor={ACCENT}
        label={String(r?.RuleName ?? "未命名规则")}
        note={tags.length ? tags.join(" · ") : "只有名称"}
        chevron
        onTap={() => {
          update({ draft: draftFromRule(r) })
          onPush("parentEdit")
        }}
      />
    )
  })

  const groups: any[] = []

  groups.push(
    <Group key="sw" footer="开启后，可创建定时上网与网址过滤规则。">
      <SwitchRow label={s.enable === null ? "家长控制（读取中）" : "家长控制"} value={on} onChanged={toggleEnable} />
    </Group>
  )

  groups.push(
    <Group key="rules" header={`家长控制规则（${rules.length}/${MAX_RULES}）`}>
      {rules.length ? (
        rows
      ) : (
        <Row label="还没有规则" note={on ? "点下面的「添加家长控制规则」" : "开启家长控制后可添加"} icon="info.circle" />
      )}
    </Group>
  )

  // 只有家长控制开启后，才出现「添加」
  if (on) {
    groups.push(
      <Group key="add">
        <ButtonRow
          title={rules.length >= MAX_RULES ? `已达上限（${MAX_RULES} 条）` : "添加家长控制规则"}
          disabled={rules.length >= MAX_RULES}
          onTap={() => {
            update({ draft: emptyDraft() })
            onPush("parentEdit")
          }}
        />
      </Group>
    )
  }

  return (
    <SettingsPage
      title="家长控制"
      refreshable={() => fetchAll(mac, token)}
      toast={hintToast(s.toast, () => update({ toast: null }))}
    >
      {s.error ? (
        <Group>
          <NoticeRow kind="error" text={s.error} />
        </Group>
      ) : null}
      {groups}
    </SettingsPage>
  )
}

/* ---------------- 二级页：规则编辑 ---------------- */

export function ParentEditPage(props: {
  session: Session
  devices: DeviceInfo[]
  onPush: (key: string) => void
  onBack: () => void
}) {
  const { session, devices, onPush, onBack } = props
  const mac = devices[0]?.mac ?? ""
  const token = session.token
  const s = useStore()
  const d = s.draft
  const [saving, setSaving] = useState(false)
  const [dayPicker, setDayPicker] = useState(false)

  async function onSave() {
    if (saving) return
    setSaving(true)
    const ok = await saveRule(mac, token)
    setSaving(false)
    if (ok) onBack()
  }

  const groups: any[] = []

  groups.push(
    <Group key="info" header="规则信息">
      <InputRow label="规则名称" value={d.name} prompt="给这条规则起个名字" onChanged={v => updateDraft({ name: v })} />
      <Row
        label="应用设备"
        value={d.selMacs.length ? `${d.selMacs.length} 台` : "无设置"}
        valueColor={d.selMacs.length ? ACCENT : "tertiaryLabel"}
        chevron
        onTap={() => onPush("parentDevices")}
      />
    </Group>
  )

  const contentRows: any[] = []
  contentRows.push(<SwitchRow key="ton" label="定时上网" value={d.timeOn} onChanged={v => updateDraft({ timeOn: v })} />)
  if (d.timeOn) {
    contentRows.push(<Row key="days" label="生效日" value={daysText(d.days)} chevron onTap={() => setDayPicker(true)} />)
    contentRows.push(
      <PickerRow key="st" label="开始时间" value={d.start} options={TIMES} onSelect={v => updateDraft({ start: v })} />
    )
    contentRows.push(
      <PickerRow key="et" label="结束时间" value={d.end} options={TIMES} onSelect={v => updateDraft({ end: v })} />
    )
  }
  contentRows.push(
    <Row
      key="url"
      label="网址过滤"
      value={d.urls.length ? `${d.urls.length} 条` : "无设置"}
      valueColor={d.urls.length ? ACCENT : "tertiaryLabel"}
      chevron
      onTap={() => onPush("parentUrl")}
    />
  )
  groups.push(
    <Group key="content" header="规则内容">
      {contentRows}
    </Group>
  )

  groups.push(
    <Group key="save">
      <ButtonRow title="保存" busy={saving} onTap={onSave} />
    </Group>
  )

  if (d.editId) {
    const found = s.rules.find(r => String(r?.Id ?? "") === d.editId)
    if (found) {
      groups.push(
        <Group key="del">
          <ButtonRow
            title="删除这条规则"
            destructive
            onTap={async () => {
              const ok = await deleteRule(mac, token, String((found as any)?.Id ?? ""), String((found as any)?.RuleName ?? ""))
              if (ok) onBack()
            }}
          />
        </Group>
      )
    }
  }

  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      <SettingsPage title="家长控制规则" toast={hintToast(s.toast, () => update({ toast: null }))}>
        {groups}
      </SettingsPage>
      {dayPicker ? (
        <Overlay onDismiss={() => setDayPicker(false)}>
          <WeekdayDialog
            week={WEEK}
            days={d.days}
            accent={ACCENT}
            onToggle={x =>
              updateDraft({ days: d.days.includes(x) ? d.days.filter(y => y !== x) : [...d.days, x] })
            }
            onCancel={() => setDayPicker(false)}
            onDone={() => setDayPicker(false)}
          />
        </Overlay>
      ) : null}
    </ZStack>
  )
}

/* ---------------- 二级页：选择应用设备 ---------------- */

export function ParentDevicesPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { onBack } = props
  const s = useStore()
  const d = s.draft
  const online = s.stas.filter(x => String(x?.Active ?? "") === "1")
  const offline = s.stas.filter(x => String(x?.Active ?? "") !== "1")

  function rowsOf(list: any[], prefix: string) {
    return list.map((x, i) => {
      const m = String(x?.Mac ?? "")
      const picked = d.selMacs.includes(m)
      return (
        <Row
          key={`${prefix}${i}`}
          label={String(x?.Devname ?? m)}
          note={`MAC：${m}`}
          selected={picked}
          onTap={() =>
            updateDraft({ selMacs: picked ? d.selMacs.filter(y => y !== m) : [...d.selMacs, m] })
          }
        />
      )
    })
  }

  return (
    <SettingsPage title="选择应用设备">
      <Group header={`在线设备（${online.length}）`}>
        {online.length ? rowsOf(online, "on") : <Row label="没有在线设备" icon="minus.circle" />}
      </Group>
      <Group header={`离线设备（${offline.length}）`}>
        {offline.length ? rowsOf(offline, "off") : <Row label="没有离线设备" icon="minus.circle" />}
      </Group>
      <Group>
        <ButtonRow title={`完成（已选 ${d.selMacs.length} 台）`} onTap={onBack} />
      </Group>
    </SettingsPage>
  )
}

/* ---------------- 二级页：网址过滤 ---------------- */

export function ParentUrlPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { onBack } = props
  const s = useStore()
  const d = s.draft

  const list: any[] = d.urls.map((u, i) => (
    <Row
      key={`u${i}`}
      icon="globe"
      iconColor={ACCENT}
      label={u}
      mono
      trailing={
        <HStack
          spacing={0}
          padding={{ vertical: 2, horizontal: 4 }}
          contentShape="rect"
          onTapGesture={() => updateDraft({ urls: d.urls.filter((_, k) => k !== i) })}
        >
          <Text font="footnote" foregroundStyle={ACCENT_WARM}>
            删除
          </Text>
        </HStack>
      }
    />
  ))

  return (
    <SettingsPage title="网址过滤">
      <Group footer="黑名单：只挡住这些网址；白名单：只放行这些网址。">
        <PickerRow
          label="过滤方式"
          value={URL_MODES.find(m => m.value === d.urlMode)?.label ?? "无设置"}
          selected={d.urlMode}
          options={URL_MODES}
          onSelect={v => updateDraft({ urlMode: v })}
        />
      </Group>
      <Group header={`网址（${d.urls.length}）`}>
        {d.urls.length ? list : <Row label="还没有网址" icon="info.circle" />}
        <InputRow
          label="添加网址"
          value={d.urlInput}
          prompt="例如 www.example.com"
          autocapitalization="never"
          autocorrectionDisabled
          onChanged={v => updateDraft({ urlInput: v })}
        />
        <ButtonRow
          title="加入列表"
          disabled={!d.urlInput.trim()}
          onTap={() => {
            const v = d.urlInput.trim()
            if (!v) return
            if (!d.urls.includes(v)) updateDraft({ urls: [...d.urls, v] })
            updateDraft({ urlInput: "" })
          }}
        />
      </Group>
      <Group>
        <ButtonRow title="返回规则" onTap={onBack} />
      </Group>
    </SettingsPage>
  )
}
