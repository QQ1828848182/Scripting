// ---------- 家长控制（总开关 + 规则列表 + 添加/编辑规则） ----------
// 读：GET_PARENT_CONTROL_INFO      → { Enable, RuleTemplate[{Id,RuleName,UrlFilterPolicy,Stainfo,Duration,UrlFilter}] }
//     GET_PARENT_CONTROL_STA_LIST  → Stainfo[{Active,Devname,Id,Mac,RuleName}]（Active=1 在线）
// 写：SET_PARENT_CONTROL_ENABLE    { Enable:"0"|"1" }   ✅ 实测
//     SET_PARENT_CONTROL_RULE_INFO ✅ 实测（2026-10-30 对照官方 App 抓包后打通）：子项必带 Action:"1" + TraceId:""，
//                                                        新建时规则 Id 传 "0"；丢了 Action/TraceId 就会被静默清成 []
//     DEL_PARENT_CONTROL_RULE      { Id:"1", RuleName }    ✅ Id 必须是字符串，传数字报 "Json is invalid"
// 修改规则：同 Id 重写时设备是「追加」子项而不是覆盖 → 这里先删旧再按 Id:"0" 新建

import { HStack, Spacer, Text, useState, useEffect, ZStack } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"
import { Overlay, WeekdayDialog } from "./lib/pickers"
import {
  ACCENT,
  ACCENT_WARM,
  ButtonRow,
  Group,
  InputRow,
  NoticeRow,
  OK,
  PickerRow,
  Row,
  SettingsPage,
  SwitchRow,
} from "./lib/settings"

const GET_INFO = "GET_PARENT_CONTROL_INFO"
const GET_STA = "GET_PARENT_CONTROL_STA_LIST"
const SET_ENABLE = "SET_PARENT_CONTROL_ENABLE"
const SET_RULE = "SET_PARENT_CONTROL_RULE_INFO"
const DEL_RULE = "DEL_PARENT_CONTROL_RULE"
const MAX_RULES = 8

// 官方真实结构（2026-10-30 用户用官方 App 建了一条「睡觉」规则后抓到的原样返回）：
// RuleTemplate[{ Id:"1", RuleName:"睡觉", DurationRight:"1", UrlFilterRight:"1", UrlFilterPolicy:"0",
//   Stainfo:[{Devname,Id,Mac}], Duration:[{DaysOfWeek:"Mon",StartTime:"00:57",EndTime:"01:57",Id}],
//   UrlFilter:[{Id,Url}] }] —— DaysOfWeek 用 Mon/Tue… 英文缩写；每条子项都带 Id。
// 但本机固件在 SET_PARENT_CONTROL_RULE_INFO 里只落库 RuleName / UrlFilterPolicy /
// DurationRight / UrlFilterRight，三个数组（不论对象数组还是 JSON 字符串）一律存成 []。
// ⚠️ 上面这条旧结论已被推翻：数组子项只要带上 Action/TraceId 就能存住（详见文件头注释）。

const WEEK: { d: string; label: string }[] = [
  { d: "Mon", label: "周一" },
  { d: "Tue", label: "周二" },
  { d: "Wed", label: "周三" },
  { d: "Thu", label: "周四" },
  { d: "Fri", label: "周五" },
  { d: "Sat", label: "周六" },
  { d: "Sun", label: "周日" },
]

/** 半点步进的时间选项 00:00 – 23:30 */
const TIMES: { value: string; label: string }[] = (() => {
  const out: { value: string; label: string }[] = []
  for (let h = 0; h < 24; h++) {
    for (const m of ["00", "30"]) {
      const v = `${String(h).padStart(2, "0")}:${m}`
      out.push({ value: v, label: v })
    }
  }
  return out
})()

const URL_MODES = [
  { value: "0", label: "无设置" },
  { value: "1", label: "黑名单" },
  { value: "2", label: "白名单" },
]

type View = "list" | "edit" | "devices" | "url"

export default function ParentPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices[0]
  const mac = device?.mac ?? ""
  const token = session.token

  const [enable, setEnable] = useState<string | null>(null)
  const [rules, setRules] = useState<any[]>([])
  const [stas, setStas] = useState<any[]>([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState("")
  const [toastHint, setToastHint] = useState<Hint | null>(null)

  const [view, setView] = useState<View>("list")
  const [editId, setEditId] = useState<string>("")
  const [name, setName] = useState("")
  const [selMacs, setSelMacs] = useState<string[]>([])
  const [timeOn, setTimeOn] = useState(false)
  const [days, setDays] = useState<string[]>([])
  const [start, setStart] = useState("08:00")
  const [end, setEnd] = useState("22:00")
  const [urlMode, setUrlMode] = useState("0")
  const [urls, setUrls] = useState<string[]>([])
  const [urlInput, setUrlInput] = useState("")
  const [saving, setSaving] = useState(false)
  const [dayPicker, setDayPicker] = useState(false)
  const [raw, setRaw] = useState("")
  const [showRaw, setShowRaw] = useState(false)

  const on = enable === "1"

  async function load() {
    if (!mac || !token) return
    setError("")
    const [i, s] = await Promise.all([
      invokeService<any>(mac, token, GET_INFO, {}, 10).catch(e => ({ ok: false, error: String(e) } as any)),
      invokeService<any>(mac, token, GET_STA, {}, 10).catch(e => ({ ok: false, error: String(e) } as any)),
    ])
    if (i.ok) {
      setEnable(String(i.data?.Enable ?? "0"))
      setRules(Array.isArray(i.data?.RuleTemplate) ? i.data.RuleTemplate : [])
      setRaw(`GET_PARENT_CONTROL_INFO\n${JSON.stringify(i.data, null, 1)}${s.ok ? `\n\nGET_PARENT_CONTROL_STA_LIST\n${JSON.stringify(s.data, null, 1)}` : ""}`)
    } else {
      setError(i.error ?? "读取家长控制失败")
    }
    if (s.ok) {
      const list = s.data?.Stainfo ?? s.data?.StaInfo
      setStas(Array.isArray(list) ? list : [])
    }
  }

  useEffect(() => {
    load()
  }, [mac, token])

  /* ---------------- 开关 ---------------- */

  async function toggleEnable(next: boolean) {
    if (!mac || busy || enable === null) return
    setBusy(true)
    setError("")
    const prev = enable
    setEnable(next ? "1" : "0")
    const r = await invokeService<any>(mac, token, SET_ENABLE, { Enable: next ? "1" : "0" }, 10).catch(() => null)
    if (!r || !r.ok) {
      setEnable(prev)
      setBusy(false)
      setToastHint({ text: r?.error ?? "设置失败", ok: false })
      return
    }
    await new Promise<void>(res => setTimeout(res, 400))
    const c = await invokeService<any>(mac, token, GET_INFO, {}, 10).catch(() => null)
    setBusy(false)
    if (c?.ok) {
      const v = String(c.data?.Enable ?? "")
      setEnable(v || (next ? "1" : "0"))
      setRules(Array.isArray(c.data?.RuleTemplate) ? c.data.RuleTemplate : [])
      if (v && v !== (next ? "1" : "0")) {
        setEnable(prev)
        setToastHint({ text: `设备回读仍为${v === "1" ? "开" : "关"}`, ok: false })
        return
      }
    }
    setToastHint({ text: `家长控制已${next ? "开启" : "关闭"}` })
  }

  /* ---------------- 规则编辑 ---------------- */

  function resetForm() {
    setEditId("")
    setName("")
    setSelMacs([])
    setTimeOn(false)
    setDays([])
    setStart("08:00")
    setEnd("22:00")
    setUrlMode("0")
    setUrls([])
    setUrlInput("")
  }

  function openNew() {
    resetForm()
    setView("edit")
  }

  function openEdit(r: any) {
    const d = Array.isArray(r?.Stainfo) ? r.Stainfo : []
    const du = Array.isArray(r?.Duration) ? r.Duration : []
    const uf = Array.isArray(r?.UrlFilter) ? r.UrlFilter : []
    setEditId(String(r?.Id ?? ""))
    setName(String(r?.RuleName ?? ""))
    setSelMacs(d.map((x: any) => String(x?.Mac ?? "")).filter(Boolean))
    setTimeOn(du.length > 0)
    setDays(du.length > 0 ? String(du[0]?.DaysOfWeek ?? "").split(/[,\s]+/).filter(Boolean) : [])
    setStart(String(du[0]?.StartTime ?? "08:00") || "08:00")
    setEnd(String(du[0]?.EndTime ?? "22:00") || "22:00")
    setUrlMode(String(r?.UrlFilterPolicy ?? "0") || "0")
    setUrls(uf.map((x: any) => String(x?.Url ?? "")).filter(Boolean))
    setUrlInput("")
    setView("edit")
  }

  function devName(m: string): string {
    const s = stas.find(x => String(x?.Mac ?? "") === m)
    return String(s?.Devname ?? "")
  }

  const daysText = () => {
    if (days.length === 0 || days.length === 7) return "每天"
    return WEEK.filter(w => days.includes(w.d))
      .map(w => w.label)
      .join(" ")
  }

  async function saveRule() {
    if (!mac || saving) return
    const nm = name.trim()
    if (!nm) {
      setToastHint({ text: "先给规则起个名字", ok: false })
      return
    }
    if (!editId && rules.length >= MAX_RULES) {
      setToastHint({ text: `最多 ${MAX_RULES} 条规则`, ok: false })
      return
    }
    setSaving(true)

    // 修改已有规则：设备对同 Id 的子项是「追加」不是覆盖，所以先删再建
    if (editId) {
      const old = rules.find(r => String(r?.Id ?? "") === editId)
      const dr = await invokeService<any>(mac, token, DEL_RULE, { Id: editId, RuleName: String(old?.RuleName ?? "") }, 15).catch(
        () => null
      )
      if (!dr || !dr.ok) {
        setSaving(false)
        setToastHint({ text: dr?.error ?? "先删旧规则失败", ok: false })
        return
      }
    }

    // 官方报文（2026-10-30 实抓）：子项必须带 Action/TraceId，新建时规则 Id 传 "0"
    const body: Record<string, any> = {
      Id: "0",
      RuleName: nm,
      Stainfo: selMacs.map(m => ({ Mac: m, Devname: devName(m), Action: "1", TraceId: "", Id: "" })),
      Duration: timeOn
        ? [{ DaysOfWeek: days.join(","), StartTime: start, EndTime: end, Action: "1", TraceId: "", Id: "" }]
        : [],
      UrlFilter: urls.map(u => ({ Url: u, Action: "1", TraceId: "", Id: "" })),
      UrlFilterPolicy: urlMode,
      DurationRight: timeOn ? "1" : "0",
      UrlFilterRight: urls.length ? "1" : "0",
    }
    const r = await invokeService<any>(mac, token, SET_RULE, body, 15).catch(() => null)
    if (!r || !r.ok) {
      setSaving(false)
      setToastHint({ text: r?.error ?? "保存失败", ok: false })
      return
    }
    const st = String((r.data as any)?.Status ?? "0")
    if (st !== "0") {
      setSaving(false)
      const fail = String((r.data as any)?.FailReason ?? "")
      setToastHint({ text: fail ? `设备拒绝：${fail}` : "设备拒绝了这次保存", ok: false })
      return
    }

    // 回读：看设备到底留下了哪些字段
    await new Promise<void>(res => setTimeout(res, 500))
    const g = await invokeService<any>(mac, token, GET_INFO, {}, 10).catch(() => null)
    setSaving(false)
    if (g?.ok) setRules(Array.isArray(g.data?.RuleTemplate) ? g.data.RuleTemplate : [])
    const saved: any[] = g?.ok ? (g.data?.RuleTemplate ?? []) : []
    const found = saved.find(x => String(x?.RuleName ?? "") === nm)
    const lost: string[] = []
    if (found) {
      if (body.Stainfo.length && !(Array.isArray(found.Stainfo) && found.Stainfo.length)) lost.push("应用设备")
      if (body.Duration.length && !(Array.isArray(found.Duration) && found.Duration.length)) lost.push("定时上网")
      if (body.UrlFilter.length && !(Array.isArray(found.UrlFilter) && found.UrlFilter.length)) lost.push("网址过滤")
    }
    if (lost.length) {
      setToastHint({ text: `已保存，但设备没接受：${lost.join(" / ")}` })
    } else {
      setToastHint({ text: editId ? "规则已更新" : "规则已添加" })
    }
    setView("list")
  }

  async function deleteRule(r: any) {
    if (!mac || busy) return
    const id = String(r?.Id ?? "")
    if (!id) {
      setToastHint({ text: "这条规则没有 Id，删不掉", ok: false })
      return
    }
    setBusy(true)
    const nm = String(r?.RuleName ?? "")
    const res = await invokeService<any>(mac, token, DEL_RULE, { Id: id, RuleName: nm }, 15).catch(() => null)
    setBusy(false)
    if (!res || !res.ok) {
      setToastHint({ text: res?.error ?? "删除失败", ok: false })
      return
    }
    setToastHint({ text: "规则已删除" })
    setView("list")
    await load()
  }

  /* ---------------- 列表页 ---------------- */

  function timeText(r: any): string {
    const du = Array.isArray(r?.Duration) ? r.Duration : []
    if (!du.length) return ""
    const d = du[0] ?? {}
    const wd = String(d?.DaysOfWeek ?? "")
      .split(/[,\s]+/)
      .filter(Boolean)
      .map(x => WEEK.find(w => w.d === x)?.label ?? x)
      .join(" ")
    const span = `${String(d?.StartTime ?? "")}–${String(d?.EndTime ?? "")}`
    return [wd || "每天", span].filter(Boolean).join(" ")
  }

  function listPage() {
    const rows: any[] = rules.map((r, i) => {
      const d = Array.isArray(r?.Stainfo) ? r.Stainfo.length : 0
      const uf = Array.isArray(r?.UrlFilter) ? r.UrlFilter.length : 0
      const tt = timeText(r)
      const tags = [d ? `${d} 台设备` : "", tt, uf ? `${uf} 条网址` : ""].filter(Boolean)
      return (
        <Row
          key={`r${i}`}
          icon="person.2.badge.gearshape"
          iconColor={ACCENT}
          label={String(r?.RuleName ?? "未命名规则")}
          note={tags.length ? tags.join(" · ") : "只有名称"}
          chevron
          onTap={() => openEdit(r)}
        />
      )
    })

    const groups: any[] = []

    groups.push(
      <Group key="sw" footer="开启后，可创建定时上网与网址过滤规则。">
        <SwitchRow
          label={enable === null ? "家长控制（读取中）" : "家长控制"}
          value={on}
          onChanged={toggleEnable}
        />
      </Group>
    )

    groups.push(
      <Group key="rules" header={`家长控制规则（${rules.length}/${MAX_RULES}）`}>
        {rules.length ? rows : <Row label="还没有规则" note={on ? "点下面的「添加家长控制规则」" : "开启家长控制后可添加"} icon="info.circle" />}
      </Group>
    )

    // 只有家长控制开启后，才出现「添加」
    if (on) {
      groups.push(
        <Group key="add">
          <ButtonRow
            title={rules.length >= MAX_RULES ? `已达上限（${MAX_RULES} 条）` : "添加家长控制规则"}
            disabled={rules.length >= MAX_RULES}
            onTap={openNew}
          />
        </Group>
      )
    }

    // 底部：原始返回
    groups.push(
      <Group key="raw" header={showRaw ? "原始返回" : undefined}>
        <Row
          label={showRaw ? "收起原始返回" : "查看原始返回"}
          chevron={!showRaw}
          onTap={() => setShowRaw(!showRaw)}
        />
        {showRaw ? (
          <Row
            content={
              <HStack spacing={0} frame={{ maxWidth: "infinity", alignment: "leading" }}>
                <Text font="caption2" monospaced foregroundStyle="secondaryLabel" frame={{ maxWidth: "infinity", alignment: "leading" }}>
                  {raw || "（空）"}
                </Text>
              </HStack>
            }
          />
        ) : null}
      </Group>
    )

    return (
      <SettingsPage title="家长控制" refreshable={load} toast={hintToast(toastHint, () => setToastHint(null))}>
        {error ? (
          <Group>
            <NoticeRow kind="error" text={error} />
          </Group>
        ) : null}
        {groups}
      </SettingsPage>
    )
  }

  /* ---------------- 规则编辑页 ---------------- */

  function editPage() {
    const groups: any[] = []

    groups.push(
      <Group key="info" header="规则信息">
        <InputRow label="规则名称" value={name} prompt="给这条规则起个名字" onChanged={setName} />
        <Row
          label="应用设备"
          value={selMacs.length ? `${selMacs.length} 台` : "无设置"}
          valueColor={selMacs.length ? ACCENT : "tertiaryLabel"}
          chevron
          onTap={() => setView("devices")}
        />
      </Group>
    )

    const contentRows: any[] = []
    contentRows.push(<SwitchRow key="ton" label="定时上网" value={timeOn} onChanged={setTimeOn} />)
    if (timeOn) {
      contentRows.push(<Row key="days" label="生效日" value={daysText()} chevron onTap={() => setDayPicker(true)} />)
      contentRows.push(
        <PickerRow key="st" label="开始时间" value={start} options={TIMES} onSelect={setStart} />
      )
      contentRows.push(<PickerRow key="et" label="结束时间" value={end} options={TIMES} onSelect={setEnd} />)
    }
    contentRows.push(
      <Row
        key="url"
        label="网址过滤"
        value={urls.length ? `${urls.length} 条` : "无设置"}
        valueColor={urls.length ? ACCENT : "tertiaryLabel"}
        chevron
        onTap={() => setView("url")}
      />
    )
    groups.push(
      <Group key="content" header="规则内容">
        {contentRows}
      </Group>
    )

    groups.push(
      <Group key="save">
        <ButtonRow title="保存" busy={saving} onTap={saveRule} />
      </Group>
    )

    groups.push(
      <Group key="back">
        <ButtonRow title="返回列表" onTap={() => setView("list")} />
      </Group>
    )

    if (editId) {
      const cur = rules.find(r => String(r?.Id ?? "") === editId)
      if (cur) {
        groups.push(
          <Group key="del">
            <ButtonRow title="删除这条规则" destructive onTap={() => deleteRule(cur)} />
          </Group>
        )
      }
    }

    return (
      <SettingsPage title="家长控制规则" toast={hintToast(toastHint, () => setToastHint(null))}>
        {groups}
      </SettingsPage>
    )
  }

  /* ---------------- 选择应用设备 ---------------- */

  function devicesPage() {
    const online = stas.filter(s => String(s?.Active ?? "") === "1")
    const offline = stas.filter(s => String(s?.Active ?? "") !== "1")

    function rowsOf(list: any[], prefix: string) {
      return list.map((s, i) => {
        const m = String(s?.Mac ?? "")
        const picked = selMacs.includes(m)
        return (
          <Row
            key={`${prefix}${i}`}
            label={String(s?.Devname ?? m)}
            note={`MAC：${m}`}
            selected={picked}
            onTap={() => setSelMacs(picked ? selMacs.filter(x => x !== m) : [...selMacs, m])}
          />
        )
      })
    }

    return (
      <SettingsPage title="选择应用设备">
        <Group header={`在线设备（${online.length}）`}>
          {online.length ? rowsOf(online, "on") : <Row label="没有在线设备" icon="minus.circle" />}
        </Group>
        <Group header={`离线设备（${offline.length}）`}>
          {offline.length ? rowsOf(offline, "off") : <Row label="没有离线设备" icon="minus.circle" />}
        </Group>
        <Group>
          <ButtonRow title={`完成（已选 ${selMacs.length} 台）`} onTap={() => setView("edit")} />
        </Group>
      </SettingsPage>
    )
  }

  /* ---------------- 网址过滤 ---------------- */

  function urlPage() {
    const list: any[] = urls.map((u, i) => (
      <Row
        key={`u${i}`}
        icon="globe"
        iconColor={ACCENT}
        label={u}
        mono
        trailing={
          <HStack spacing={0} padding={{ vertical: 2, horizontal: 4 }} contentShape="rect" onTapGesture={() => setUrls(urls.filter((_, k) => k !== i))}>
            <Text font="footnote" foregroundStyle={ACCENT_WARM}>
              删除
            </Text>
          </HStack>
        }
      />
    ))

    return (
      <SettingsPage title="网址过滤">
        <Group footer="黑名单：只挡住这些网址；白名单：只放行这些网址。">
          <PickerRow label="过滤方式" value={URL_MODES.find(m => m.value === urlMode)?.label ?? "无设置"} selected={urlMode} options={URL_MODES} onSelect={setUrlMode} />
        </Group>
        <Group header={`网址（${urls.length}）`}>
          {urls.length ? list : <Row label="还没有网址" icon="info.circle" />}
          <InputRow
            label="添加网址"
            value={urlInput}
            prompt="例如 www.example.com"
            autocapitalization="never"
            autocorrectionDisabled
            onChanged={setUrlInput}
          />
          <ButtonRow
            title="加入列表"
            disabled={!urlInput.trim()}
            onTap={() => {
              const v = urlInput.trim()
              if (!v) return
              if (!urls.includes(v)) setUrls([...urls, v])
              setUrlInput("")
            }}
          />
        </Group>
        <Group>
          <ButtonRow title="返回规则" onTap={() => setView("edit")} />
        </Group>
      </SettingsPage>
    )
  }

  /* ---------------- 渲染 ---------------- */

  const body = view === "edit" ? editPage() : view === "devices" ? devicesPage() : view === "url" ? urlPage() : listPage()

  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      {body}
      {dayPicker ? (
        <Overlay onDismiss={() => setDayPicker(false)}>
          <WeekdayDialog
            week={WEEK}
            days={days}
            accent={ACCENT}
            onToggle={d => setDays(days.includes(d) ? days.filter(x => x !== d) : [...days, d])}
            onCancel={() => setDayPicker(false)}
            onDone={() => setDayPicker(false)}
          />
        </Overlay>
      ) : null}
    </ZStack>
  )
}
