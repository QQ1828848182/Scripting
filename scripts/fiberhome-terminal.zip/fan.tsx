// ---------- 风扇模式（CPE_FAN_CONTROL） ----------
// 命令不是 GET_/SET_ 命名，而是带 action 的复合命令：
//   读：{ action: "get", mode: "" }
//   写：{ action: "set", mode: "0" | "1" | "2" | "3" }
// 实测四个取值全部被接受，且回读一致（2026-10-27 现场验证）。
// 页面已取消（改为工具箱里的弹窗选择），这里只导出档位表 + 读/写/回读校验。

import type { Color } from "scripting"
import { invokeService } from "./lib/invoke"

const FAN_CMD = "CPE_FAN_CONTROL"

/** 档位（已按官方页面确认）：1=静音 / 0=标准 / 2=性能；官方没有 3 */
export const FAN_GEARS: { mode: string; label: string; desc: string; icon: string; color: Color }[] = [
  { mode: "1", label: "静音", desc: "静音体验，适用于低负载、温度低场景", icon: "fanblades.fill", color: "#3E8BFF" },
  { mode: "0", label: "标准", desc: "平衡产品运行性能和静音体验", icon: "fanblades.fill", color: "#34C759" },
  { mode: "2", label: "性能", desc: "强劲散热，适用于高负荷、温度高场景", icon: "fanblades.fill", color: "#C97A45" },
]

/** 从设备返回里抠出档位数字 */
export function fanModeOf(data: any): string | null {
  if (!data) return null
  if (typeof data === "string" && /^\d+$/.test(data.trim())) return data.trim()
  if (typeof data === "object") {
    for (const k of ["mode", "Mode", "fanMode", "FanMode"]) {
      const v = (data as any)[k]
      if (v !== undefined && v !== null && /^\d+$/.test(String(v).trim())) return String(v).trim()
    }
  }
  return null
}

/** 设备回了 0/1/2 以外的值也能如实显示 */
export function fanModeLabel(mode: string | null): string {
  if (mode === null) return "未知"
  return FAN_GEARS.find(g => g.mode === mode)?.label ?? `未定义（mode ${mode}）`
}

export type FanReadResult = { ok: boolean; mode: string | null; error?: string; code?: number }

export async function readFanMode(mac: string, token: string): Promise<FanReadResult> {
  const r = await invokeService<any>(mac, token, FAN_CMD, { action: "get", mode: "" }, 8)
  if (!r.ok) {
    return { ok: false, mode: null, error: `${r.error ?? "读取失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`, code: r.code }
  }
  return { ok: true, mode: fanModeOf(r.data) }
}

export type FanSetResult = { ok: boolean; mode: string | null; error?: string; warning?: string }

/** 下发档位 + 回读校验（最多 6 次 × 400ms） */
export async function setFanMode(mac: string, token: string, next: string): Promise<FanSetResult> {
  const r = await invokeService<any>(mac, token, FAN_CMD, { action: "set", mode: next }, 8)
  if (!r.ok && !/未实现/.test(r.error ?? "")) {
    return {
      ok: false,
      mode: null,
      error: `设置失败：${r.error ?? "未知"}${r.code !== undefined ? ` (code ${r.code})` : ""}`,
    }
  }

  let last: string | null = null
  for (let i = 0; i < 6; i++) {
    await new Promise<void>(res => setTimeout(res, 400))
    const c = await invokeService<any>(mac, token, FAN_CMD, { action: "get", mode: "" }, 8)
    if (!c.ok) continue
    const m = fanModeOf(c.data)
    if (m === null) continue
    last = m
    if (m === next) break
  }

  if (last === next) return { ok: true, mode: next }
  if (last === null) {
    return { ok: true, mode: next, warning: "已下发，但没能回读当前档位（可下拉刷新）" }
  }
  return {
    ok: true,
    mode: next,
    warning: `已下发「${fanModeLabel(next)}」，设备回读仍为「${fanModeLabel(last)}」`,
  }
}
