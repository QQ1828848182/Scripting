// ---------- 射频信号参数（GET_RF_SIGNAL_INFO，只读） ----------
// 官方页面里 AMBR 是 Kbps 原始值换算成 Mbps 显示的（204800 → 200 Mbps），这里两者都给。
// 邻居小区：设备给的是 5 条并行数组（EARFCN-NBR / PCI-NBR / RSRP-NBR / SINR-NBR / BAND-NBR），
// 这里按下标拼成「一个小区一行」的表格，并按 RSRP 从强到弱排序；长按某个数值可单独复制它。

import { HStack, Spacer, Text, useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import type { Hint } from "./lib/ui"
import { hintToast } from "./lib/ui"
import { ACCENT, DANGER, Group, NoticeRow, OK, Row, SettingsPage } from "./lib/settings"

const ACCENT_WARM = "#FF9F0A"

// 设备给的是 Kbps 原始值，按 1024 进制换算成 Mbps（204800 → 200 Mbps、1024000 → 1000 Mbps）。
export function mbps(kbps: string): string {
  const n = Number(kbps)
  if (!isFinite(n) || n <= 0) return "—"
  const v = n / 1024
  const r = v >= 100 ? Math.round(v) : Number(v.toFixed(1))
  return `${r} Mbps`
}


function rsrpColor(v: string): any {
  const n = Number(v)
  if (!isFinite(n)) return "secondaryLabel"
  if (n >= -85) return OK
  if (n >= -100) return ACCENT_WARM
  return DANGER
}

/** SINR：≥10 好、≥0 一般、其余差 */
function sinrColor(v: string): any {
  const n = Number(v)
  if (!isFinite(n)) return "secondaryLabel"
  if (n >= 10) return OK
  if (n >= 0) return ACCENT_WARM
  return DANGER
}

function toList(raw: any): string[] {
  return String(raw ?? "")
    .split(",")
    .map(s => s.trim())
    .filter(s => s !== "" && s !== "-")
}

export type Nbr = { band: string; pci: string; earfcn: string; rsrp: string; sinr: string }

/** 把 5 条并行数组拼成小区对象，并按 RSRP 从强到弱排序 */
export function nbrCells(data: any): Nbr[] {
  const earfcn = toList(data?.EARFCN_NBR)
  const pci = toList(data?.PCI_NBR)
  const band = toList(data?.BAND_NBR)
  const rsrp = toList(data?.RSRP_NBR)
  const sinr = toList(data?.SINR_NBR)
  const n = Math.max(earfcn.length, pci.length, band.length, rsrp.length, sinr.length)
  const list: Nbr[] = []
  for (let i = 0; i < n; i++) {
    list.push({
      band: band[i] ?? "—",
      pci: pci[i] ?? "—",
      earfcn: earfcn[i] ?? "—",
      rsrp: rsrp[i] ?? "—",
      sinr: sinr[i] ?? "—",
    })
  }
  list.sort((a, b) => {
    const x = Number(a.rsrp)
    const y = Number(b.rsrp)
    if (!isFinite(x) && !isFinite(y)) return 0
    if (!isFinite(x)) return 1
    if (!isFinite(y)) return -1
    return y - x
  })
  return list
}

/** 表头：频段 / PCI / EARFCN / RSRP / SINR */
export function NbrHeader() {
  return (
    <Row
      content={
        <HStack spacing={8} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <Text font="caption2" foregroundStyle="tertiaryLabel" frame={{ width: 44, alignment: "leading" }}>
            频段
          </Text>
          <Text font="caption2" foregroundStyle="tertiaryLabel" frame={{ width: 60, alignment: "leading" }}>
            小区 ID
          </Text>
          <Text font="caption2" foregroundStyle="tertiaryLabel" frame={{ width: 62, alignment: "leading" }}>
            频点
          </Text>
          <Spacer />
          <Text font="caption2" foregroundStyle="tertiaryLabel" frame={{ width: 44, alignment: "trailing" }}>
            强度
          </Text>
          <Text font="caption2" foregroundStyle="tertiaryLabel" frame={{ width: 44, alignment: "trailing" }}>
            信噪比
          </Text>
        </HStack>
      }
    />
  )
}

/** 一个邻居小区一行；长按任意数值只复制那一项 */
export function NbrCell(props: { c: Nbr; onCopy: (text: string, label: string) => void }) {
  const { c, onCopy } = props
  return (
    <Row
      content={
        <HStack spacing={8} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <Text
            font="footnote"
            fontWeight="semibold"
            foregroundStyle={ACCENT}
            frame={{ width: 44, alignment: "leading" }}
            contentShape="rect"
            onLongPressGesture={() => onCopy(c.band, "频段")}
          >
            {c.band}
          </Text>
          <Text
            font="footnote"
            monospaced
            frame={{ width: 60, alignment: "leading" }}
            contentShape="rect"
            onLongPressGesture={() => onCopy(c.pci, "PCI")}
          >
            {c.pci}
          </Text>
          <Text
            font="caption"
            monospaced
            foregroundStyle="secondaryLabel"
            frame={{ width: 62, alignment: "leading" }}
            lineLimit={1}
            contentShape="rect"
            onLongPressGesture={() => onCopy(c.earfcn, "频点")}
          >
            {c.earfcn}
          </Text>
          <Spacer />
          <Text
            font="footnote"
            monospaced
            fontWeight="semibold"
            foregroundStyle={rsrpColor(c.rsrp)}
            frame={{ width: 44, alignment: "trailing" }}
            contentShape="rect"
            onLongPressGesture={() => onCopy(c.rsrp, "强度")}
          >
            {c.rsrp}
          </Text>
          <Text
            font="footnote"
            monospaced
            fontWeight="semibold"
            foregroundStyle={sinrColor(c.sinr)}
            frame={{ width: 44, alignment: "trailing" }}
            contentShape="rect"
            onLongPressGesture={() => onCopy(c.sinr, "信噪比")}
          >
            {c.sinr}
          </Text>
        </HStack>
      }
    />
  )
}

export default function RfPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices[0]

  const [rf, setRf] = useState<any>(null)
  const [error, setError] = useState("")
  const [hint, setHint] = useState<Hint | null>(null)

  async function load() {
    if (!device?.mac || !session.token) return
    setError("")
    const r = await invokeService<any>(device.mac, session.token, "GET_RF_SIGNAL_INFO", {}, 8)
    if (r.ok) {
      setRf(r.data)
    } else {
      setError(`${r.error ?? "读取失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
    }
  }
  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  /** 长按某个数值：只复制这一项 */
  async function copyOne(text: string, label: string) {
    if (!text || text === "—") return
    await Pasteboard.setString(text)
    setHint({ text: `已复制 ${label}：${text}` })
  }

  const v = (k: string) => {
    const x = rf?.[k]
    return x === undefined || x === null || x === "" || x === "-" ? "—" : String(x)
  }

  const cells = nbrCells(rf)

  return (
    <SettingsPage title="射频信号参数" refreshable={load} toast={hintToast(hint, () => setHint(null))}>
      {error ? (
        <Group>
          <NoticeRow kind="error" text={error} />
        </Group>
      ) : null}

      <Group header="速率上限">
        <Row
          label="上行速率上限"
          note={v("UL_AMBR") !== "—" ? `UL-AMBR · ${v("UL_AMBR")} Kbps` : "UL-AMBR"}
          icon="arrow.up.circle"
          iconColor={ACCENT}
          value={mbps(v("UL_AMBR"))}
        />
        <Row
          label="下行速率上限"
          note={v("DL_AMBR") !== "—" ? `DL-AMBR · ${v("DL_AMBR")} Kbps` : "DL-AMBR"}
          icon="arrow.down.circle"
          iconColor={ACCENT}
          value={mbps(v("DL_AMBR"))}
        />
      </Group>

      <Group header="小区">
        <Row label="跟踪区码" note="TAC" icon="mappin.and.ellipse" value={v("TAC")} />
        <Row label="运营商网络" note="PLMN" icon="globe" value={v("PLMN")} />
        <Row label="工作模式" note="WorkMode" icon="gearshape.2" value={v("WorkMode")} />
        <Row label="NR 频段" note="NR_BAND · n 号" icon="wave.3.right" value={v("NR_BAND")} />
        <Row
          label="物理小区 ID"
          note="PCI"
          icon="dot.radiowaves.left.and.right"
          value={v("NR_PCI") !== "—" ? v("NR_PCI") : v("PCI")}
        />
      </Group>

      <Group header="信号强度">
        <Row
          label="同步信号强度"
          note="SSB-RSRP"
          icon="cellularbars"
          iconColor={rsrpColor(v("SSB_RSRP"))}
          value={v("SSB_RSRP")}
        />
        <Row
          label="参考信号强度"
          note="RSRP"
          icon="cellularbars"
          iconColor={rsrpColor(v("RSRP"))}
          value={v("RSRP") !== "—" ? v("RSRP") : v("SSB_RSRP")}
        />
        <Row label="参考信号质量" note="RSRQ" icon="waveform.path.ecg" value={v("RSRQ")} />
        <Row label="同步信号质量" note="SSB-RSRQ" icon="waveform.path.ecg" value={v("SSB_RSRQ")} />
        <Row label="接收总强度" note="RSSI" icon="antenna.radiowaves.left.and.right" value={v("RSSI")} />
        <Row label="信噪比" note="SINR" icon="chart.line.uptrend.xyaxis" value={v("SINR")} />
        <Row label="同步信号信噪比" note="SSB-SINR" icon="chart.line.uptrend.xyaxis" value={v("SSB_SINR")} />
        <Row label="信道质量" note="CQI" icon="gauge" value={v("NR_CQI")} />
      </Group>

      <Group
        header={`邻居小区${cells.length ? `（${cells.length} 个）` : ""}`}
        footer={
          cells.length
            ? "按 RSRP 从强到弱排序；长按任意数值可单独复制该项。"
            : "设备没有返回邻居小区数据。"
        }
      >
        {cells.length ? (
          [<NbrHeader key="hdr" />, ...cells.map((c, i) => <NbrCell key={`c${i}`} c={c} onCopy={copyOne} />)]
        ) : (
          <Row label="暂无数据" icon="minus.circle" />
        )}
      </Group>
    </SettingsPage>
  )
}
