# FiberHome Terminal · 烽火终端

> 一个用 [Scripting](https://scripting.fun)（TSX）写的**烽火 5G CPE 远程控制台**，界面采用 iOS 26 **Liquid Glass（液态玻璃）**。
> 所有数据走云端 `home.mifon.com`，**不依赖局域网网关**，人在外面也能看设备的实时速率、信号和流量。

<p align="center">
  <img alt="platform" src="https://img.shields.io/badge/platform-iOS%2026%2B-black?logo=apple" />
  <img alt="language" src="https://img.shields.io/badge/lang-TypeScript-3178C6?logo=typescript&logoColor=white" />
  <img alt="scripting" src="https://img.shields.io/badge/Scripting-TSX-0A84FF" />
  <img alt="license" src="https://img.shields.io/badge/license-MIT-green" />
</p>

---

## ✨ 特性

| | |
|---|---|
| ☁️ **纯远程** | 只走云端接口，不需要和 CPE 在同一局域网 |
| 🔐 **两种登录** | 账号 + 密码 / 账号 + Token；会话写入 **Keychain**（按脚本隔离，不落明文） |
| 📊 **真实数据** | 上传/下载速率、日/月流量、RSRP / SINR / RSRQ、频段 / PCI、载波聚合、CPU / 内存 / 运行时长 |
| 📱 **多设备** | 一个账号下多台 CPE 自由切换 |
| 🧰 **工具箱** | 接入设备、指示灯、移动网络、短信、流量、锁频、家长控制、DHCP、定时重启、MLO、风扇 |
| 🪟 **Liquid Glass** | `glassEffect` + `GlassEffectContainer`，iOS 26 原生材质，低版本自动降级为半透明纯色 |
| 🧩 **零依赖** | SHA-256 纯 JS 实现，不引入任何第三方库 |

## 📸 界面

三个页签对齐官方 App：**首页** / **工具箱** / **路由设置**。

```
┌───────────── 首页 ─────────────┐   ┌────────── 工具箱 ──────────┐
│ 关闭            烽火终端        │   │  接入设备   指示灯   移动网络 │
│ ┌───────────────────────────┐  │   │  短信       流量     锁频    │
│ │ ● 在线   CPE-5G            │  │   │  家长控制   DHCP     定时重启 │
│ │ 型号  LG6851F   MAC AA:…   │  │   │  MLO        风扇     信号详情 │
│ └───────────────────────────┘  │   └────────────────────────────┘
│  ↓ 386 Mb/s      ↑ 42 Mb/s     │
│  RSRP -78   SINR 22   频段 n78 │   ┌───────── 路由设置 ─────────┐
│  今日 12.4 GB   本月 218 GB    │   │ 设备名称 / 管理密码 / 升级   │
│  [关闭并退出]                  │   │ 重启 / 恢复出厂 / 退出登录   │
└────────────────────────────────┘   └────────────────────────────┘
```

## 📦 安装（远程导入）

仓库根目录本身就是一个完整的 Scripting 脚本项目（含 `script.json`），**三种方式任选**。

### 方式 A：GitHub 直连导入（推荐）

1. 复制压缩包地址（把 `<你的用户名>` 换成仓库实际地址）：
   ```
   https://github.com/<你的用户名>/fiberhome-terminal/archive/refs/heads/main.zip
   ```
2. 在 **Scripting** 中选择 *从 URL 导入 / 远程导入*，粘贴上面的 zip 地址即可。

> 也可以用 `git clone`，然后把目录内容作为脚本项目打开。

### 方式 B：打包成 `.scripting` 手动导入

`.scripting` 就是改了扩展名的 zip，自己打一个就行：

```bash
git clone https://github.com/<你的用户名>/fiberhome-terminal.git
cd fiberhome-terminal
zip -r ../fiberhome-terminal.scripting * -x "scripts/*" "docs/*" ".*"
```

把生成的 `fiberhome-terminal.scripting` 传到 iPhone，点开即导入 Scripting。

### 方式 C：文件 App 直接放

把整个仓库内容放到 iCloud Drive 的一个文件夹里，在 Scripting 里「打开文件夹作为项目」。

## 🚀 使用

1. 打开脚本 → 出现全屏登录页；
2. 选 **账号密码** 或 **账号 Token**；
3. 登录成功后进入首页，下拉刷新拉取最新快照。

> ⚠️ **建议优先用 Token 登录**：账号密码登录会把官方 App 挤下线，Token 方式可以和 App 同时在线。
> Token 获取：抓一次官方 App 请求头里的 `token` 字段即可。

## 🗂 项目结构

```
script.json          脚本元信息（name / icon / color / version，Scripting 必需）
index.tsx            入口：TabView(首页 / 工具箱 / 路由设置) + 全屏登录模态
login.tsx            登录页（账号密码 / 账号 Token）
home.tsx             首页：设备总览 + 实时速率 / 信号 / 流量
toolbox.tsx          工具箱：功能宫格
router.tsx           路由设置：设备设置 + 账号资料 + 退出登录
clients.tsx / sim.tsx / sms.tsx / traffic.tsx / wifi.tsx / wan.tsx / dhcp.tsx
lock*.tsx / mlo.tsx / rf.tsx / mnet.tsx / fan.tsx / reboot.tsx / upgrade.tsx / bind.tsx ...
lib/api.ts           接口层：登录、Token 校验、设备列表、用户信息、改名
lib/invoke.ts        设备 RPC 网关（device/invokeService，三层信封 + base64）
lib/deviceData.ts    设备快照、速率采样、缓存与格式化
lib/sign.ts          SHA256(timestamp + uuid + body) 请求签名
lib/sha256.ts        纯 JS SHA-256（UTF-8 安全）
lib/store.ts         Keychain 会话读写
lib/ui.tsx           液态玻璃基础组件（GlassCard / Pill / InfoRow / fill / IconBadge）
lib/localApi.ts      本地 CPE 接口层（/api/tmp/FHTOOLAPIS）
scripts/             开发期自检脚本（不需要放进 Scripting）
```

## 🔌 云端接口

```
LOGIN_URL       POST https://home.mifon.com/NetworkPlatform/rest/user/userLogin
USER_INFO_URL   POST https://home.mifon.com/NetworkPlatform/rest/userInfo/queryUserInfo
DEVICE_LIST_URL POST https://home.mifon.com/NetworkPlatform/rest/deviceBind/getAllDeviceByUser
DEVICE_INVOKE   POST https://home.mifon.com/NetworkPlatform/rest/device/invokeService
```

请求头：

| 头 | 值 |
|---|---|
| `content-type` | `application/json` |
| `apptype` | `terminal` |
| `uuid` | 32 位大写 HEX，首次生成后存 Keychain 固定复用 |
| `timestamp` | 13 位毫秒 |
| `signature` | `SHA256(timestamp + uuid + body)`，64 位小写 hex |
| `user-agent` | `FHTerminal/2.2.51 (iPhone; iOS 27.0.1; Scale/3.00)` |

> 签名中的 `body` 必须是**实际发送的 JSON 原文**，不能反序列化后再序列化。

## 🧪 自检

```bash
python3 scripts/check.py          # esbuild 解析全部 TS/TSX 语法（仅语法，不做类型检查）
python3 scripts/verify_logic.py   # 摘要 / 响应解析 / 错误分支单测
```

真正的类型检查请在 Scripting 里跑 TypeScript 诊断——本项目当前为 **0 error**。

## 📋 功能真实性

| 状态 | 内容 |
|---|---|
| ✅ 真实数据 | 设备名称 / 型号 / MAC / SN / 在线状态 / 固件 / 安装位置 / 区域 / 绑定时间，账号资料，**上下行速率、日/月流量、运营商与工作模式、频段 / PCI、RSRP / SINR / RSRQ、载波聚合、CPU / 内存 / 运行时长**，设备改名 |
| 🚧 占位 | 接入设备明细、短信、指示灯、锁频、家长控制、DHCP、定时重启、MLO、风扇模式、Wi-Fi 设置、重启、恢复出厂 |

占位项保留了官方布局与点击反馈，**不伪造数字**；拿到对应接口后替换 `onTap` 即可。

## ⚖️ 免责声明

本项目通过抓包还原的私有接口实现，**仅用于管理你自己的账号与设备**，以及协议学习。
请勿用于越权访问他人设备。密码 / Token 只保存在本机 Keychain，仓库中不含任何真实凭据。
与烽火通信及相关 App 开发者无任何关联。

## 📄 License

[MIT](LICENSE) · 详见 [docs/ARCHIVE.md](docs/ARCHIVE.md) 了解每一轮的开发与修复记录。
