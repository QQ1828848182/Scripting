// ---------- 移动网络设置（读写）——— 从官方「移动网络 → 移动网络设置」进去 ----------
// 读：GET_MOBILE_NETWORK  → FlightMode / DataNetEnable / DateRoaming /
//                           CarrierAggregationEnable / CarrierAggregationEnable2 / WorkMode / NetworkMode
// 写：SET_MOBILE_NETWORK  → 必须是「全量状态」，只改一个字段也要把 6 个字段一起回传。
// 语义：0=关、1=开。NetworkMode 3 = 5G Pref；WorkMode 1 = SA（都不是开关，别套 0/1 规则）。

import { useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"
import {
  ACCENT,
  Group,
  NoticeRow,
  OK,
  PickerRow,
  Row,
  SettingsPage,
  SwitchRow,
} from "./lib/settings"

const SET_CMD = "SET_MOBILE_NETWORK"

type Field = "DataNetEnable" | "DateRoaming" | "FlightMode" | "CarrierAggregationEnable" | "NetworkMode" | "WorkMode"

const LABEL: Record<Field, string> = {
  DataNetEnable: "数据网络",
  DateRoaming: "数据漫游",
  FlightMode: "飞行模式",
  CarrierAggregationEnable: "载波聚合",
  NetworkMode: "网络模式",
  WorkMode: "组网模式",
}

/** 网络模式（用户确认）：3=5G优先 / 2=仅5G / 0=仅4G / 1=仅3G */
const NET_MODES = [
  { value: "3", label: "5G 优先" },
  { value: "2", label: "仅 5G" },
  { value: "0", label: "仅 4G" },
  { value: "1", label: "仅 3G" },
]

/** 组网模式（用户确认）：1=SA / 3=SA+NSA / 2=NSA */
const WORK_MODES = [
  { value: "1", label: "SA" },
  { value: "3", label: "SA + NSA" },
  { value: "2", label: "NSA" },
]

const netModeLabel = (v: string) => NET_MODES.find(m => m.value === v)?.label ?? (v ? `未知(${v})` : "—")
const workModeLabel = (v: string) => WORK_MODES.find(m => m.value === v)?.label ?? (v ? `未知(${v})` : "—")

/** 组网模式受网络模式限制（对齐网页版 NR_ALLOWED）
 *  5G 优先 → SA / SA+NSA / NSA；仅 5G → 只能 SA；仅 4G、仅 3G → 不支持组网模式 */
const NR_ALLOWED: Record<string, string[]> = {
  "3": ["1", "3", "2"], // 5G 优先
  "2": ["1"], // 仅 5G
  "0": [], // 仅 4G
  "1": [], // 仅 3G
}
/** 允许的组网模式；网络模式未知时返回全部（不误锁） */
function nrAllowed(networkMode: string): string[] {
  if (!networkMode) return WORK_MODES.map(m => m.value)
  return NR_ALLOWED[networkMode] ?? WORK_MODES.map(m => m.value)
}

/** 全量状态包：只替换 patch 里的字段，其余原样回传 */
function bundle(net: any, patch: Record<string, string>): Record<string, string> {
  const base: Record<string, string> = {
    DataNetEnable: String(net?.DataNetEnable ?? "1"),
    DateRoaming: String(net?.DateRoaming ?? "0"),
    WorkMode: String(net?.WorkMode ?? "1"),
    CarrierAggregationEnable: String(net?.CarrierAggregationEnable ?? "0"),
    FlightMode: String(net?.FlightMode ?? "0"),
    NetworkMode: String(net?.NetworkMode ?? "3"),
  }
  return { ...base, ...patch }
}

export default function MnetPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices[0]

  const [net, setNet] = useState<any>(null)
  const [busy, setBusy] = useState<Field | null>(null)
  const [error, setError] = useState("")
  const [notice, setNotice] = useState("")
  const [warn, setWarn] = useState("")
  const [confirmKey, setConfirmKey] = useState<string | null>(null)
  const [hint, setHint] = useState<Hint | null>(null)

  async function load() {
    if (!device?.mac || !session.token) return
    setError("")
    const a = await invokeService<any>(device.mac, session.token, "GET_MOBILE_NETWORK", {}, 8)
    if (a.ok) {
      setNet(a.data)
    } else {
      setError(`${a.error ?? "读取失败"}${a.code !== undefined ? ` (code ${a.code})` : ""}`)
    }
  }
  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  const val = (f: Field) => String(net?.[f] ?? "")
  const isOn = (f: Field) => val(f) === "1"

  /** 风险动作需要二次确认：飞行模式开、网络模式切“仅4G/仅3G” */
  function dangerOf(f: Field, next: string): string | null {
    if (f === "FlightMode" && next === "1")
      return "飞行模式会立刻关闭设备蜂窝，脚本走的云端通道也会随之断开，届时只能靠局域网(192.168.8.1)或机身按键恢复。确认就再点一次。"
    if (f === "NetworkMode" && next === "0")
      return "切成「仅 4G」后如果当地 4G 覆盖不好，设备可能失去上行，远控会断。确认就再选一次。"
    if (f === "NetworkMode" && next === "1")
      return "切成「仅 3G」后设备大概率掉到 3G 甚至断网（远控随之失效）。确认就再选一次。"
    if (f === "DataNetEnable" && next === "0")
      return "关掉数据网络会断开设备的上行，脚本的云端通道也会断，只能靠局域网恢复。确认就再点一次。"
    return null
  }

  async function write(f: Field, next: string) {
    if (!device?.mac || !session.token || busy) return
    // 组网模式不在当前网络模式允许集合内：直接拦下
    if (f === "WorkMode" && !nrAllowed(String(net?.NetworkMode ?? "")).includes(next)) {
      setWarn("当前网络模式不支持这个组网模式（仅 4G / 仅 3G 没有 5G 组网，仅 5G 只能 SA），已拦下。")
      return
    }

    const key = `${f}:${next}`
    const danger = dangerOf(f, next)
    if (danger && confirmKey !== key) {
      setConfirmKey(key)
      setWarn(danger)
      return
    }
    setConfirmKey(null)
    setWarn("")
    setError("")
    setNotice("")

    const isMode = f === "NetworkMode" || f === "WorkMode"
    const prev = net
    const patch: Record<string, string> = { [f]: next }
    const curWm = String(net?.WorkMode ?? "")
    let autoWm = ""
    // 改网络模式时联动组网模式：不在允许集合里就回落到第一个允许值（3G/4G 不动组网）
    if (f === "NetworkMode") {
      const allowed = NR_ALLOWED[next] ?? []
      if (allowed.length > 0 && !allowed.includes(curWm)) {
        patch.WorkMode = allowed[0]
        autoWm = allowed[0]
      }
    }
    setBusy(f)
    setNet({ ...(net ?? {}), ...patch }) // 乐观更新，避免控件回弹

    // 改网络制式 / 组网模式 → 设备会重新注册，云端掉线 10~20s，SET 响应大概率超时但配置已生效
    if (isMode) setNotice("已下发，设备正在重新注册，可能掉线 10~30 秒，等它回来自动校对…")

    const r = await invokeService<any>(device.mac, session.token, SET_CMD, bundle(prev, patch), isMode ? 20 : 8)

    const pending = !r.ok && (/超时|超时|timeout/i.test(r.error ?? "") || r.code === 20029)
    if (!r.ok && !pending && !/未实现/.test(r.error ?? "")) {
      setNet(prev)
      setBusy(null)
      setNotice("")
      setError(`设置失败：${r.error ?? "未知"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
      setHint({ text: "设置失败", ok: false })
      return
    }
    if (pending && !isMode) setNotice("响应超时，正在回读校对…")

    // 回读校对：普通开关 8×500ms；制式类掉线重连，最多等 45s
    const tries = isMode ? 45 : 8
    const gap = isMode ? 1000 : 500
    let last: string | null = null
    for (let i = 0; i < tries; i++) {
      await new Promise<void>(res => setTimeout(res, gap))
      const c = await invokeService<any>(device.mac, session.token, "GET_MOBILE_NETWORK", {}, 12)
      if (!c.ok) continue
      last = String(c.data?.[f] ?? "")
      setNet(c.data)
      if (last === next) break
    }
    setBusy(null)
    setNotice("")

    const show = (v: string) =>
      f === "NetworkMode" ? netModeLabel(v) : f === "WorkMode" ? workModeLabel(v) : v === "1" ? "开" : "关"

    if (last === next) {
      setHint({ text: autoWm ? `设置成功，组网模式已联动为 ${workModeLabel(autoWm)}` : "设置成功" })
      return
    }
    if (last === null) {
      // 完全读不到：设备可能还在重连，不要盲目回滚，保持用户意图
      setError("已下发，但设备还没回来（仍在重连）。过一会儿下拉刷新确认即可。")
      return
    }
    // 明确读到旧值才算失败
    setNet({ ...(prev ?? {}), ...patch })
    setError(`已下发「${LABEL[f]} = ${show(next)}」，设备回读仍为 ${show(last)}（${f}=${last}）`)
  }

  const toggle = (f: Field) => (v: boolean) => {
    // 数据还没读到时不写（避免进页面误写）
    if (!net) return
    write(f, v ? "1" : "0")
  }

  const nm = String(net?.NetworkMode ?? "")
  const wm = String(net?.WorkMode ?? "")
  const allowedWm = nrAllowed(nm)
  const nrOk = allowedWm.length > 0
  const wmOptions = nrOk ? WORK_MODES.filter(m => allowedWm.includes(m.value)) : WORK_MODES

  return (
    <SettingsPage title="移动网络设置" refreshable={load} toast={hintToast(hint, () => setHint(null))}>
      {notice ? (
        <Group>
          <NoticeRow kind="ok" text={notice} />
        </Group>
      ) : null}

      {warn ? (
        <Group>
          <NoticeRow kind="error" text={warn} />
        </Group>
      ) : null}

      {error ? (
        <Group>
          <NoticeRow kind="error" text={error} />
        </Group>
      ) : null}

      <Group header="开关">
        <SwitchRow label="飞行模式" note="关闭蜂窝收发" value={isOn("FlightMode")} onChanged={toggle("FlightMode")} />
        <SwitchRow label="数据漫游" note="在国外使用当地网络" value={isOn("DateRoaming")} onChanged={toggle("DateRoaming")} />
        <SwitchRow label="数据网络" note="关闭后设备无法上网" value={isOn("DataNetEnable")} onChanged={toggle("DataNetEnable")} />
        <SwitchRow
          label="载波聚合"
          note="多个频段叠加提速"
          value={isOn("CarrierAggregationEnable")}
          onChanged={toggle("CarrierAggregationEnable")}
        />
      </Group>

      <Group header="制式" footer="切换网络模式/组网模式会触发重新注册，设备可能掉线 10~30 秒。">
        <PickerRow
          label="网络模式"
          note="5G 优先 / 仅 5G / 仅 4G / 仅 3G"
          icon="cellularbars"
          iconColor={OK}
          value={netModeLabel(nm)}
          options={NET_MODES}
          onSelect={v => write("NetworkMode", v)}
        />

        {nrOk ? (
          <PickerRow
            label="组网模式"
            note={wmOptions.map(m => m.label).join(" / ")}
            icon="antenna.radiowaves.left.and.right"
            iconColor={ACCENT}
            value={workModeLabel(wm)}
            options={wmOptions}
            onSelect={v => write("WorkMode", v)}
          />
        ) : (
          <Row
            label="组网模式"
            note={`${netModeLabel(nm)} 不支持 5G 组网模式（仅 4G / 仅 3G）`}
            icon="antenna.radiowaves.left.and.right"
            iconColor="tertiaryLabel"
            value="不适用"
            valueColor="tertiaryLabel"
          />
        )}
      </Group>
    </SettingsPage>
  )
}
