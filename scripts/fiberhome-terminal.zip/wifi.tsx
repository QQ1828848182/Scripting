// ---------- Wi-Fi 设置（主 Wi-Fi：2.4G / 5G 分组，iOS 设置风格） ----------
// 读：GET_WIFI_LIST_INFO（12.har 实测）
// 写：SET_WIFI_LIST_INFO（整份配置原样回写，只改用户动过的字段；失败会 toast 原文）
// 字段语义：Enable 0/1 = 该 SSID 开关；AdvertisementEnable 0 = 隐身（不广播）。MLO 开关已从本页移除（MloCtrl 原样回写）

import {
  Button,
  HStack,
  Image,
  SecureField,
  Text,
  TextField,
  useState,
  useEffect,
  ZStack,
} from "scripting"
import type { Color } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import type { WifiEntry, WifiRadioSet } from "./lib/cmds"
import { fetchMainWifi, setWifiList } from "./lib/cmds"
import { hintToast } from "./lib/ui"
import { capsuleFill } from "./lib/ui"
import {
  DANGER,
  Group,
  InputRow,
  NoticeRow,
  OK,
  Row,
  SettingsPage,
  SwitchRow,
} from "./lib/settings"

export type BandDraft = {
  /** SSIDIndex */
  index: string
  title: string
  enable: boolean
  ssid: string
  pwd: string
  /** 隐身 = AdvertisementEnable 0 */
  hidden: boolean
}

function draftOf(e: WifiEntry, title: string): BandDraft {
  return {
    index: e.index,
    title,
    enable: e.enable.trim() !== "0",
    ssid: e.ssid,
    pwd: e.pwd,
    hidden: e.advertise.trim() === "0",
  }
}

/** 每个频段取一个槽位：优先已启用的（停用的空槽位不展示） */
function pickSlot(list: WifiEntry[], type: string): WifiEntry | undefined {
  const band = list.filter(e => e.type === type)
  return band.find(e => e.enable.trim() !== "0") ?? band[0]
}

function strength(pwd: string): { text: string; color: Color } {
  if (!pwd) return { text: "无", color: "rgba(120,120,128,0.55)" as Color }
  const letter = /[a-zA-Z]/.test(pwd)
  const digit = /\d/.test(pwd)
  const symbol = /[^a-zA-Z0-9]/.test(pwd)
  if (pwd.length >= 12 || (pwd.length >= 10 && letter && digit && symbol)) return { text: "高", color: OK }
  if (pwd.length >= 8 && letter && digit) return { text: "高", color: OK }
  if (pwd.length >= 8) return { text: "中", color: "#FF9F0A" as Color }
  return { text: "低", color: DANGER }
}

/** 单频段分组：标题 + 开关 + 名称 / 密码 / 隐身 */
export function BandCard(props: {
  draft: BandDraft
  onChange: (patch: Partial<BandDraft>) => void
  showPwd: boolean
  onTogglePwd: () => void
}) {
  const { draft, onChange, showPwd, onTogglePwd } = props
  const st = strength(draft.pwd)
  return (
    <Group header={draft.title}>
      <SwitchRow label="启用" value={draft.enable} onChanged={v => onChange({ enable: v })} />
      <InputRow
        label="名称"
        value={draft.ssid}
        prompt="Wi-Fi 名称"
        autocorrectionDisabled
        onChanged={v => onChange({ ssid: v })}
      />
      <Row
        content={
          <HStack spacing={10} frame={{ maxWidth: "infinity" }}>
            <Text>密码</Text>
            {showPwd ? (
              <TextField
                title=""
                value={draft.pwd}
                onChanged={v => onChange({ pwd: v })}
                autocorrectionDisabled
                multilineTextAlignment="trailing"
                frame={{ maxWidth: "infinity" }}
              />
            ) : (
              <SecureField
                title=""
                value={draft.pwd}
                onChanged={v => onChange({ pwd: v })}
                multilineTextAlignment="trailing"
                frame={{ maxWidth: "infinity" }}
              />
            )}
            <Text
              font="caption2"
              fontWeight="semibold"
              foregroundStyle="white"
              padding={{ horizontal: 7, vertical: 1 }}
              background={capsuleFill(st.color)}
            >
              {st.text}
            </Text>
            <Image
              systemName={showPwd ? "eye.slash" : "eye"}
              font={14}
              foregroundStyle="secondaryLabel"
              contentShape="rect"
              onTapGesture={onTogglePwd}
            />
          </HStack>
        }
      />
      <SwitchRow label="隐身（不广播名称）" value={draft.hidden} onChanged={v => onChange({ hidden: v })} />
    </Group>
  )
}

export default function WifiPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices[0]

  const [main, setMain] = useState<WifiRadioSet | null>(null)
  const [rawSet, setRawSet] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [hint, setHint] = useState("")
  const [confirmSave, setConfirmSave] = useState(false)

  const [b24, setB24] = useState<BandDraft | null>(null)
  const [b5, setB5] = useState<BandDraft | null>(null)
  const [shown, setShown] = useState<Record<string, boolean>>({})

  function flash(msg: string) {
    setHint(msg)
    setTimeout(() => setHint(""), 2800)
  }

  /** 把设备返回的配置应用到页面（读取/保存后都用它） */
  function applySet(data: WifiRadioSet, raw: any) {
    setMain(data)
    setRawSet(raw ?? null)
    const s24 = pickSlot(data.list, "0")
    const s5 = pickSlot(data.list, "1")
    setB24(s24 ? draftOf(s24, "2.4G Wi-Fi") : null)
    setB5(s5 ? draftOf(s5, "5G Wi-Fi") : null)
  }

  async function load() {
    if (!device?.mac || !session.token) return
    setLoading(true)
    const a = await fetchMainWifi(device.mac, session.token)
    setLoading(false)
    if (!a.ok || !a.data) {
      flash(a.error ?? "读取失败")
      return
    }
    applySet(a.data, a.raw)
  }

  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  function patch(setter: (v: BandDraft) => void, cur: BandDraft | null) {
    return (p: Partial<BandDraft>) => {
      if (!cur) return
      setter({ ...cur, ...p })
    }
  }

  // 是否有未保存的改动
  const dirty =
    main !== null &&
    ((b24 !== null && b24.index !== "" &&
        b24.enable !== (main.list.find(e => e.index === b24.index)?.enable.trim() !== "0")) ||
      (b24 !== null &&
        (b24.ssid !== (main.list.find(e => e.index === b24.index)?.ssid ?? "") ||
          b24.pwd !== (main.list.find(e => e.index === b24.index)?.pwd ?? "") ||
          b24.hidden !== ((main.list.find(e => e.index === b24.index)?.advertise ?? "").trim() === "0"))) ||
      (b5 !== null &&
        (b5.enable !== (main.list.find(e => e.index === b5.index)?.enable.trim() !== "0") ||
          b5.ssid !== (main.list.find(e => e.index === b5.index)?.ssid ?? "") ||
          b5.pwd !== (main.list.find(e => e.index === b5.index)?.pwd ?? "") ||
          b5.hidden !== ((main.list.find(e => e.index === b5.index)?.advertise ?? "").trim() === "0"))))

  async function save() {
    if (!device?.mac || saving || loading) return
    if (!rawSet) {
      flash("还没读到 Wi-Fi 配置")
      return
    }
    if (!confirmSave) {
      setConfirmSave(true)
      setTimeout(() => setConfirmSave(false), 4000)
      flash("再点一次「保存」：改名称/密码后已连接的设备需要重新连接")
      return
    }
    setConfirmSave(false)

    const drafts = [b24, b5].filter((d): d is BandDraft => d !== null)
    // 实测官方 App 只下发被编辑的两个主 SSID 槽位（idx 1 / 5），其余槽位不带上，避免误改扩展 SSID
    const list = (Array.isArray(rawSet.WIFIList) ? rawSet.WIFIList : [])
      .filter((it: any) => drafts.some(d => d.index === String(it.SSIDIndex)))
      .map((it: any) => {
        const d = drafts.find(x => x.index === String(it.SSIDIndex))
        if (!d) return { ...it, isLoading: false }
        return {
          ...it,
          SSID: d.ssid,
          PWD: d.pwd,
          Enable: d.enable ? "1" : "0",
          AdvertisementEnable: d.hidden ? "0" : "1",
        }
      })

    setSaving(true)
    const r = await setWifiList(device.mac, session.token, {
      WIFIList: list,
      StaCtrl: String(rawSet.StaCtrl ?? "0"),
      // MLO 不在本页编辑，原样回写避免误改
      MloCtrl: (main?.mloCtrl ?? "0").trim() || "0",
    })
    setSaving(false)
    if (!r.ok) {
      flash(`保存失败：${r.error ?? ""}`)
      return
    }

    // 设备写入是异步的：轮询回读，直到回读值与自己下发的一致，再刷新页面
    flash("已下发，正在校验…")
    const target = (data: WifiRadioSet) =>
      drafts.every(d => {
        const e = data.list.find(x => x.index === d.index)
        if (!e) return false
        return (
          e.ssid === d.ssid &&
          e.pwd === d.pwd &&
          (e.enable.trim() !== "0") === d.enable &&
          (e.advertise.trim() === "0") === d.hidden
        )
      })

    for (let i = 0; i < 6; i++) {
      await new Promise<void>(resolve => setTimeout(() => resolve(), 1200))
      const a = await fetchMainWifi(device.mac, session.token)
      if (!a.ok || !a.data) continue
      if (target(a.data)) {
        applySet(a.data, a.raw)
        flash("已保存")
        return
      }
    }
    // 超时：还是刷一次（可能只是某个字段设备没接受）
    await load()
    flash("已下发，但回读仍是旧值（设备可能没接受这次修改）")
  }

  const toast = hintToast(hint ? { text: hint } : null, () => setHint(""))

  return (
    <ZStack
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      toolbar={{
        topBarTrailing: (
          <Button
            title={saving ? "保存中…" : confirmSave ? "确认保存" : "保存"}
            action={save}
            disabled={saving || loading || !dirty}
          />
        ),
      }}
    >
      <SettingsPage title="Wi-Fi 设置" toast={toast} refreshable={load}>
      {b24 ? (
        <BandCard
          draft={b24}
          onChange={patch(setB24, b24)}
          showPwd={!!shown["0"]}
          onTogglePwd={() => setShown(s => ({ ...s, "0": !s["0"] }))}
        />
      ) : null}

      {b5 ? (
        <BandCard
          draft={b5}
          onChange={patch(setB5, b5)}
          showPwd={!!shown["1"]}
          onTogglePwd={() => setShown(s => ({ ...s, "1": !s["1"] }))}
        />
      ) : null}

      {main === null && !loading ? (
        <Group>
          <NoticeRow kind="info" text="没读到 Wi-Fi 配置，下拉重试。" />
        </Group>
      ) : null}

      </SettingsPage>
    </ZStack>
  )
}
