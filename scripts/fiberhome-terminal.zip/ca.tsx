// ---------- 载波聚合参数（GET_CARRIER_AGGREGATION_INFO，只读） ----------
// 实测结构：{ main_CA_info: {...}, sub_CA_info: [] }
// 布局参考官方：按「上行 / 下行 / 网络」三段，每个参数一行 —— 左边参数名、右边主载波数值，
// 有聚合辅载波时，行下再给出 子载波 1–4 的同一参数数值；长按数值可单独复制。

import { HStack, Spacer, Text, VStack, useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import type { Hint } from "./lib/ui"
import { hintToast } from "./lib/ui"
import { ACCENT, DANGER, Group, NoticeRow, OK, Row, SettingsPage } from "./lib/settings"

/** 单个参数行：参数名 + 主载波数值，可选 子载波 1–4 数值 */
export function ParamRow(props: {
  label: string
  /** 英文原名/缩写，显示在参数名后面 */
  note?: string
  value: string
  subs: any[]
  subKey: string
  onCopy: (text: string, label: string) => void
}) {
  const { label, note, value, subs, subKey, onCopy } = props
  const subAt = (i: number) => {
    const raw = subs[i]?.[subKey]
    return raw === undefined || raw === null || raw === "" || raw === "-" ? "—" : String(raw)
  }
  const hasSubs = subs.length > 0
  const cell = (i: number) => {
    const s = subAt(i)
    return (
      <HStack key={`s${i}`} spacing={4} frame={{ width: 140, alignment: "leading" }} contentShape="rect" onLongPressGesture={() => onCopy(s, `子载波${i + 1} ${label}`)}>
        <Text font="caption2" foregroundStyle="tertiaryLabel">
          子载波{i + 1}
        </Text>
        <Text font="caption2" monospaced foregroundStyle={s === "—" ? "tertiaryLabel" : "secondaryLabel"} lineLimit={1}>
          {s}
        </Text>
      </HStack>
    )
  }

  // 每行两个子载波，只排实际存在的数量（2 载波 → 1 行，3 载波 → 1 行 + 1 行）
  const pairRows: any[] = []
  for (let i = 0; i < subs.length; i += 2) {
    pairRows.push(
      <HStack key={`r${i}`} spacing={4} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        {cell(i)}
        {i + 1 < subs.length ? cell(i + 1) : null}
      </HStack>
    )
  }

  return (
    <Row
      content={
        <VStack alignment="leading" spacing={4} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <HStack spacing={8} frame={{ maxWidth: "infinity", alignment: "leading" }}>
            <Text>{label}</Text>
            {note ? (
              <Text font="caption2" foregroundStyle="tertiaryLabel">
                {note}
              </Text>
            ) : null}
            <Spacer />
            <Text
              monospaced
              fontWeight="semibold"
              foregroundStyle={value === "—" ? "tertiaryLabel" : "label"}
              contentShape="rect"
              onLongPressGesture={() => onCopy(value, label)}
            >
              {value}
            </Text>
          </HStack>
          {hasSubs ? (
            <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
              {pairRows}
            </VStack>
          ) : null}
        </VStack>
      }
    />
  )
}

export default function CaPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices[0]

  const [main, setMain] = useState<any>(null)
  const [subs, setSubs] = useState<any[]>([])
  const [error, setError] = useState("")
  const [hint, setHint] = useState<Hint | null>(null)

  async function load() {
    if (!device?.mac || !session.token) return
    setError("")
    const r = await invokeService<any>(device.mac, session.token, "GET_CARRIER_AGGREGATION_INFO", {}, 8)
    if (r.ok) {
      const d = r.data ?? {}
      setMain(d.main_CA_info ?? null)
      setSubs(Array.isArray(d.sub_CA_info) ? d.sub_CA_info : [])
    } else {
      setError(`${r.error ?? "读取失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
    }
  }
  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  async function copyOne(text: string, label: string) {
    if (!text || text === "—") return
    await Pasteboard.setString(text)
    setHint({ text: `已复制 ${label}：${text}` })
  }

  const m = (k: string) => (main?.[k] !== undefined && main?.[k] !== "" ? String(main[k]) : "—")
  const active = String(main?.State ?? "") === "activated"

  const row = (label: string, key: string) => (
    <ParamRow label={label} note={key} value={m(key)} subs={subs} subKey={key} onCopy={copyOne} />
  )

  return (
    <SettingsPage title="载波聚合参数" refreshable={load} toast={hintToast(hint, () => setHint(null))}>
      {error ? (
        <Group>
          <NoticeRow kind="error" text={error} />
        </Group>
      ) : null}

      <Group header="主载波">
        <Row label="类型" icon="antenna.radiowaves.left.and.right" iconColor={active ? OK : "secondaryLabel"} value={m("Type")} />
        <Row
          label="状态"
          icon="power"
          iconColor={active ? OK : DANGER}
          value={active ? "已激活" : m("State")}
          valueColor={active ? OK : "secondaryLabel"}
        />
        <Row label="频段" icon="wave.3.right" value={`Band ${m("Band")}`} />
        <Row label="物理小区 ID" note="PCI" icon="dot.radiowaves.left.and.right" value={m("PCI")} />
      </Group>

      <Group header="上行参数">
        {row("带宽", "UIBandWidth")}
        {row("多天线层数", "UIMimo")}
        {row("调制方式", "UIModulation")}
        {row("资源块数", "UIRB")}
        {row("调制编码等级", "UIMCS")}
      </Group>

      <Group header="下行参数">
        {row("带宽", "DIBandWidth")}
        {row("多天线层数", "DIMimo")}
        {row("调制方式", "DIModulation")}
        {row("资源块数", "DIRB")}
        {row("调制编码等级", "DIMCS")}
        {row("信道质量", "CQI")}
        {row("传输层数", "RANK")}
      </Group>

      <Group
        header="网络参数"
        footer={
          subs.length
            ? `已聚合 ${subs.length} 个辅载波（共 ${subs.length + 1} 载波），每个参数行下方给出子载波 1–${subs.length} 的数值；长按任意数值可单独复制。`
            : "当前单载波运行（无辅载波），只显示主载波数值；聚合后每个参数行下方会给出子载波数值。长按数值可单独复制。"
        }
      >
        {row("频点", "Arfcn")}
        {row("控制信道发射功率", "PucchTxPower")}
        {row("路损", "PATH_LOSS")}
      </Group>
    </SettingsPage>
  )
}
