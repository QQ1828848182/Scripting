// ---------- 锁频设置（入口，对齐官方两项目录） ----------
// 锁小区 → GET_LOCK_CELL_LIST_INFO（只读，无写命令）
// 锁频段 → GET_LOCK_BAND_INFO / SET_LOCK_BAND_ENABLE（开关可写）/ SET_LOCK_BAND_INFO（本固件拒绝）
//
// 互斥规则（对齐网页版 updateLockMutualState）：锁频段与锁小区互斥 ——
// 一边「已开启」，另一边就整行变灰不可点，必须先关掉才能进另一个。

import { Image, Text, useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { Group, NoticeRow, OK, Row, SettingsPage } from "./lib/settings"

type Sub = "cell" | "band"

const GET_BAND = "GET_LOCK_BAND_INFO"
const GET_CELLS = "GET_LOCK_CELL_LIST_INFO"

const ITEMS: { key: Sub; label: string }[] = [
  { key: "cell", label: "锁小区" },
  { key: "band", label: "锁频段" },
]

export default function LockPage(props: {
  session: Session
  devices: DeviceInfo[]
  onBack: () => void
  onPush: (key: string) => void
}) {
  const { session, devices, onPush } = props
  const device = devices[0]

  // null = 还没读到
  const [bandOn, setBandOn] = useState<boolean | null>(null)
  const [cellOn, setCellOn] = useState<boolean | null>(null)
  const [error, setError] = useState("")
  const [blocked, setBlocked] = useState("")

  /** 一次读两个开关，用来判断互斥 */
  async function loadStates(quiet = false) {
    if (!device?.mac || !session.token) return
    setError("")
    const [b, c] = await Promise.all([
      invokeService<any>(device.mac, session.token, GET_BAND, {}, 10),
      invokeService<any>(device.mac, session.token, GET_CELLS, {}, 10),
    ])
    if (b.ok) setBandOn(String(b.data?.LockFrequencyBand ?? "0") === "1")
    if (c.ok) setCellOn(String(c.data?.LockCommunity ?? "0") === "1")
    if (!b.ok && !c.ok) setError(b.error ?? c.error ?? "读取锁频状态失败")
  }

  useEffect(() => {
    loadStates()
  }, [device?.mac, session.token])

  const onOf = (k: Sub) => (k === "cell" ? cellOn : bandOn)
  const otherOf = (k: Sub) => (k === "cell" ? bandOn : cellOn)
  const otherName = (k: Sub) => (k === "cell" ? "锁频段" : "锁小区")

  function open(k: Sub) {
    if (otherOf(k) === true) {
      setBlocked(`${otherName(k)}已开启，锁频段与锁小区互斥，请先在${otherName(k)}页关闭后再进入。`)
      setTimeout(() => setBlocked(""), 4000)
      return
    }
    setBlocked("")
    onPush(k)
  }

  return (
    <SettingsPage
      title="锁频设置"
      refreshable={async () => {
        await loadStates(true)
      }}
    >
      {error ? (
        <Group>
          <NoticeRow kind="error" text={error} />
        </Group>
      ) : null}

      {blocked ? (
        <Group>
          <NoticeRow kind="error" text={blocked} />
        </Group>
      ) : null}

      <Group>
        {ITEMS.map(it => {
          const on = onOf(it.key)
          const locked = otherOf(it.key) === true
          return (
            <Row
              key={it.key}
              label={it.label}
              note={locked ? `${otherName(it.key)}已开启，需先关闭才能进入` : undefined}
              value={on === true ? "已开启" : on === false ? "未开启" : undefined}
              valueColor={on === true ? OK : "secondaryLabel"}
              trailing={
                locked ? <Image systemName="lock.fill" font="footnote" foregroundStyle="tertiaryLabel" /> : undefined
              }
              chevron={!locked}
              onTap={() => open(it.key)}
            />
          )
        })}
      </Group>
    </SettingsPage>
  )
}
