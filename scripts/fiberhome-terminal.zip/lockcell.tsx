// ---------- 锁小区（iOS 设置风格） ----------
// 一级：锁小区开关 + 「锁小区 (n/20)」列表 + 底部「新增锁小区」
// 二级（新增）：网络制式 / 频点(0~875000) / PCI 选填(0~2000) + 右上角保存
//
// 命令实测（2026-10-28）：
//   SET_LOCK_CELL_ENABLE {Enable:"0"|"1"}  ✅ 真写（关→LockCommunity=0；开→=1 且小区列表保留）
//   SET_LOCK_CELL_INFO                     ❌ 恒定 Status:1 / FailReason:"json node null"（增删改小区都不行）
// 小区对象：{ FrequencyPoint:"627264", PCI:"209", Standard:"2", Id:"1" }，Standard=2 就是 5G NR。

import { Button, DragGesture, HStack, Text, ZStack, useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import { invokeService } from "./lib/invoke"
import { hintToast } from "./lib/ui"
import type { Hint } from "./lib/ui"
import {
  ACCENT,
  DANGER,
  Group,
  InputRow,
  NoticeRow,
  PickerRow,
  Row,
  SettingsPage,
  SwitchRow,
} from "./lib/settings"

const GET_CELLS = "GET_LOCK_CELL_LIST_INFO"
const SET_ENABLE = "SET_LOCK_CELL_ENABLE"
const SET_CELLS = "SET_LOCK_CELL_INFO"

const MAX_CELLS = 20

/** 网络制式：设备里 5G NR 存的是 Standard="2"；LTE 的取值未实测 */
const RATS = [
  { label: "5G NR", value: "2", verified: true },
  { label: "LTE", value: "1", verified: false },
]

const isPending = (err?: string, code?: number) =>
  /超时|timeout|中断/i.test(String(err ?? "")) || code === 20029 || code === 20012

export default function LockCellPage(props: { session: Session; devices: DeviceInfo[]; onBack: () => void }) {
  const { session, devices } = props
  const device = devices[0]

  const [cells, setCells] = useState<any[]>([])
  const [community, setCommunity] = useState("0")
  const [loading, setLoading] = useState(false)
  const [busy, setBusy] = useState<"" | "enable" | "add">("")
  const [error, setError] = useState("")
  const [hint, setHint] = useState("")
  const [toastHint, setToastHint] = useState<Hint | null>(null)

  const [form, setForm] = useState(false)
  const [rat, setRat] = useState("2")
  const [freq, setFreq] = useState("")
  const [pci, setPci] = useState("")
  const [formError, setFormError] = useState("")

  function apply(d: any) {
    setCells(Array.isArray(d?.lock_cell_list) ? d.lock_cell_list : [])
    setCommunity(String(d?.LockCommunity ?? "0"))
  }

  async function load(quiet = false) {
    if (!device?.mac || !session.token) return
    if (!quiet) setLoading(true)
    setError("")
    const r = await invokeService<any>(device.mac, session.token, GET_CELLS, {}, 10)
    if (!quiet) setLoading(false)
    if (r.ok) {
      apply(r.data)
    } else if (!quiet) {
      setError(`${r.error ?? "读取失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
    }
  }
  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  const enabled = community === "1"

  /** 开关：真写；会触发重新注册，用回读确认。 */
  async function writeEnable(next: boolean) {
    if (!device?.mac || busy) return
    // 首次加载完成前不写（避免进页面误写）
    if (next === enabled && loading) return
    setBusy("enable")
    setError("")
    setHint("")
    setCommunity(next ? "1" : "0")

    const r = await invokeService<any>(device.mac, session.token, SET_ENABLE, { Enable: next ? "1" : "0" }, 15)
    const pending = isPending(r.error, r.code)
    if (!r.ok && !pending) {
      setBusy("")
      setCommunity(enabled ? "1" : "0")
      setError(`${r.error ?? "写入失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
      return
    }

    let confirmed = false
    for (let i = 0; i < 40; i++) {
      await new Promise<void>(res => setTimeout(res, 1500))
      const c = await invokeService<any>(device.mac, session.token, GET_CELLS, {}, 10)
      if (!c.ok) continue
      if (String(c.data?.LockCommunity ?? "") === (next ? "1" : "0")) {
        apply(c.data)
        confirmed = true
        break
      }
    }
    setBusy("")
    if (confirmed) {
      setToastHint({ text: "设置成功" })
    } else {
      setHint(pending ? "下发后没等到回读（设备可能还在重注册），稍后下拉刷新确认" : "回读与目标不一致，已恢复设备当前值")
      setToastHint({ text: "设置失败", ok: false })
      load(true)
    }
  }

  function openForm() {
    if (!enabled) {
      setHint("锁小区已关闭，先打开开关才能新增")
      return
    }
    setForm(true)
    setRat("2")
    setFreq("")
    setPci("")
    setFormError("")
    setError("")
    setHint("")
  }

  /** 新增小区：本固件云端不支持，会如实回报拒因。 */
  async function saveCell() {
    if (!device?.mac || busy) return
    if (!enabled) {
      setFormError("")
      setError("锁小区已关闭，先打开开关再保存")
      return
    }
    const f = freq.trim()
    const p = pci.trim()
    if (f === "") {
      setFormError("频点不能为空")
      return
    }
    if (!/^\d+$/.test(f) || Number(f) < 0 || Number(f) > 875000) {
      setFormError("请输入 0～875000 之间的整数")
      return
    }
    if (p !== "" && (!/^\d+$/.test(p) || Number(p) > 2000)) {
      setFormError("请输入 0～2000 之间的整数")
      return
    }
    setFormError("")
    setBusy("add")
    setError("")
    setHint("")

    const nextId = cells.reduce((m, c) => Math.max(m, Number(c?.Id ?? 0)), 0) + 1
    const cell: any = { FrequencyPoint: f, PCI: p, Standard: rat, Id: String(nextId) }
    const list = [...cells, cell]

    const r = await invokeService<any>(
      device.mac,
      session.token,
      SET_CELLS,
      { Enable: "1", LockCommunity: "1", lock_cell_list: list },
      15
    )
    const pending = isPending(r.error, r.code)
    setBusy("")

    if (r.ok) {
      setForm(false)
      setToastHint({ text: "已新增锁小区" })
      load(true)
      return
    }
    if (pending) {
      setHint("下发超时（设备可能在重注册），稍后下拉刷新确认")
      return
    }
    setError(`${r.error ?? "写入失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
    setHint("这台 LG6851F 的云端插件不接受小区增删改（SET_LOCK_CELL_INFO 恒定 json node null，连原样回写也失败）。开关本身可写；要加/删基站请用 192.168.8.1 网页版。")
  }

  // ---------- 新增表单（二级页） ----------
  if (form) {
    const ratLabel = RATS.find(r => r.value === rat)?.label ?? rat
    return (
      <ZStack
        alignment="topLeading"
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        toolbar={{ topBarTrailing: <Button title="保存" action={saveCell} disabled={busy === "add"} /> }}
      >
        <SettingsPage title="新增锁小区">
          {hint ? (
            <Group>
              <NoticeRow kind="info" text={hint} />
            </Group>
          ) : null}

          {error ? (
            <Group>
              <NoticeRow kind="error" text={error} />
            </Group>
          ) : null}

          <Group>
            <PickerRow
              label="网络制式"
              value={ratLabel}
              selected={rat}
              options={RATS.map(r => ({
                value: r.value,
                label: r.label + (r.verified ? "" : "（未验证）"),
              }))}
              onSelect={v => setRat(v)}
            />
            <InputRow
              label="频点"
              value={freq}
              prompt="0～875000"
              onChanged={v => {
                setFreq(v)
                setFormError("")
              }}
            />
            <InputRow label="PCI（选填）" value={pci} prompt="0～2000" onChanged={v => setPci(v)} />
          </Group>

          {formError ? (
            <Group>
              <NoticeRow kind="error" text={formError} />
            </Group>
          ) : null}

        </SettingsPage>

        <HStack
          frame={{ width: 22, maxHeight: "infinity" }}
          contentShape="rect"
          gesture={DragGesture({ minDistance: 12 }).onEnded((v: any) => {
            if (v.translation.width > 60 && Math.abs(v.translation.height) < 200) setForm(false)
          })}
        />
      </ZStack>
    )
  }

  // ---------- 列表 ----------
  return (
    <SettingsPage
      title="锁小区"
      refreshable={async () => {
        await load(true)
      }}
      toast={hintToast(toastHint, () => setToastHint(null))}
    >
      {error ? (
        <Group>
          <NoticeRow kind="error" text={error} />
        </Group>
      ) : null}

      {hint ? (
        <Group>
          <NoticeRow kind="info" text={hint} />
        </Group>
      ) : null}

      <Group>
        <SwitchRow label="锁小区" value={enabled} onChanged={v => writeEnable(v)} />
      </Group>

      <Group header={`已锁定小区（${cells.length}/${MAX_CELLS}）`}>
        {cells.length === 0 ? (
          <Row label="还没有锁定任何小区" icon="minus.circle" />
        ) : (
          cells.map((c, i) => {
            const ratName = RATS.find(r => r.value === String(c.Standard ?? ""))?.label ?? `Standard=${String(c.Standard ?? "?")}`
            return (
              <Row
                key={String(c.Id ?? i)}
                icon="antenna.radiowaves.left.and.right"
                iconColor={ACCENT}
                label={`${ratName} · PCI ${String(c.PCI ?? "—")}`}
                note={`频点 ${String(c.FrequencyPoint ?? "—")} · Id ${String(c.Id ?? "—")}`}
              />
            )
          })
        )}
      </Group>

      <Group>
        <Row
          label={enabled ? "新增锁小区" : "新增锁小区（先打开开关）"}
          chevron={enabled && cells.length < MAX_CELLS}
          iconColor={enabled ? ACCENT : "tertiaryLabel"}
          onTap={openForm}
        />
      </Group>
    </SettingsPage>
  )
}
