// ---------- 登录页（账号 / 账号+Token，仅远程登录）· iOS 设置风格 ----------
// 视觉对齐系统「设置」：insetGroup 分组列表、白卡片分组、分组标题、行内右对齐输入框。

import {
  HStack,
  Image,
  List,
  Picker,
  ProgressView,
  Section,
  SecureField,
  Spacer,
  Text,
  TextField,
  VStack,
  useEffect,
  useState,
} from "scripting"
import type { Session } from "./lib/api"
import { APP_VERSION, loginWithPassword, loginWithToken } from "./lib/api"
import { saveSession, lastAccount } from "./lib/store"
import { ACCENT, DANGER, fill } from "./lib/ui"

export type LoginResult = { session: Session } | { cancelled: true } | { error: string }

export default function LoginPage(props: {
  /** 关闭登录页，返回结果 */
  onDone: (r: LoginResult) => void
  /** 初始错误（例如会话过期） */
  initialError?: string
}) {
  const { onDone, initialError } = props

  const [account, setAccount] = useState(lastAccount() || "")
  const [password, setPassword] = useState("")
  const [token, setToken] = useState("")
  const [useToken, setUseToken] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string>(initialError ?? "")

  useEffect(() => {
    setError(initialError ?? "")
  }, [initialError])

  const canSubmit =
    !busy && account.trim().length > 0 && (useToken ? token.trim().length > 0 : password.length > 0)

  async function submit() {
    if (!canSubmit) return
    setBusy(true)
    setError("")

    const acc = account.trim()
    try {
      const r = useToken
        ? await loginWithToken(acc, token)
        : await loginWithPassword(acc, password)
      saveSession(r.session)
      setBusy(false)
      onDone({ session: r.session })
    } catch (e: any) {
      setBusy(false)
      setError(friendly(e))
    }
  }

  return (
    <List
      listStyle="insetGroup"
      listSectionSpacing={24}
      navigationTitle="远程登录"
      navigationBarTitleDisplayMode="inline"
    >
      {/* 顶部：产品身份，等同「设置」里的账户行 */}
      <Section>
        <HStack spacing={12} padding={{ vertical: 2 }}>
          <Image
            systemName="wifi.router.fill"
            font={16}
            foregroundStyle="white"
            frame={{ width: 30, height: 30 }}
            background={fill(ACCENT, 8)}
          />
          <VStack alignment="leading" spacing={1}>
            <Text fontWeight="semibold">烽火终端</Text>
            <Text font="footnote" foregroundStyle="secondaryLabel">
              5G CPE Pro · 云端控制台
            </Text>
          </VStack>
          <Spacer />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            远程
          </Text>
        </HStack>
      </Section>

      {/* 登录方式：系统分段控件，整行铺满卡片 */}
      <Section header={<Text>登录方式</Text>}>
        <Picker
          title=""
          pickerStyle="segmented"
          value={useToken ? "token" : "password"}
          onChanged={(v: string) => {
            setUseToken(v === "token")
            setError("")
          }}
        >
          <Text tag="password">账号密码</Text>
          <Text tag="token">账号 Token</Text>
        </Picker>
      </Section>

      {/* 账号信息：标题在左、输入在右 */}
      <Section header={<Text>账号</Text>}>
        <HStack spacing={10} frame={{ maxWidth: "infinity" }}>
          <Text>账号</Text>
          <TextField
            title=""
            value={account}
            onChanged={v => {
              setAccount(v)
              setError("")
            }}
            prompt="请输入手机号或邮箱"
            textInputAutocapitalization="characters"
            autocorrectionDisabled
            multilineTextAlignment="trailing"
            frame={{ maxWidth: "infinity" }}
          />
        </HStack>

        {useToken ? (
          <HStack spacing={10} frame={{ maxWidth: "infinity" }}>
            <Text>Token</Text>
            <TextField
              title=""
              value={token}
              onChanged={v => {
                setToken(v)
                setError("")
              }}
              prompt="粘贴 Token"
              autocorrectionDisabled
              textInputAutocapitalization="never"
              multilineTextAlignment="trailing"
              frame={{ maxWidth: "infinity" }}
            />
          </HStack>
        ) : (
          <HStack spacing={10} frame={{ maxWidth: "infinity" }}>
            <Text>密码</Text>
            <SecureField
              title=""
              value={password}
              onChanged={v => {
                setPassword(v)
                setError("")
              }}
              frame={{ maxWidth: "infinity" }}
            />
          </HStack>
        )}
      </Section>

      {/* 提交：整行按钮 + 脚注（错误 / 说明 / 版本） */}
      <Section
        footer={
          <VStack alignment="leading" spacing={6} frame={{ maxWidth: "infinity" }}>
            {error ? <Text foregroundStyle={DANGER}>{error}</Text> : null}
            <Text foregroundStyle="secondaryLabel">仅支持远程登录，不连接局域网网关</Text>
            <Text foregroundStyle="secondaryLabel">
              {`客户端 烽火终端 ${APP_VERSION} · 密码在本地做 SHA-256，凭据存 Keychain`}
            </Text>
          </VStack>
        }
      >
        <HStack
          frame={{ maxWidth: "infinity", minHeight: 22 }}
          contentShape="rect"
          onTapGesture={submit}
        >
          {busy ? (
            <ProgressView progressViewStyle="circular" controlSize="small" />
          ) : (
            <Text
              fontWeight="semibold"
              foregroundStyle={canSubmit ? ACCENT : "secondaryLabel"}
              frame={{ maxWidth: "infinity" }}
            >
              {useToken ? "使用 Token 登录" : "登录"}
            </Text>
          )}
        </HStack>
      </Section>
    </List>
  )
}

// ---------------- 错误处理 ----------------

function friendly(e: any): string {
  if (!e) return "登录失败"
  const msg = String(e?.message ?? e ?? "")
  return msg || "登录失败"
}
