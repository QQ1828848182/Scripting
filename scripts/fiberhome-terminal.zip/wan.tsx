// ---------- 上网设置：上行方式（官方 5 项单选） ----------
// 读：GET_UPLINK_NETWORK_MODE → { LinkMode, Percent }
// 写：SET_UPLINK_NETWORK_MODE { LinkMode, Percent? }
//
// 取值（实测：蜂窝上行=1，以太上行=2，后面顺延）：
//   1 蜂窝上行 / 2 以太上行 / 3 蜂窝上行优先 / 4 以太上行优先 / 5 双网聚合
// 注意：GET 里的 Percent 是「信号百分比」（90 = 90%），不是双网聚合占比；
// 双网聚合的占比字段名未验证，暂按 Percent 发，被拒则退回只发 LinkMode。

import { HStack, Spacer, Text, TextField, ZStack, useState, useEffect } from "scripting"
import type { DeviceInfo, Session } from "./lib/api"
import type { WanInfo } from "./lib/cmds"
import { invokeService } from "./lib/invoke"
import { hintToast, fill } from "./lib/ui"
import type { Hint } from "./lib/ui"
import { ButtonRow, ChoiceRow, Group, NoticeRow, Row, SettingsPage } from "./lib/settings"

/** 上行方式：1 = 蜂窝，2 = 以太，后面同官方列表顺序顺延 */
const UPLINK_MODES: { value: string; label: string }[] = [
  { value: "1", label: "蜂窝上行" },
  { value: "2", label: "以太上行" },
  { value: "3", label: "蜂窝上行优先" },
  { value: "4", label: "以太上行优先" },
  { value: "5", label: "双网聚合" },
]

const MODE_AGG = "5" // 双网聚合

/** LinkMode → 中文名（读不到时默认蜂窝上行） */
export function uplinkLabel(v: string): string {
  const s = String(v ?? "").trim()
  return UPLINK_MODES.find(m => m.value === s)?.label ?? "蜂窝上行"
}

const GET_UPLINK = "GET_UPLINK_NETWORK_MODE"
const SET_UPLINK = "SET_UPLINK_NETWORK_MODE"

export default function WanPage(props: {
  session: Session
  devices: DeviceInfo[]
  onBack: () => void
  prefill?: WanInfo
  /** 切换成功后回传新的 LinkMode，供上层（路由设置页）刷新显示 */
  onModeChanged?: (mode: string) => void
}) {
  const { session, devices } = props
  const device = devices?.[0]

  const [pick, setPick] = useState("")
  /** 双网聚合的以太占比（可编辑），蜂窝 = 100 - 以太 */
  const [eth, setEth] = useState("10")
  const [saving, setSaving] = useState(false)
  const [confirmDone, setConfirmDone] = useState(false)
  const [error, setError] = useState("")
  const [hint, setHint] = useState<Hint | null>(null)

  async function load() {
    const mac = device?.mac
    const token = session.token
    if (!mac || !token) return
    setError("")
    const r = await invokeService<any>(mac, token, GET_UPLINK, {}, 8)
    if (!r.ok) {
      setError(`${r.error ?? "读取失败"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
      return
    }
    const lm = String(r.data?.LinkMode ?? "")
    setPick(prev => (prev === "" ? lm : prev))
  }

  useEffect(() => {
    load()
  }, [device?.mac, session.token])

  async function saveUplink() {
    const mac = device?.mac
    const token = session.token
    if (!mac || !token || saving || !pick) return
    const ratio = String(Math.max(0, 100 - Math.min(100, Number(eth) || 10)))
    if (!confirmDone) {
      setConfirmDone(true)
      setTimeout(() => setConfirmDone(false), 6000)
      return
    }
    setConfirmDone(false)
    setSaving(true)
    setError("")

    const params: any = { LinkMode: pick }
    if (pick === MODE_AGG) params.Percent = ratio

    let r = await invokeService<any>(mac, token, SET_UPLINK, params, 15)
    let stripped = false
    if (!r.ok && pick === MODE_AGG) {
      // Percent 字段可能不被接受（或含义不同），退回只发 LinkMode
      const r2 = await invokeService<any>(mac, token, SET_UPLINK, { LinkMode: pick }, 15)
      if (r2.ok) {
        r = r2
        stripped = true
      }
    }
    if (!r.ok) {
      setSaving(false)
      setError(`切换失败：${r.error ?? "未知"}${r.code !== undefined ? ` (code ${r.code})` : ""}`)
      setHint({ text: "切换失败", ok: false })
      return
    }

    // 回读校对
    let backMode = ""
    for (let i = 0; i < 6; i++) {
      await new Promise<void>(res => setTimeout(res, 600))
      const c = await invokeService<any>(mac, token, GET_UPLINK, {}, 8)
      if (!c.ok) continue
      backMode = String(c.data?.LinkMode ?? "")
      if (backMode === pick) break
    }
    setSaving(false)

    if (backMode) props.onModeChanged?.(backMode)
    if (backMode === pick) {
      const label = UPLINK_MODES.find(m => m.value === pick)?.label ?? pick
      setHint({ text: `已切换为「${label}」${stripped ? "（占比未下发）" : ""}` })
    } else {
      setHint({ text: backMode ? `已下发，回读 LinkMode=${backMode}` : "已下发，未回读到模式", ok: false })
    }
  }

  const ethPct = Math.max(0, Math.min(100, Number(eth) || 0))
  const cellularPct = 100 - ethPct

  const rows: any[] = []
  for (const m of UPLINK_MODES) {
    rows.push(
      <ChoiceRow
        key={m.value}
        title={m.label}
        selected={pick === m.value}
        spinner={saving && pick === m.value}
        onTap={() => {
          if (saving) return
          setPick(m.value)
        }}
      />
    )
    if (m.value === MODE_AGG && pick === MODE_AGG) {
      rows.push(
        <Row
          key="ratio"
          content={
            <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
              <Text foregroundStyle="label">带宽占比</Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                蜂窝:以太
              </Text>
              <Spacer />
              <Text monospaced foregroundStyle="label">
                {`${cellularPct}:`}
              </Text>
              <TextField
                title=""
                value={eth}
                onChanged={v => {
                  const digits = v.replace(/[^\d]/g, "")
                  const n = digits === "" ? 0 : Math.min(100, Number(digits))
                  setEth(String(n))
                }}
                multilineTextAlignment="trailing"
                keyboardType="numberPad"
                padding={{ horizontal: 8, vertical: 4 }}
                frame={{ width: 58 }}
                background={fill("rgba(120,120,128,0.20)", 8)}
              />
            </HStack>
          }
        />
      )
    }
  }

  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      <SettingsPage title="上网设置" refreshable={load} toast={hintToast(hint, () => setHint(null))}>
        {error ? (
          <Group>
            <NoticeRow kind="error" text={error} />
          </Group>
        ) : null}

        <Group
          header="上行方式"
          footer="切换会重新建立上联（可能瞬断）。双网聚合按「蜂窝:以太」占比分配带宽。"
        >
          {rows}
          <ButtonRow
            title={saving ? "下发中…" : confirmDone ? "再点一次确认切换" : "完成"}
            busy={saving}
            onTap={() => saveUplink()}
          />
        </Group>
      </SettingsPage>
    </ZStack>
  )
}
